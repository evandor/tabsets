import { h as useAlignProps, i as useAlign, d as QBtn, Q as QIcon } from "./QBtn.a54a10bb.js";
import { l as QCardSection, f as QImg, g as QItemLabel, m as QSeparator, k as QCard, T as TabsetApi, h as useQuasar, n as Tabset, j as QExpansionItem, i as QList, e as QItemSection } from "./TabsetApi.8c10dc31.js";
import { Q as QPage } from "./QPage.94a5415d.js";
import { c as computed, h, S as defineComponent, W as openBlock, a3 as createElementBlock, F as Fragment, a4 as renderList, d as createVNode, V as withCtx, a1 as createBaseVNode, Z as toDisplayString, r as ref, a0 as useTabGroupsStore, $ as useTabsStore, ad as onUpdated, U as createBlock, N as withDirectives, a9 as vShow, ae as useRoute, ab as _, Y as createTextVNode, X as createCommentVNode } from "./index.b9fa4abe.js";
import { c as createComponent, h as hSlot } from "./render.4e012312.js";
var QCardActions = createComponent({
  name: "QCardActions",
  props: {
    ...useAlignProps,
    vertical: Boolean
  },
  setup(props, { slots }) {
    const alignClass = useAlign(props);
    const classes = computed(
      () => `q-card__actions ${alignClass.value} q-card__actions--${props.vertical === true ? "vert column" : "horiz row"}`
    );
    return () => h("div", { class: classes.value }, hSlot(slots.default));
  }
});
const _hoisted_1$1 = { class: "row items-start" };
const _hoisted_2$1 = { class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs" };
const _hoisted_3 = { class: "text-overline" };
const _hoisted_4 = { class: "text-h6 q-mt-sm q-mb-xs" };
const _hoisted_5 = {
  class: "text-caption text-grey wrap",
  style: { "overflow": "hidden" }
};
const _hoisted_6 = { class: "cursor-pointer" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Tabcards",
  props: {
    tabs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    new TabsetApi(null);
    function getHost(urlAsString) {
      const url = new URL(urlAsString);
      return url.host;
    }
    function maxChar(max, t) {
      if (t.length > max - 3) {
        return t.substring(0, max - 3) + "...";
      }
      return t;
    }
    function openOrCreateTab(withUrl) {
      let found = false;
      chrome.tabs.query({ currentWindow: true }, (t) => {
        t.filter((r) => !r.url.startsWith("chrome")).map((r) => {
          if (withUrl === r.url) {
            found = true;
            chrome.tabs.highlight({ tabs: r.index });
          }
        });
      });
      console.log("found", found);
      if (!found) {
        chrome.tabs.create({
          active: false,
          pinned: false,
          url: withUrl
        }).catch((e) => {
          console.log("got error", e);
        });
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(props.tabs, (tab) => {
          return openBlock(), createElementBlock("div", _hoisted_2$1, [
            createVNode(QCard, {
              class: "my-card",
              flat: "",
              bordered: "",
              style: { "height": "200px", "max-height": "200px", "min-height": "200px" }
            }, {
              default: withCtx(() => [
                createVNode(QCardSection, { horizontal: "" }, {
                  default: withCtx(() => [
                    createVNode(QCardSection, { class: "q-pt-xs" }, {
                      default: withCtx(() => [
                        createBaseVNode("div", null, [
                          createVNode(QImg, {
                            class: "rounded-borders",
                            width: "20px",
                            height: "20px",
                            src: tab.favIconUrl
                          }, null, 8, ["src"])
                        ]),
                        createBaseVNode("div", _hoisted_3, toDisplayString(getHost(tab.url)), 1),
                        createBaseVNode("div", _hoisted_4, toDisplayString(maxChar(20, tab.title)), 1),
                        createBaseVNode("div", _hoisted_5, [
                          createVNode(QItemLabel, {
                            lines: "1",
                            class: "q-mt-xs text-body2 text-primary",
                            onClick: ($event) => openOrCreateTab(tab.url)
                          }, {
                            default: withCtx(() => [
                              createBaseVNode("span", _hoisted_6, toDisplayString(maxChar(30, tab.url)), 1)
                            ]),
                            _: 2
                          }, 1032, ["onClick"])
                        ])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024),
                createVNode(QSeparator),
                createVNode(QCardActions, { style: { "min-height": "50px", "max-height": "50px" } }, {
                  default: withCtx(() => [
                    createVNode(QBtn, {
                      flat: "",
                      round: "",
                      icon: "event"
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024)
          ]);
        }), 256))
      ]);
    };
  }
});
const _hoisted_1 = { class: "text-h6" };
const _hoisted_2 = { class: "text-caption" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Tabset",
  setup(__props) {
    const route = useRoute();
    const localStorage = useQuasar().localStorage;
    const tabsetApi = new TabsetApi(localStorage);
    const tabsetId = ref("");
    const tabset = ref(null);
    const tabs = ref(null);
    const tabGroupsStore = useTabGroupsStore();
    const tabsStore = useTabsStore();
    function init() {
      console.log("updating tabset", route.params.tabsetId);
      tabsetId.value = route.params.tabsetId;
      if (tabsetId.value === "current") {
        tabset.value = new Tabset("current", "current", []);
        tabs.value = tabsStore.tabs;
      } else {
        tabset.value = tabsetApi.getTabset(tabsetId.value) || new Tabset("", "", []);
        tabs.value = tabset.value.tabs;
      }
    }
    init();
    onUpdated(() => {
      init();
    });
    function pinned(tabs2) {
      return _.filter(tabs2, (t) => t.pinned);
    }
    function unpinnedNoGroup(tabs2) {
      return _.filter(tabs2, (t) => !t.pinned && t.groupId === -1);
    }
    function getTabGroups() {
      return tabGroupsStore.data;
    }
    function tabsForGroup(tabs2, groupId) {
      return _.filter(tabs2, (t) => t.groupId === groupId);
    }
    function restore() {
      console.log("restoring tabset", tabset.value.id);
      tabsetApi.restore(tabset.value.id);
    }
    function newTabsetFrom(title, groupId) {
      console.log("creating tabset from group", groupId);
      tabsetApi.createFromGroup(tabset.value.id, title, groupId);
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, toDisplayString(tabset.value.name), 1),
          createBaseVNode("div", _hoisted_2, toDisplayString(tabset.value.date), 1),
          createBaseVNode("div", null, [
            withDirectives(createVNode(QBtn, {
              label: "restore",
              onClick: _cache[0] || (_cache[0] = ($event) => restore())
            }, null, 512), [
              [vShow, tabset.value.name !== "current"]
            ])
          ]),
          createVNode(QList, {
            bordered: "",
            class: "rounded-borders"
          }, {
            default: withCtx(() => [
              createVNode(QExpansionItem, {
                "expand-separator": "",
                icon: "push_pin",
                label: "Pinned Tabs",
                caption: "John Doe"
              }, {
                default: withCtx(() => [
                  createVNode(QCard, null, {
                    default: withCtx(() => [
                      createVNode(QCardSection, null, {
                        default: withCtx(() => [
                          createVNode(_sfc_main$1, {
                            tabs: pinned(tabs.value)
                          }, null, 8, ["tabs"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              (openBlock(true), createElementBlock(Fragment, null, renderList(getTabGroups(), (group) => {
                return openBlock(), createElementBlock("div", null, [
                  tabsForGroup(tabs.value, group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                    key: 0,
                    "expand-separator": ""
                  }, {
                    header: withCtx(({ expanded }) => [
                      createVNode(QItemSection, { avatar: "" }, {
                        default: withCtx(() => [
                          createVNode(QIcon, {
                            color: group.color,
                            name: "tab"
                          }, null, 8, ["color"])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(QItemSection, null, {
                        default: withCtx(() => [
                          createBaseVNode("div", null, [
                            createTextVNode(toDisplayString(group.title + " (" + tabsForGroup(tabs.value, group.id).length + ")") + " ", 1),
                            expanded ? (openBlock(), createBlock(QBtn, {
                              key: 0,
                              label: "create new tabset",
                              onClick: ($event) => newTabsetFrom(group.title, group.id)
                            }, null, 8, ["onClick"])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    default: withCtx(() => [
                      createVNode(QCard, null, {
                        default: withCtx(() => [
                          createVNode(QCardSection, null, {
                            default: withCtx(() => [
                              createVNode(_sfc_main$1, {
                                tabs: tabsForGroup(tabs.value, group.id)
                              }, null, 8, ["tabs"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)) : createCommentVNode("", true)
                ]);
              }), 256)),
              createVNode(QExpansionItem, {
                "expand-separator": "",
                icon: "push_pin",
                label: "Other Tabs",
                caption: "John Doe"
              }, {
                default: withCtx(() => [
                  createVNode(QCard, null, {
                    default: withCtx(() => [
                      createVNode(QCardSection, null, {
                        default: withCtx(() => [
                          createVNode(_sfc_main$1, {
                            tabs: unpinnedNoGroup(tabs.value)
                          }, null, 8, ["tabs"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
