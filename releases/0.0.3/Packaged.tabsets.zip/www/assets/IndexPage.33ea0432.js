import { Q as QPage } from "./QPage.94a5415d.js";
import { S as defineComponent, U as createBlock, V as withCtx, W as openBlock, a1 as createBaseVNode } from "./index.b9fa4abe.js";
import "./render.4e012312.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "row" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col" }, [
    /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Tabset Extension")
  ])
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "row" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col" }, [
    /* @__PURE__ */ createBaseVNode("div", { class: "text-body1" }, ' To get started, click on "current" on the left. This will open your current set of tabs on a new page where you can organize them and store them, giving this set of tabs a name. ')
  ])
], -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "IndexPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { class: "q-ma-lg" }, {
        default: withCtx(() => [
          _hoisted_1,
          _hoisted_2
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
