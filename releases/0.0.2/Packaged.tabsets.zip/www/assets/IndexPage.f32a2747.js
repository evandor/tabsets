import { Q as QPage } from "./QPage.a0c1e799.js";
import { S as defineComponent, r as ref, c as computed, W as openBlock, a2 as createElementBlock, a1 as createBaseVNode, Z as toDisplayString, F as Fragment, a3 as renderList, a4 as unref, U as createBlock, V as withCtx, d as createVNode, Y as createTextVNode } from "./index.3d6a4c02.js";
import { u as useAuthStore } from "./auth.b31b40d2.js";
import "./render.56c4261b.js";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ExampleComponent",
  props: {
    title: null,
    todos: { default: () => [] },
    meta: null,
    active: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const clickCount = ref(0);
    function increment() {
      clickCount.value += 1;
      return clickCount.value;
    }
    const todoCount = computed(() => props.todos.length);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("p", null, toDisplayString(__props.title), 1),
        createBaseVNode("ul", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(__props.todos, (todo) => {
            return openBlock(), createElementBlock("li", {
              key: todo.id,
              onClick: increment
            }, toDisplayString(todo.id) + " - " + toDisplayString(todo.content), 1);
          }), 128))
        ]),
        createBaseVNode("p", null, "Count: " + toDisplayString(unref(todoCount)) + " / " + toDisplayString(__props.meta.totalCount), 1),
        createBaseVNode("p", null, "Active: " + toDisplayString(__props.active ? "yes" : "no"), 1),
        createBaseVNode("p", null, "Clicks on todos: " + toDisplayString(clickCount.value), 1)
      ]);
    };
  }
});
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "IndexPage",
  setup(__props) {
    const todos = ref([
      {
        id: 1,
        content: "ct1"
      }
    ]);
    const meta = ref({
      totalCount: 1200
    });
    const authStore = useAuthStore();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { class: "row items-center justify-evenly" }, {
        default: withCtx(() => [
          createVNode(_sfc_main$1, {
            title: "Example component",
            active: "",
            todos: todos.value,
            meta: meta.value
          }, null, 8, ["todos", "meta"]),
          createTextVNode(" " + toDisplayString(unref(authStore).getUsername) + "*** ", 1)
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
