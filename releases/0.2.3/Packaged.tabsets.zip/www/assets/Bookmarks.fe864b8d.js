var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { n as createComponent, bg as useRouterLinkProps, bh as useRouterLink, c as computed, h, a1 as QIcon, H as hMergeSlot, bC as useAlignProps, bD as useAlign, bE as getNormalizedVNodes, q as hSlot, I as defineComponent, aX as useBookmarksStore, J as useTabsStore, r as ref, j as openBlock, k as createBlock, l as withCtx, ay as unref, a8 as QDialog, L as useRouter, b1 as useRoute, K as useQuasar, d as createVNode, aF as QCardSection, M as createBaseVNode, aC as toDisplayString, aG as QInput, aH as withKeys, a$ as QRadio, aB as createCommentVNode, aI as QCardActions, aJ as QBtn, ap as withDirectives, aK as QCard, bv as ChromeApi, ax as TabsetService, az as createElementBlock, F as Fragment, aM as renderList, aA as createTextVNode, aN as normalizeStyle, aP as _, aD as withModifiers, aE as Navigation, aw as watchEffect, aR as uid } from "./index.ac7851bc.js";
import { a as QToolbarTitle, Q as QToolbar } from "./QToolbar.8ddc4c0b.js";
import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { Q as QPage } from "./QPage.d2025984.js";
import { Q as QPopupEdit } from "./QPopupEdit.065c1278.js";
import { a as QBadge } from "./QMenu.39c979c3.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
import { B as BookmarksService } from "./BookmarksService.21bead40.js";
import { _ as _export_sfc } from "./plugin-vue_export-helper.21dcd24c.js";
import { _ as _sfc_main$3 } from "./Fab.577affc8.js";
import "./NewTabsetDialog.35dde97f.js";
import "./ReindexDialog.ccfa929c.js";
var QBreadcrumbsEl = createComponent({
  name: "QBreadcrumbsEl",
  props: {
    ...useRouterLinkProps,
    label: String,
    icon: String,
    tag: {
      type: String,
      default: "span"
    }
  },
  emits: ["click"],
  setup(props, { slots }) {
    const { linkTag, linkAttrs, linkClass, navigateOnClick } = useRouterLink();
    const data = computed(() => {
      return {
        class: "q-breadcrumbs__el q-link flex inline items-center relative-position " + (props.disable !== true ? "q-link--focusable" + linkClass.value : "q-breadcrumbs__el--disable"),
        ...linkAttrs.value,
        onClick: navigateOnClick
      };
    });
    const iconClass = computed(
      () => "q-breadcrumbs__el-icon" + (props.label !== void 0 ? " q-breadcrumbs__el-icon--with-label" : "")
    );
    return () => {
      const child = [];
      props.icon !== void 0 && child.push(
        h(QIcon, {
          class: iconClass.value,
          name: props.icon
        })
      );
      props.label !== void 0 && child.push(props.label);
      return h(
        linkTag.value,
        { ...data.value },
        hMergeSlot(slots.default, child)
      );
    };
  }
});
const disabledValues = ["", true];
var QBreadcrumbs = createComponent({
  name: "QBreadcrumbs",
  props: {
    ...useAlignProps,
    separator: {
      type: String,
      default: "/"
    },
    separatorColor: String,
    activeColor: {
      type: String,
      default: "primary"
    },
    gutter: {
      type: String,
      validator: (v) => ["none", "xs", "sm", "md", "lg", "xl"].includes(v),
      default: "sm"
    }
  },
  setup(props, { slots }) {
    const alignClass = useAlign(props);
    const classes = computed(
      () => `flex items-center ${alignClass.value}${props.gutter === "none" ? "" : ` q-gutter-${props.gutter}`}`
    );
    const sepClass = computed(() => props.separatorColor ? ` text-${props.separatorColor}` : "");
    const activeClass = computed(() => ` text-${props.activeColor}`);
    return () => {
      const vnodes = getNormalizedVNodes(
        hSlot(slots.default)
      );
      if (vnodes.length === 0) {
        return;
      }
      let els = 1;
      const child = [], len = vnodes.filter((c) => c.type !== void 0 && c.type.name === "QBreadcrumbsEl").length, separator = slots.separator !== void 0 ? slots.separator : () => props.separator;
      vnodes.forEach((comp) => {
        if (comp.type !== void 0 && comp.type.name === "QBreadcrumbsEl") {
          const middle = els < len;
          const disabled = comp.props !== null && disabledValues.includes(comp.props.disable);
          const cls = (middle === true ? "" : " q-breadcrumbs--last") + (disabled !== true && middle === true ? activeClass.value : "");
          els++;
          child.push(
            h("div", {
              class: `flex items-center${cls}`
            }, [comp])
          );
          if (middle === true) {
            child.push(
              h("div", {
                class: "q-breadcrumbs__separator" + sepClass.value
              }, separator())
            );
          }
        } else {
          child.push(comp);
        }
      });
      return h("div", {
        class: "q-breadcrumbs"
      }, [
        h("div", { class: classes.value }, child)
      ]);
    };
  }
});
const _hoisted_1$2 = { class: "text-h6" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please provide a name for the new tabset", -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "New Tabset's name:", -1);
const _hoisted_4$2 = { class: "text-body2 text-warning" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "ImportFromBookmarks",
  props: {},
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const props = __props;
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const bookmarksStore = useBookmarksStore();
    const tabsStore = useTabsStore();
    const router = useRouter();
    useRoute();
    const $q = useQuasar();
    const newTabsetName = ref(bookmarksStore.currentBookmark.chromeBookmark.title);
    const bookmarkId = ref(bookmarksStore.currentBookmark.chromeBookmark.id);
    const merge = ref(false);
    const tabNameExists = () => tabsStore.nameExistsInContextTabset(newTabsetName.value);
    const newTabsetDialogWarning = () => {
      if (tabsStore.nameExistsInContextTabset(newTabsetName.value)) {
        return "Tabset " + newTabsetName.value + " already exists. Please choose:";
      }
      return "";
    };
    const importBookmarks = async () => {
      console.log("importing bookmarks", bookmarkId.value);
      $q.loadingBar.start();
      try {
        const candidates = await ChromeApi.childrenFor(bookmarkId.value);
        const result = await TabsetService.saveOrReplaceFromBookmarks(newTabsetName.value, candidates, true);
        const replaced = result.replaced;
        const merged = result.merged;
        let message = "Tabset " + newTabsetName.value + " created successfully";
        if (replaced && merged) {
          message = "Tabset " + newTabsetName.value + " was updated";
        } else if (replaced) {
          message = "Tabset " + newTabsetName.value + " was overwritten";
        }
        router.push("/tabset");
        $q.notify({
          message,
          type: "positive"
        });
      } catch (ex) {
        console.error("ex", ex);
        $q.notify({
          message: "There was a problem creating the tabset " + newTabsetName.value,
          type: "warning"
        });
      }
      $q.loadingBar.stop();
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { style: { "min-width": "350px" } }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  createBaseVNode("div", _hoisted_1$2, "Import this Bookmarks Folder " + toDisplayString(props.folderId) + "/" + toDisplayString(props.folderName) + " as Tabset", 1)
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$2
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  _hoisted_3$2,
                  createVNode(QInput, {
                    dense: "",
                    modelValue: newTabsetName.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newTabsetName.value = $event),
                    autofocus: "",
                    onKeyup: _cache[1] || (_cache[1] = withKeys(($event) => _ctx.prompt = false, ["enter"]))
                  }, null, 8, ["modelValue"]),
                  createBaseVNode("div", _hoisted_4$2, toDisplayString(newTabsetDialogWarning()), 1),
                  tabNameExists() ? (openBlock(), createBlock(QRadio, {
                    key: 0,
                    modelValue: merge.value,
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => merge.value = $event),
                    val: "true",
                    label: "Merge"
                  }, null, 8, ["modelValue"])) : createCommentVNode("", true),
                  tabNameExists() ? (openBlock(), createBlock(QRadio, {
                    key: 1,
                    modelValue: merge.value,
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => merge.value = $event),
                    val: "false",
                    label: "Overwrite"
                  }, null, 8, ["modelValue"])) : createCommentVNode("", true)
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    label: "Create new Tabset",
                    disable: newTabsetName.value.trim().length === 0,
                    onClick: _cache[4] || (_cache[4] = ($event) => importBookmarks())
                  }, null, 8, ["disable"]), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
var BookmarkCards_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$1 = { class: "row items-start q-mb-xl" };
const _hoisted_2$1 = ["onDragstart"];
const _hoisted_3$1 = { class: "row items-baseline" };
const _hoisted_4$1 = { class: "col-2" };
const _hoisted_5$1 = { class: "col-10 text-subtitle1 ellipsis" };
const _hoisted_6$1 = { class: "text-subtitle2 ellipsis text-secondary" };
const _hoisted_7 = { class: "row fit" };
const _hoisted_8 = { class: "col-xs-12 col-md-7" };
const _hoisted_9 = { class: "col-xs-12 col-md-5 text-right" };
const _hoisted_10 = { class: "row items-start" };
const _hoisted_11 = ["onDragstart"];
const _hoisted_12 = { class: "row items-baseline" };
const _hoisted_13 = { class: "col-2" };
const _hoisted_14 = { class: "col-10 text-subtitle1 ellipsis" };
const _hoisted_15 = { class: "text-subtitle2 ellipsis text-secondary" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "BookmarkCards",
  emits: ["sendCaption"],
  setup(__props, { emit: emits }) {
    const bookmarksStore = useBookmarksStore();
    const router = useRouter();
    const $q = useQuasar();
    function deleteBookmark(bm) {
      BookmarksService.deleteBookmark(bm);
    }
    function cardStyle(bm) {
      let borderColor = "";
      if (bm == null ? void 0 : bm.selected) {
        borderColor = "border-color:#000066";
      }
      let background = "";
      return `${borderColor};${background}`;
    }
    const setInfo = (tab) => {
      var _a;
      const parts = (((_a = tab.chromeTab) == null ? void 0 : _a.url) || "").split("?");
      if (parts.length > 1) {
        emits("sendCaption", parts[0] + "[... params omitted....]");
      } else if (parts.length === 1) {
        emits("sendCaption", parts[0].toString());
      }
    };
    const selectBookmark = (bm) => {
      router.push("/bookmarks/" + bm.chromeBookmark.id);
    };
    const setCustomTitle = (tab, newValue) => {
      console.log(" -> ", newValue);
      TabsetService.setCustomTitle(tab, newValue);
    };
    const nameOrTitle = (bm) => {
      var _a;
      return (_a = bm == null ? void 0 : bm.chromeBookmark) == null ? void 0 : _a.title;
    };
    const dynamicNameOrTitleModel = (bm) => {
      var _a;
      return (_a = bm == null ? void 0 : bm.chromeBookmark) == null ? void 0 : _a.title;
    };
    const startDrag = (evt, bm) => {
      if (evt.dataTransfer) {
        evt.dataTransfer.dropEffect = "move";
        evt.dataTransfer.effectAllowed = "move";
        evt.dataTransfer.setData("text/plain", bm.id);
      }
    };
    const importBookmarks = () => {
      $q.dialog({ component: _sfc_main$2 });
    };
    const existsInTabset = (url) => TabsetService.tabsetsFor(url).length > 0;
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$1, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(_).filter(unref(bookmarksStore).bookmarksForFolder, (bm) => !bm.chromeBookmark.url), (bm) => {
            return openBlock(), createElementBlock("div", {
              key: bm.id,
              draggable: "true",
              onDragstart: ($event) => startDrag($event, bm),
              class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs"
            }, [
              createVNode(QCard, {
                class: "my-card",
                flat: "",
                bordered: "",
                style: normalizeStyle(cardStyle(bm)),
                onMouseover: ($event) => setInfo(bm),
                onClick: ($event) => selectBookmark(bm)
              }, {
                default: withCtx(() => [
                  createVNode(QCardSection, { class: "q-pt-xs cursor-pointer bg-amber-2 text-black" }, {
                    default: withCtx(() => {
                      var _a;
                      return [
                        createBaseVNode("div", _hoisted_3$1, [
                          createBaseVNode("div", _hoisted_4$1, [
                            createVNode(QIcon, {
                              name: "folder_open",
                              size: "24px"
                            })
                          ]),
                          createBaseVNode("div", _hoisted_5$1, [
                            createTextVNode(toDisplayString(nameOrTitle(bm)) + " ", 1),
                            createVNode(QPopupEdit, {
                              "model-value": dynamicNameOrTitleModel(bm),
                              "onUpdate:modelValue": (val) => setCustomTitle(bm, val)
                            }, {
                              default: withCtx((scope) => [
                                createVNode(QInput, {
                                  modelValue: scope.value,
                                  "onUpdate:modelValue": ($event) => scope.value = $event,
                                  dense: "",
                                  autofocus: "",
                                  counter: "",
                                  onKeyup: withKeys(scope.set, ["enter"])
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "onKeyup"])
                              ]),
                              _: 2
                            }, 1032, ["model-value", "onUpdate:modelValue"]),
                            createVNode(QTooltip, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(bm.chromeBookmark.title), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ])
                        ]),
                        createBaseVNode("div", _hoisted_6$1, toDisplayString((_a = bm.chromeBookmark) == null ? void 0 : _a.dateAdded), 1)
                      ];
                    }),
                    _: 2
                  }, 1024),
                  createVNode(QCardActions, { align: "right" })
                ]),
                _: 2
              }, 1032, ["style", "onMouseover", "onClick"])
            ], 40, _hoisted_2$1);
          }), 128))
        ]),
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("div", _hoisted_8, [
                createVNode(QToolbarTitle)
              ]),
              createBaseVNode("div", _hoisted_9, [
                createVNode(QBtn, {
                  flat: "",
                  dense: "",
                  icon: "upload_file",
                  color: "positive",
                  label: unref($q).screen.gt.sm ? "Import as Tabset..." : "",
                  class: "q-mr-md",
                  onClick: importBookmarks
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("Import these bookmarks as Tabset")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["label"])
              ])
            ])
          ]),
          _: 1
        }),
        createBaseVNode("div", _hoisted_10, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(_).filter(unref(bookmarksStore).bookmarksForFolder, (bm) => bm.chromeBookmark.url), (bm) => {
            return openBlock(), createElementBlock("div", {
              key: bm.id,
              draggable: "true",
              onDragstart: ($event) => startDrag($event, bm),
              class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs"
            }, [
              createVNode(QCard, {
                class: "my-card",
                flat: "",
                bordered: "",
                style: normalizeStyle(cardStyle(bm)),
                onMouseover: ($event) => setInfo(bm),
                onClick: ($event) => _ctx.selectTab(bm)
              }, {
                default: withCtx(() => [
                  createVNode(QCardSection, { class: "q-pt-xs cursor-pointer bg-amber-1 text-black" }, {
                    default: withCtx(() => {
                      var _a;
                      return [
                        createBaseVNode("div", _hoisted_12, [
                          createBaseVNode("div", _hoisted_13, [
                            createVNode(QIcon, {
                              name: "bookmark_border",
                              size: "24px"
                            })
                          ]),
                          createBaseVNode("div", _hoisted_14, [
                            createTextVNode(toDisplayString(nameOrTitle(bm)) + " ", 1),
                            createVNode(QPopupEdit, {
                              "model-value": dynamicNameOrTitleModel(bm),
                              "onUpdate:modelValue": (val) => setCustomTitle(bm, val)
                            }, {
                              default: withCtx((scope) => [
                                createVNode(QInput, {
                                  modelValue: scope.value,
                                  "onUpdate:modelValue": ($event) => scope.value = $event,
                                  dense: "",
                                  autofocus: "",
                                  counter: "",
                                  onKeyup: withKeys(scope.set, ["enter"])
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "onKeyup"])
                              ]),
                              _: 2
                            }, 1032, ["model-value", "onUpdate:modelValue"]),
                            createVNode(QTooltip, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(bm.chromeBookmark.title), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          existsInTabset(bm.chromeBookmark.url) ? (openBlock(), createBlock(QBadge, {
                            key: 0,
                            color: "warning",
                            floating: ""
                          }, {
                            default: withCtx(() => [
                              createVNode(QIcon, {
                                name: "tab",
                                size: "16px",
                                color: "white"
                              }, {
                                default: withCtx(() => [
                                  createVNode(QTooltip, null, {
                                    default: withCtx(() => [
                                      createTextVNode("This bookmark is saved in a tabset")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ]),
                        createBaseVNode("div", _hoisted_15, [
                          createTextVNode(toDisplayString((_a = bm.chromeBookmark) == null ? void 0 : _a.url.replace("https://www.", "").replace("https://", "")) + " ", 1),
                          createVNode(QIcon, {
                            name: "launch",
                            color: "secondary",
                            onClick: withModifiers(($event) => {
                              var _a2;
                              return unref(Navigation).openOrCreateTab((_a2 = bm.chromeBookmark) == null ? void 0 : _a2.url);
                            }, ["stop"])
                          }, null, 8, ["onClick"]),
                          createVNode(QTooltip, null, {
                            default: withCtx(() => {
                              var _a2;
                              return [
                                createTextVNode(toDisplayString((_a2 = bm.chromeBookmark) == null ? void 0 : _a2.url), 1)
                              ];
                            }),
                            _: 2
                          }, 1024)
                        ])
                      ];
                    }),
                    _: 2
                  }, 1024),
                  createVNode(QCardActions, { align: "right" }, {
                    default: withCtx(() => [
                      createVNode(QBtn, {
                        flat: "",
                        round: "",
                        color: "red",
                        size: "11px",
                        icon: "delete_outline",
                        onClick: withModifiers(($event) => deleteBookmark(bm), ["stop"])
                      }, {
                        default: withCtx(() => [
                          createVNode(QTooltip, null, {
                            default: withCtx(() => [
                              createTextVNode("Delete this bookmark")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["onClick"])
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 2
              }, 1032, ["style", "onMouseover", "onClick"])
            ], 40, _hoisted_11);
          }), 128))
        ])
      ], 64);
    };
  }
});
var BookmarkCards = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-77e1e9c1"]]);
class Bookmark {
  constructor(id, chromeBookmark) {
    __publicField(this, "created");
    __publicField(this, "updated");
    __publicField(this, "lastActive");
    __publicField(this, "activatedCount");
    __publicField(this, "lastLoaded");
    __publicField(this, "loadedCount");
    __publicField(this, "chromeBookmark");
    __publicField(this, "selected", false);
    __publicField(this, "name");
    this.id = id;
    this.created = new Date().getTime();
    this.updated = new Date().getTime();
    this.lastActive = 0;
    this.activatedCount = 0;
    this.lastLoaded = 0;
    this.loadedCount = 0;
    this.chromeBookmark = chromeBookmark;
    this.name = void 0;
  }
}
const _hoisted_1 = { class: "row fit" };
const _hoisted_2 = { class: "col-xs-12 col-md-7" };
const _hoisted_3 = { class: "row justify-start items-baseline" };
const _hoisted_4 = { class: "col-12" };
const _hoisted_5 = { class: "text-primary" };
const _hoisted_6 = { class: "col-xs-12 col-md-5 text-right" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Bookmarks",
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    useQuasar().localStorage;
    useTabsStore();
    const bookmarksStore = useBookmarksStore();
    const $q = useQuasar();
    const bookmarksForFolder = ref([]);
    const bookmarksForBreadcrumb = ref([]);
    const bookmarkId = ref("");
    async function getParentChain(bookmarkId2, chain = []) {
      const results = await chrome.bookmarks.get(bookmarkId2);
      if (results && results[0]) {
        chain.push(new Bookmark(uid(), results[0]));
        const parentId = results[0].parentId;
        if (parentId && parentId !== "0") {
          chain = getParentChain(parentId, chain);
        }
      }
      return Promise.resolve(chain);
    }
    watchEffect(() => {
      bookmarkId.value = route.params.id;
      if (bookmarkId.value) {
        chrome.bookmarks.get(bookmarkId.value, (results) => {
          if (results && results[0]) {
            bookmarksStore.currentBookmark = new Bookmark(uid(), results[0]);
            getParentChain(bookmarkId.value).then((res) => {
              bookmarksForBreadcrumb.value = res.reverse();
            });
          }
        });
        chrome.bookmarks.getChildren(bookmarkId.value, (bms) => {
          bookmarksForFolder.value = _.map(bms, (l) => new Bookmark(uid(), l));
          useBookmarksStore().bookmarksForFolder = bookmarksForFolder.value;
        });
      }
    });
    const deleteBookmarkFolder = () => {
      $q.dialog({
        title: "Please Confirm Deleting of Bookmarks Folder",
        message: "Do you really want to delete this folder (and potentially all its subfolders and bookmarks)? This cannot be undone.",
        cancel: true,
        persistent: true
      }).onOk(() => {
        const folderId = bookmarksStore.currentBookmark.chromeBookmark.id;
        const parentId = bookmarksStore.currentBookmark.chromeBookmark.parentId;
        console.log("deleting", folderId);
        chrome.bookmarks.removeTree(bookmarksStore.currentBookmark.chromeBookmark.id);
        if (parentId) {
          router.push("/bookmarks/" + parentId);
        }
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          createVNode(QToolbar, { class: "text-primary" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createBaseVNode("div", _hoisted_2, [
                  createVNode(QToolbarTitle, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_3, [
                        createBaseVNode("div", _hoisted_4, [
                          createBaseVNode("span", _hoisted_5, [
                            createVNode(QBreadcrumbs, { separator: ">" }, {
                              default: withCtx(() => [
                                createVNode(QBreadcrumbsEl, { label: "Bookmarks" }),
                                (openBlock(true), createElementBlock(Fragment, null, renderList(bookmarksForBreadcrumb.value, (bm) => {
                                  return openBlock(), createBlock(QBreadcrumbsEl, {
                                    label: bm.chromeBookmark.title,
                                    class: "cursor-pointer",
                                    onClick: ($event) => unref(router).push("/bookmarks/" + bm.chromeBookmark.id)
                                  }, null, 8, ["label", "onClick"]);
                                }), 256))
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("div", _hoisted_6, [
                  createVNode(QBtn, {
                    flat: "",
                    dense: "",
                    icon: "delete_outline",
                    color: "negative",
                    label: unref($q).screen.gt.sm ? "Delete Folder..." : "",
                    class: "q-mr-md",
                    onClick: deleteBookmarkFolder
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Delete this Bookmark")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])
                ])
              ])
            ]),
            _: 1
          }),
          createVNode(QCard, null, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  createVNode(BookmarkCards)
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_sfc_main$3)
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
