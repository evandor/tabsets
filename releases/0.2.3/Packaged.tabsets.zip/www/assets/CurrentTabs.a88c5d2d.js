import { Q as QPage } from "./QPage.d2025984.js";
import { bx as shallowReactive, n as createComponent, bg as useRouterLinkProps, ah as useModelToggleProps, ai as useDarkProps, aj as useModelToggleEmits, ak as useDark, r as ref, aR as uid, am as useModelToggle, c as computed, w as watch, v as onBeforeUnmount, h, g as getCurrentInstance, aZ as QSeparator, ap as withDirectives, aV as vShow, q as hSlot, a1 as QIcon, a7 as stopAndPrevent, I as defineComponent, j as openBlock, k as createBlock, l as withCtx, aA as createTextVNode, aC as toDisplayString, d as createVNode, aF as QCardSection, M as createBaseVNode, aG as QInput, aH as withKeys, aD as withModifiers, ay as unref, aE as Navigation, aJ as QBtn, aN as normalizeStyle, aK as QCard, ax as TabsetService, au as useNotificationsStore, a_ as MHtmlService, K as useQuasar, J as useTabsStore, az as createElementBlock, F as Fragment, aM as renderList, aP as _, av as useFeatureTogglesStore, aB as createCommentVNode, aU as QCheckbox, by as MAX_TABS_TO_SHOW, aI as QCardActions, bz as pushScopeId, bA as popScopeId, a8 as QDialog, L as useRouter, a$ as QRadio, b1 as useRoute, bB as useTabGroupsStore, aw as watchEffect, aO as Ripple, m as resolveComponent } from "./index.ac7851bc.js";
import { b as QItem, a as QItemLabel, Q as QItemSection, c as QList } from "./QList.06a62e31.js";
import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { Q as QPopupEdit } from "./QPopupEdit.065c1278.js";
import { a as QSlideTransition, V as VueDraggableNext, Q as QBanner } from "./vue-draggable-next.esm-bundler.d5869de7.js";
import { a as QToolbarTitle, Q as QToolbar } from "./QToolbar.8ddc4c0b.js";
import { Q as QImg } from "./QImg.0869baf7.js";
import { _ as _export_sfc } from "./plugin-vue_export-helper.21dcd24c.js";
import { a as QBadge } from "./QMenu.39c979c3.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
import { _ as _sfc_main$9 } from "./Fab.577affc8.js";
import "./NewTabsetDialog.35dde97f.js";
import "./ReindexDialog.ccfa929c.js";
const itemGroups = shallowReactive({});
const LINK_PROPS = Object.keys(useRouterLinkProps);
var QExpansionItem = createComponent({
  name: "QExpansionItem",
  props: {
    ...useRouterLinkProps,
    ...useModelToggleProps,
    ...useDarkProps,
    icon: String,
    label: String,
    labelLines: [Number, String],
    caption: String,
    captionLines: [Number, String],
    dense: Boolean,
    toggleAriaLabel: String,
    expandIcon: String,
    expandedIcon: String,
    expandIconClass: [Array, String, Object],
    duration: Number,
    headerInsetLevel: Number,
    contentInsetLevel: Number,
    expandSeparator: Boolean,
    defaultOpened: Boolean,
    hideExpandIcon: Boolean,
    expandIconToggle: Boolean,
    switchToggleSide: Boolean,
    denseToggle: Boolean,
    group: String,
    popup: Boolean,
    headerStyle: [Array, String, Object],
    headerClass: [Array, String, Object]
  },
  emits: [
    ...useModelToggleEmits,
    "click",
    "afterShow",
    "afterHide"
  ],
  setup(props, { slots, emit }) {
    const { proxy: { $q } } = getCurrentInstance();
    const isDark = useDark(props, $q);
    const showing = ref(
      props.modelValue !== null ? props.modelValue : props.defaultOpened
    );
    const blurTargetRef = ref(null);
    const targetUid = uid();
    const { show, hide, toggle } = useModelToggle({ showing });
    let uniqueId, exitGroup;
    const classes = computed(
      () => `q-expansion-item q-item-type q-expansion-item--${showing.value === true ? "expanded" : "collapsed"} q-expansion-item--${props.popup === true ? "popup" : "standard"}`
    );
    const contentStyle = computed(() => {
      if (props.contentInsetLevel === void 0) {
        return null;
      }
      const dir = $q.lang.rtl === true ? "Right" : "Left";
      return {
        ["padding" + dir]: props.contentInsetLevel * 56 + "px"
      };
    });
    const hasLink = computed(
      () => props.disable !== true && (props.href !== void 0 || props.to !== void 0 && props.to !== null && props.to !== "")
    );
    const linkProps = computed(() => {
      const acc = {};
      LINK_PROPS.forEach((key) => {
        acc[key] = props[key];
      });
      return acc;
    });
    const isClickable = computed(
      () => hasLink.value === true || props.expandIconToggle !== true
    );
    const expansionIcon = computed(() => props.expandedIcon !== void 0 && showing.value === true ? props.expandedIcon : props.expandIcon || $q.iconSet.expansionItem[props.denseToggle === true ? "denseIcon" : "icon"]);
    const activeToggleIcon = computed(
      () => props.disable !== true && (hasLink.value === true || props.expandIconToggle === true)
    );
    const headerSlotScope = computed(() => ({
      expanded: showing.value === true,
      detailsId: props.targetUid,
      toggle,
      show,
      hide
    }));
    const toggleAriaAttrs = computed(() => {
      const toggleAriaLabel = props.toggleAriaLabel !== void 0 ? props.toggleAriaLabel : $q.lang.label[showing.value === true ? "collapse" : "expand"](props.label);
      return {
        role: "button",
        "aria-expanded": showing.value === true ? "true" : "false",
        "aria-owns": targetUid,
        "aria-controls": targetUid,
        "aria-label": toggleAriaLabel
      };
    });
    watch(() => props.group, (name) => {
      exitGroup !== void 0 && exitGroup();
      name !== void 0 && enterGroup();
    });
    function onHeaderClick(e) {
      hasLink.value !== true && toggle(e);
      emit("click", e);
    }
    function toggleIconKeyboard(e) {
      e.keyCode === 13 && toggleIcon(e, true);
    }
    function toggleIcon(e, keyboard) {
      keyboard !== true && blurTargetRef.value !== null && blurTargetRef.value.focus();
      toggle(e);
      stopAndPrevent(e);
    }
    function onShow() {
      emit("afterShow");
    }
    function onHide() {
      emit("afterHide");
    }
    function enterGroup() {
      if (uniqueId === void 0) {
        uniqueId = uid();
      }
      if (showing.value === true) {
        itemGroups[props.group] = uniqueId;
      }
      const show2 = watch(showing, (val) => {
        if (val === true) {
          itemGroups[props.group] = uniqueId;
        } else if (itemGroups[props.group] === uniqueId) {
          delete itemGroups[props.group];
        }
      });
      const group = watch(
        () => itemGroups[props.group],
        (val, oldVal) => {
          if (oldVal === uniqueId && val !== void 0 && val !== uniqueId) {
            hide();
          }
        }
      );
      exitGroup = () => {
        show2();
        group();
        if (itemGroups[props.group] === uniqueId) {
          delete itemGroups[props.group];
        }
        exitGroup = void 0;
      };
    }
    function getToggleIcon() {
      const data = {
        class: [
          `q-focusable relative-position cursor-pointer${props.denseToggle === true && props.switchToggleSide === true ? " items-end" : ""}`,
          props.expandIconClass
        ],
        side: props.switchToggleSide !== true,
        avatar: props.switchToggleSide
      };
      const child = [
        h(QIcon, {
          class: "q-expansion-item__toggle-icon" + (props.expandedIcon === void 0 && showing.value === true ? " q-expansion-item__toggle-icon--rotated" : ""),
          name: expansionIcon.value
        })
      ];
      if (activeToggleIcon.value === true) {
        Object.assign(data, {
          tabindex: 0,
          ...toggleAriaAttrs.value,
          onClick: toggleIcon,
          onKeyup: toggleIconKeyboard
        });
        child.unshift(
          h("div", {
            ref: blurTargetRef,
            class: "q-expansion-item__toggle-focus q-icon q-focus-helper q-focus-helper--rounded",
            tabindex: -1
          })
        );
      }
      return h(QItemSection, data, () => child);
    }
    function getHeaderChild() {
      let child;
      if (slots.header !== void 0) {
        child = [].concat(slots.header(headerSlotScope.value));
      } else {
        child = [
          h(QItemSection, () => [
            h(QItemLabel, { lines: props.labelLines }, () => props.label || ""),
            props.caption ? h(QItemLabel, { lines: props.captionLines, caption: true }, () => props.caption) : null
          ])
        ];
        props.icon && child[props.switchToggleSide === true ? "push" : "unshift"](
          h(QItemSection, {
            side: props.switchToggleSide === true,
            avatar: props.switchToggleSide !== true
          }, () => h(QIcon, { name: props.icon }))
        );
      }
      if (props.disable !== true && props.hideExpandIcon !== true) {
        child[props.switchToggleSide === true ? "unshift" : "push"](
          getToggleIcon()
        );
      }
      return child;
    }
    function getHeader() {
      const data = {
        ref: "item",
        style: props.headerStyle,
        class: props.headerClass,
        dark: isDark.value,
        disable: props.disable,
        dense: props.dense,
        insetLevel: props.headerInsetLevel
      };
      if (isClickable.value === true) {
        data.clickable = true;
        data.onClick = onHeaderClick;
        Object.assign(
          data,
          hasLink.value === true ? linkProps.value : toggleAriaAttrs.value
        );
      }
      return h(QItem, data, getHeaderChild);
    }
    function getTransitionChild() {
      return withDirectives(
        h("div", {
          key: "e-content",
          class: "q-expansion-item__content relative-position",
          style: contentStyle.value,
          id: targetUid
        }, hSlot(slots.default)),
        [[
          vShow,
          showing.value
        ]]
      );
    }
    function getContent() {
      const node = [
        getHeader(),
        h(QSlideTransition, {
          duration: props.duration,
          onShow,
          onHide
        }, getTransitionChild)
      ];
      if (props.expandSeparator === true) {
        node.push(
          h(QSeparator, {
            class: "q-expansion-item__border q-expansion-item__border--top absolute-top",
            dark: isDark.value
          }),
          h(QSeparator, {
            class: "q-expansion-item__border q-expansion-item__border--bottom absolute-bottom",
            dark: isDark.value
          })
        );
      }
      return node;
    }
    props.group !== void 0 && enterGroup();
    onBeforeUnmount(() => {
      exitGroup !== void 0 && exitGroup();
    });
    return () => h("div", { class: classes.value }, [
      h("div", { class: "q-expansion-item__container relative-position" }, getContent())
    ]);
  }
});
const _hoisted_1$6 = { class: "row items-baseline" };
const _hoisted_2$6 = { class: "col-2" };
const _hoisted_3$5 = { class: "col-10 text-subtitle1 ellipsis" };
const _hoisted_4$4 = { class: "row fit" };
const _hoisted_5$4 = { class: "col-6" };
const _hoisted_6$4 = { class: "col-6 text-right" };
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "TabCardWidget",
  props: {
    tab: {
      type: Object,
      required: true
    },
    highlightUrl: {
      type: String,
      required: false
    }
  },
  emits: ["sendCaption"],
  setup(__props, { emit: emits }) {
    const props = __props;
    const thumbnails = ref(/* @__PURE__ */ new Map());
    const thumbnailFor = (tab) => {
      const key = btoa(tab.chromeTab.url || "");
      return thumbnails.value.get(key) || "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=";
    };
    const loadThumbnail = (tab) => {
      TabsetService.getThumbnailFor(tab).then((data) => {
        const key = btoa(tab.chromeTab.url || "");
        if (data && data.thumbnail) {
          thumbnails.value.set(key, data.thumbnail);
        }
      }).catch((err) => console.log("err", err));
    };
    function cardStyle(tab) {
      let borderColor = "";
      if (isOpen(tab)) {
        borderColor = "border-color:#8f8f8f";
      }
      if (tab == null ? void 0 : tab.selected) {
        borderColor = "border-color:#000066";
      }
      let background = "";
      if (tab == null ? void 0 : tab.isDuplicate) {
        background = "background: radial-gradient(circle, #FFFFFF 0%, #FFECB3 100%)";
      } else if ((tab == null ? void 0 : tab.chromeTab.url) === props.highlightUrl) {
        background = "background: radial-gradient(circle, #FFBF46 0%, #FFBF46 100%)";
      }
      return `${borderColor};${background}`;
    }
    function isOpen(tab) {
      var _a;
      return TabsetService.isOpen(((_a = tab == null ? void 0 : tab.chromeTab) == null ? void 0 : _a.url) || "");
    }
    const setInfo = (tab) => {
      var _a;
      const parts = (((_a = tab.chromeTab) == null ? void 0 : _a.url) || "").split("?");
      if (parts.length > 1) {
        emits("sendCaption", parts[0] + "[... params omitted....]");
      } else if (parts.length === 1) {
        emits("sendCaption", parts[0].toString());
      }
    };
    const setCustomTitle = (tab, newValue) => {
      console.log(" -> ", newValue);
      TabsetService.setCustomTitle(tab, newValue);
    };
    const selectTab = (tab) => {
      TabsetService.setOnlySelectedTab(tab);
      const notificationStore = useNotificationsStore();
      notificationStore.setSelectedTab(tab);
    };
    const getFaviconUrl = (chromeTab) => {
      if (chromeTab && chromeTab.favIconUrl && !chromeTab.favIconUrl.startsWith("chrome")) {
        return chromeTab.favIconUrl;
      }
      return "";
    };
    const nameOrTitle = (tab) => {
      var _a;
      return tab.name ? tab.name : (_a = tab.chromeTab) == null ? void 0 : _a.title;
    };
    const dynamicNameOrTitleModel = (tab) => {
      var _a;
      return tab.name ? tab.name : (_a = tab.chromeTab) == null ? void 0 : _a.title;
    };
    function closeTab(tab) {
      Navigation.closeTab(tab);
    }
    const saveTab = (tab) => {
      if (tab.chromeTab.id) {
        console.log("capturing", tab.chromeTab);
        chrome.pageCapture.saveAsMHTML(
          { tabId: tab.chromeTab.id },
          (html) => {
            MHtmlService.saveMHtml(tab, html);
          }
        );
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        class: "my-card",
        flat: "",
        bordered: "",
        style: normalizeStyle(cardStyle(__props.tab)),
        onMouseover: _cache[4] || (_cache[4] = ($event) => setInfo(__props.tab)),
        onClick: _cache[5] || (_cache[5] = ($event) => selectTab(__props.tab))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(loadThumbnail(__props.tab)) + " ", 1),
          createVNode(QCardSection, {
            class: "q-pt-xs cursor-pointer bg-primary text-white",
            style: { "width": "100%" }
          }, {
            default: withCtx(() => {
              var _a;
              return [
                createBaseVNode("div", _hoisted_1$6, [
                  createBaseVNode("div", _hoisted_2$6, [
                    createVNode(QImg, {
                      class: "rounded-borders",
                      width: "24px",
                      height: "24px",
                      src: getFaviconUrl(__props.tab.chromeTab)
                    }, {
                      default: withCtx(() => [
                        createVNode(QTooltip, null, {
                          default: withCtx(() => {
                            var _a2;
                            return [
                              createTextVNode(toDisplayString((_a2 = __props.tab.chromeTab) == null ? void 0 : _a2.id) + " / " + toDisplayString(__props.tab.id), 1)
                            ];
                          }),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["src"])
                  ]),
                  createBaseVNode("div", _hoisted_3$5, [
                    createTextVNode(toDisplayString(nameOrTitle(__props.tab)) + " ", 1),
                    createVNode(QPopupEdit, {
                      "model-value": dynamicNameOrTitleModel(__props.tab),
                      "onUpdate:modelValue": _cache[0] || (_cache[0] = (val) => setCustomTitle(__props.tab, val))
                    }, {
                      default: withCtx((scope) => [
                        createVNode(QInput, {
                          modelValue: scope.value,
                          "onUpdate:modelValue": ($event) => scope.value = $event,
                          dense: "",
                          autofocus: "",
                          counter: "",
                          onKeyup: withKeys(scope.set, ["enter"])
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "onKeyup"])
                      ]),
                      _: 1
                    }, 8, ["model-value"]),
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(__props.tab.chromeTab.title), 1)
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createBaseVNode("div", {
                  class: "text-subtitle2 ellipsis text-secondary",
                  onClick: _cache[1] || (_cache[1] = withModifiers(($event) => {
                    var _a2;
                    return unref(Navigation).openOrCreateTab((_a2 = __props.tab.chromeTab) == null ? void 0 : _a2.url);
                  }, ["stop"]))
                }, [
                  createTextVNode(toDisplayString((_a = __props.tab.chromeTab) == null ? void 0 : _a.url.replace("https://www.", "").replace("https://", "")) + " ", 1),
                  createVNode(QIcon, {
                    name: "launch",
                    color: "secondary"
                  }),
                  createVNode(QTooltip, null, {
                    default: withCtx(() => {
                      var _a2;
                      return [
                        createTextVNode(toDisplayString((_a2 = __props.tab.chromeTab) == null ? void 0 : _a2.url), 1)
                      ];
                    }),
                    _: 1
                  })
                ])
              ];
            }),
            _: 1
          }),
          createVNode(QCardSection, { class: "q-ma-none q-pa-xs" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_4$4, [
                createBaseVNode("div", _hoisted_5$4, [
                  createVNode(QImg, {
                    src: thumbnailFor(__props.tab),
                    width: "48px",
                    height: "32px",
                    "no-spinner": "",
                    style: { "border": "1px solid #efefef", "border-right": "3px" }
                  }, null, 8, ["src"])
                ]),
                createBaseVNode("div", _hoisted_6$4, [
                  createVNode(QBtn, {
                    flat: "",
                    round: "",
                    color: "positive",
                    size: "11px",
                    icon: "save",
                    onClick: _cache[2] || (_cache[2] = withModifiers(($event) => saveTab(__props.tab), ["stop"])),
                    disabled: !isOpen(__props.tab)
                  }, {
                    default: withCtx(() => [
                      isOpen(__props.tab) ? (openBlock(), createBlock(QTooltip, { key: 0 }, {
                        default: withCtx(() => [
                          createTextVNode("Save this tab")
                        ]),
                        _: 1
                      })) : (openBlock(), createBlock(QTooltip, { key: 1 }, {
                        default: withCtx(() => [
                          createTextVNode("The tab must be open if you want to save it. Click on the link and come back here to save it.")
                        ]),
                        _: 1
                      }))
                    ]),
                    _: 1
                  }, 8, ["disabled"]),
                  createVNode(QBtn, {
                    flat: "",
                    round: "",
                    color: "red",
                    size: "11px",
                    icon: "delete_outline",
                    onClick: _cache[3] || (_cache[3] = withModifiers(($event) => closeTab(__props.tab), ["stop"]))
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Delete this tab from this list")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ])
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["style"]);
    };
  }
});
var Tabcards_vue_vue_type_style_index_0_scoped_true_lang = "";
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "Tabcards",
  props: {
    tabs: {
      type: Array,
      required: true
    },
    group: {
      type: String,
      required: true
    },
    highlightUrl: {
      type: String,
      required: false
    }
  },
  setup(__props) {
    const props = __props;
    const $q = useQuasar();
    const tabsStore = useTabsStore();
    ref(/* @__PURE__ */ new Map());
    const tabAsTab = (tab) => tab;
    function adjustIndex(element, tabs) {
      console.log("filtered", tabs);
      if (element.newIndex === 0) {
        console.log(" 0 - searching for ", tabs[0].id);
        return _.findIndex(tabsStore.getCurrentTabs, (t) => t.id === tabs[0].id);
      } else {
        console.log(" 1 - searching for ", tabs[element.newIndex - 1].id);
        return 1 + _.findIndex(tabsStore.getCurrentTabs, (t) => t.id === tabs[element.newIndex - 1].id);
      }
    }
    const handleDragAndDrop = (event) => {
      console.log("event", event);
      const { moved, added } = event;
      if (moved) {
        console.log("d&d tabs moved", moved.element.id, moved.newIndex, props.group);
        let useIndex = moved.newIndex;
        switch (props.group) {
          case "otherTabs":
            const unpinnedNoGroup = _.filter(tabsStore.getCurrentTabs, (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1);
            if (unpinnedNoGroup.length > 0) {
              useIndex = adjustIndex(moved, unpinnedNoGroup);
            }
            break;
          case "pinnedTabs":
            const filteredTabs = _.filter(tabsStore.getCurrentTabs, (t) => t.chromeTab.pinned);
            if (filteredTabs.length > 0) {
              useIndex = adjustIndex(moved, filteredTabs);
            }
            break;
          default:
            if (props.group.startsWith("groupedTabs_")) {
              const groupId = props.group.split("_")[1];
              const filteredTabs2 = _.filter(tabsStore.getCurrentTabs, (t) => t.chromeTab.groupId === parseInt(groupId));
              if (filteredTabs2.length > 0) {
                useIndex = adjustIndex(moved, filteredTabs2);
              }
            }
            break;
        }
        TabsetService.moveTo(moved.element.id, useIndex);
      }
      if (added) {
        console.log("d&d tabs added", added.element.id, added.newIndex, props.group);
        console.log("tabs", tabsStore.getCurrentTabs);
        const exists = _.findIndex(tabsStore.getCurrentTabs, (t) => t.chromeTab.url === added.element.chromeTab.url) >= 0;
        let useIndex = added.newIndex;
        switch (props.group) {
          case "otherTabs":
            const unpinnedNoGroup = _.filter(tabsStore.getCurrentTabs, (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1);
            if (unpinnedNoGroup.length > 0) {
              useIndex = adjustIndex(added, unpinnedNoGroup);
            }
            added.element.chromeTab.groupId = -1;
            added.element.chromeTab.pinned = false;
            break;
          case "pinnedTabs":
            const filteredTabs = _.filter(tabsStore.getCurrentTabs, (t) => t.chromeTab.pinned);
            if (filteredTabs.length > 0) {
              useIndex = adjustIndex(added, filteredTabs);
            }
            added.element.chromeTab.pinned = true;
            added.element.chromeTab.groupId = -1;
            break;
          default:
            if (props.group.startsWith("groupedTabs_")) {
              const groupId = props.group.split("_")[1];
              console.log("got group id", groupId);
              const filteredTabs2 = _.filter(tabsStore.getCurrentTabs, (t) => t.chromeTab.groupId === parseInt(groupId));
              if (filteredTabs2.length > 0) {
                useIndex = adjustIndex(added, filteredTabs2);
              }
              added.element.chromeTab.groupId = parseInt(groupId);
            }
            break;
        }
        if (!exists) {
          if (useIndex !== void 0 && useIndex >= 0) {
            tabsStore.getCurrentTabs.splice(useIndex, 0, added.element);
          } else {
            tabsStore.getCurrentTabs.push(added.element);
          }
        } else {
          const oldIndex = _.findIndex(tabsStore.getCurrentTabs, (t) => t.id === added.element.id);
          if (oldIndex >= 0) {
            const tab = tabsStore.getCurrentTabs.splice(oldIndex, 1)[0];
            tabsStore.getCurrentTabs.splice(useIndex, 0, tab);
          }
        }
        TabsetService.saveCurrentTabset().then(() => {
          $q.notify({
            message: exists ? "The tab has been moved" : "The tab has been added",
            type: "positive"
          });
        }).catch((err) => {
          console.log("err", err);
          $q.notify({
            message: "The tab already exists in this tabset",
            type: "negative"
          });
        });
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(VueDraggableNext), {
        key: props.group,
        class: "row items-start",
        list: props.tabs,
        group: { name: "tabs", pull: "clone" },
        onChange: handleDragAndDrop
      }, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(props.tabs, (tab) => {
            return openBlock(), createElementBlock("div", {
              class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs",
              key: props.group + "_" + tab.id
            }, [
              (openBlock(), createBlock(_sfc_main$8, {
                key: props.group + "__" + tab.id,
                tab: tabAsTab(tab),
                highlightUrl: __props.highlightUrl
              }, null, 8, ["tab", "highlightUrl"]))
            ]);
          }), 128))
        ]),
        _: 1
      }, 8, ["list"]);
    };
  }
});
var Tabcards = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-37f2632c"]]);
var TabcardsPending_vue_vue_type_style_index_0_scoped_true_lang = "";
const _withScopeId = (n) => (pushScopeId("data-v-ed562f88"), n = n(), popScopeId(), n);
const _hoisted_1$5 = { class: "row items-start" };
const _hoisted_2$5 = { class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs" };
const _hoisted_3$4 = { class: "row items-baseline" };
const _hoisted_4$3 = { class: "col-2" };
const _hoisted_5$3 = { class: "col-10 text-subtitle1 text-black ellipsis" };
const _hoisted_6$3 = { class: "text-subtitle2 ellipsis text-secondary" };
const _hoisted_7$3 = { class: "row fit" };
const _hoisted_8$3 = { class: "col-6" };
const _hoisted_9$3 = { class: "col-6 text-right" };
const _hoisted_10$3 = { class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs" };
const _hoisted_11$3 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "row items-baseline" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col-2 text-body1" }, " >>> "),
  /* @__PURE__ */ createBaseVNode("div", { class: "col-10 text-subtitle1 ellipsis" }, " more tabs... ")
], -1));
const _hoisted_12$3 = { class: "text-subtitle2 ellipsis text-secondary" };
const _hoisted_13$3 = { class: "row fit" };
const _hoisted_14$3 = { class: "col-12 text-right" };
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "TabcardsPending",
  props: {
    tabs: {
      type: Array,
      required: true
    }
  },
  emits: ["sendCaption", "selectionChanged"],
  setup(__props, { emit: emits }) {
    const props = __props;
    const featureToggles = useFeatureTogglesStore();
    function closeTab(tab) {
      Navigation.closeTab(tab);
    }
    function ignoreTab(tab) {
      console.log("ignoring tab", tab);
      TabsetService.ignoreTab(tab);
      Navigation.closeTab(tab);
    }
    function saveTab(tab) {
      console.log("saving tab", tab);
      TabsetService.saveToCurrentTabset(tab);
    }
    function cardStyle(tab) {
      let borderColor = "";
      if (isOpen(tab)) {
        borderColor = "border-color:#8f8f8f";
      }
      if (tab.selected) {
        borderColor = "border-color:#000066";
      }
      let background = "";
      if (tab.isDuplicate) {
        background = "background: radial-gradient(circle, #FFFFFF 0%, #FFECB3 100%)";
      }
      return `${borderColor};${background}`;
    }
    function isOpen(tab) {
      var _a;
      return TabsetService.isOpen(((_a = tab == null ? void 0 : tab.chromeTab) == null ? void 0 : _a.url) || "");
    }
    const setInfo = (tab) => {
      var _a;
      const parts = (((_a = tab.chromeTab) == null ? void 0 : _a.url) || "").split("?");
      if (parts.length > 1) {
        emits("sendCaption", parts[0] + "[... params omitted....]");
      } else if (parts.length === 1) {
        emits("sendCaption", parts[0].toString());
      }
    };
    const selectTab = (tab) => {
      TabsetService.setOnlySelectedTab(tab);
      const notificationStore = useNotificationsStore();
      notificationStore.setSelectedTab(tab);
    };
    const setCustomTitle = (tab, newValue) => {
      console.log(" -> ", newValue);
      TabsetService.setCustomTitle(tab, newValue);
    };
    const nameOrTitle = (tab) => {
      var _a;
      return tab.name ? tab.name : (_a = tab.chromeTab) == null ? void 0 : _a.title;
    };
    const dynamicNameOrTitleModel = (tab) => {
      var _a;
      return tab.name ? tab.name : (_a = tab.chromeTab) == null ? void 0 : _a.title;
    };
    const selectionChanged = (val) => emits("selectionChanged", val);
    const tabsWithLimit = () => {
      const allTabs = props.tabs;
      if (allTabs.length > MAX_TABS_TO_SHOW) {
        return allTabs.slice(0, MAX_TABS_TO_SHOW - 1);
      }
      return allTabs;
    };
    const getFaviconUrl = (chromeTab) => {
      if (chromeTab && chromeTab.favIconUrl && !chromeTab.favIconUrl.startsWith("chrome")) {
        return chromeTab.favIconUrl;
      }
      return "";
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$5, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(tabsWithLimit(), (tab) => {
          return openBlock(), createElementBlock("div", _hoisted_2$5, [
            createVNode(QCard, {
              class: "my-card",
              bordered: "",
              style: normalizeStyle(cardStyle(tab)),
              onMouseover: ($event) => setInfo(tab),
              onClick: ($event) => selectTab(tab)
            }, {
              default: withCtx(() => [
                createVNode(QCardSection, { class: "bg-grey-1 text-black cursor-pointer" }, {
                  default: withCtx(() => {
                    var _a;
                    return [
                      createBaseVNode("div", _hoisted_3$4, [
                        createBaseVNode("div", _hoisted_4$3, [
                          createVNode(QImg, {
                            class: "rounded-borders",
                            width: "24px",
                            height: "24px",
                            src: getFaviconUrl(tab.chromeTab)
                          }, {
                            default: withCtx(() => [
                              unref(featureToggles).debugEnabled ? (openBlock(), createBlock(QTooltip, { key: 0 }, {
                                default: withCtx(() => {
                                  var _a2;
                                  return [
                                    createTextVNode(toDisplayString((_a2 = tab.chromeTab) == null ? void 0 : _a2.id) + " / " + toDisplayString(tab.id) + " / " + toDisplayString(tab.chromeTab.pinned), 1)
                                  ];
                                }),
                                _: 2
                              }, 1024)) : createCommentVNode("", true)
                            ]),
                            _: 2
                          }, 1032, ["src"])
                        ]),
                        createBaseVNode("div", _hoisted_5$3, [
                          createTextVNode(toDisplayString(nameOrTitle(tab)) + " ", 1),
                          createVNode(QPopupEdit, {
                            "model-value": dynamicNameOrTitleModel(tab),
                            "onUpdate:modelValue": (val) => setCustomTitle(tab, val)
                          }, {
                            default: withCtx((scope) => [
                              createVNode(QInput, {
                                modelValue: scope.value,
                                "onUpdate:modelValue": ($event) => scope.value = $event,
                                dense: "",
                                autofocus: "",
                                counter: "",
                                onKeyup: withKeys(scope.set, ["enter"])
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "onKeyup"])
                            ]),
                            _: 2
                          }, 1032, ["model-value", "onUpdate:modelValue"]),
                          createVNode(QTooltip, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(tab.chromeTab.title), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        tab.chromeTab.pinned ? (openBlock(), createBlock(QBadge, {
                          key: 0,
                          color: "warning",
                          floating: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QIcon, {
                              name: "push_pin",
                              size: "16px",
                              color: "white"
                            }, {
                              default: withCtx(() => [
                                createVNode(QTooltip, null, {
                                  default: withCtx(() => [
                                    createTextVNode("This tab is pinned")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })) : createCommentVNode("", true),
                        tab.chromeTab.groupId !== -1 ? (openBlock(), createBlock(QBadge, {
                          key: 1,
                          color: "warning",
                          floating: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QIcon, {
                              name: "content_copy",
                              size: "16px",
                              color: "white"
                            }, {
                              default: withCtx(() => [
                                createVNode(QTooltip, null, {
                                  default: withCtx(() => [
                                    createTextVNode("This tab is part of a group")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      createBaseVNode("div", _hoisted_6$3, [
                        createTextVNode(toDisplayString((_a = tab.chromeTab) == null ? void 0 : _a.url) + " ", 1),
                        createVNode(QIcon, {
                          name: "launch",
                          color: "secondary",
                          onClick: withModifiers(($event) => {
                            var _a2;
                            return unref(Navigation).openOrCreateTab((_a2 = tab.chromeTab) == null ? void 0 : _a2.url);
                          }, ["stop"])
                        }, null, 8, ["onClick"]),
                        createVNode(QTooltip, null, {
                          default: withCtx(() => {
                            var _a2;
                            return [
                              createTextVNode(toDisplayString((_a2 = tab.chromeTab) == null ? void 0 : _a2.url), 1)
                            ];
                          }),
                          _: 2
                        }, 1024)
                      ]),
                      createBaseVNode("div", _hoisted_7$3, [
                        createBaseVNode("div", _hoisted_8$3, [
                          createVNode(QCheckbox, {
                            modelValue: tab.selected,
                            "onUpdate:modelValue": [
                              ($event) => tab.selected = $event,
                              _cache[0] || (_cache[0] = (val) => selectionChanged(val))
                            ],
                            size: "30px",
                            "checked-icon": "task_alt",
                            "unchecked-icon": "check_box_outline_blank"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(QBtn, {
                            flat: "",
                            round: "",
                            color: "positive",
                            size: "11px",
                            icon: "file_download",
                            onClick: ($event) => saveTab(tab)
                          }, {
                            default: withCtx(() => [
                              createVNode(QTooltip, null, {
                                default: withCtx(() => [
                                  createTextVNode("Save this tab to this tabset")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1032, ["onClick"])
                        ]),
                        createBaseVNode("div", _hoisted_9$3, [
                          createVNode(QBtn, {
                            flat: "",
                            round: "",
                            color: "warning",
                            size: "11px",
                            icon: "highlight_off",
                            onClick: withModifiers(($event) => ignoreTab(tab), ["stop"])
                          }, {
                            default: withCtx(() => [
                              createVNode(QTooltip, null, {
                                default: withCtx(() => [
                                  createTextVNode("Ignore the tab's url from now on")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1032, ["onClick"]),
                          createVNode(QBtn, {
                            flat: "",
                            round: "",
                            color: "red",
                            size: "11px",
                            icon: "delete_outline",
                            onClick: withModifiers(($event) => closeTab(tab), ["stop"])
                          }, {
                            default: withCtx(() => [
                              createVNode(QTooltip, null, {
                                default: withCtx(() => [
                                  createTextVNode("Delete this tab from this list")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1032, ["onClick"])
                        ])
                      ])
                    ];
                  }),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1032, ["style", "onMouseover", "onClick"])
          ]);
        }), 256)),
        createBaseVNode("div", _hoisted_10$3, [
          props.tabs.length >= 1 + unref(MAX_TABS_TO_SHOW) ? (openBlock(), createBlock(QCard, {
            key: 0,
            class: "my-card",
            bordered: ""
          }, {
            default: withCtx(() => [
              createVNode(QCardSection, { class: "bg-grey-1 text-black cursor-pointer" }, {
                default: withCtx(() => [
                  _hoisted_11$3,
                  createBaseVNode("div", _hoisted_12$3, toDisplayString(1 + props.tabs.length - unref(MAX_TABS_TO_SHOW)) + " more tabs to show ", 1)
                ]),
                _: 1
              }),
              createVNode(QCardActions, null, {
                default: withCtx(() => [
                  createBaseVNode("div", _hoisted_13$3, [
                    createBaseVNode("div", _hoisted_14$3, [
                      createVNode(QBtn, {
                        flat: "",
                        round: "",
                        color: "positive",
                        icon: "double_arrow"
                      }, {
                        default: withCtx(() => [
                          createVNode(QTooltip, null, {
                            default: withCtx(() => [
                              createTextVNode("Show All")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
var TabcardsPending = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-ed562f88"]]);
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Restore Tabset", -1);
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Would you like to restore this tabset?", -1);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "RestoreTabsetDialog",
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const tabsStore = useTabsStore();
    useRouter();
    const closeOld = ref("false");
    ref("");
    const openTabset = () => {
      console.log("opening tabset", closeOld.value);
      TabsetService.restore(tabsStore.currentTabsetId, closeOld.value === "true");
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1$4
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$4
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  createVNode(QRadio, {
                    modelValue: closeOld.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => closeOld.value = $event),
                    val: "true",
                    label: "Close open Tabs"
                  }, null, 8, ["modelValue"]),
                  createVNode(QRadio, {
                    modelValue: closeOld.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => closeOld.value = $event),
                    val: "false",
                    label: "Keep them open"
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    label: "Open Tabset",
                    onClick: _cache[2] || (_cache[2] = ($event) => openTabset())
                  }, null, 512), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Changed Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "Decide which tabs you want to put into your tabset ")
], -1);
const _hoisted_2$3 = { class: "text-weight-bold" };
const _hoisted_3$3 = { class: "text-caption" };
const _hoisted_4$2 = { class: "justify-center row q-ma-none q-pa-xl" };
const _hoisted_5$2 = { key: 0 };
const _hoisted_6$2 = { key: 1 };
const _hoisted_7$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body2" }, " To get started, add a new tabset by clicking on the plus sign at the lower right page. ", -1);
const _hoisted_8$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body2" }, " Select an existing tabset from the right or add a new tabset by clicking on the plus sign at the lower right page. ", -1);
const _hoisted_9$2 = { class: "row fit" };
const _hoisted_10$2 = { class: "col-xs-12 col-md-5" };
const _hoisted_11$2 = { class: "row justify-start items-baseline" };
const _hoisted_12$2 = { class: "col-1" };
const _hoisted_13$2 = /* @__PURE__ */ createBaseVNode("span", { class: "text-dark" }, "Tabset", -1);
const _hoisted_14$2 = { class: "text-primary" };
const _hoisted_15 = { class: "col-xs-12 col-md-7 text-right" };
const _hoisted_16 = { class: "text-weight-bold" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption ellipsis" }, "this browser's window's tabs to be pinned", -1);
const _hoisted_18 = { class: "text-weight-bold" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body2" }, " To start adding new tabs to this empty tabset, select the tabs you want to use from above and click save. ", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_23 = { class: "text-weight-bold" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption ellipsis" }, "other tabs", -1);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "EditTabsetComponent",
  setup(__props) {
    const route = useRoute();
    useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    const featuresStore = useFeatureTogglesStore();
    ref(tabsStore.currentTabsetName);
    const filter = ref("");
    const duplicatesCount = ref(0);
    const $q = useQuasar();
    const highlightUrl = ref("");
    watchEffect(() => {
      var _a;
      const currentTabs = tabsStore.getCurrentTabs;
      duplicatesCount.value = 0;
      _.forEach((_a = tabsStore.pendingTabset) == null ? void 0 : _a.tabs, (pendingTab) => {
        if (_.find(currentTabs, (t) => (t == null ? void 0 : t.chromeTab.url) === pendingTab.chromeTab.url)) {
          pendingTab.isDuplicate = true;
          duplicatesCount.value += 1;
        } else {
          pendingTab.isDuplicate = false;
        }
      });
    });
    watchEffect(() => {
      const highlight = route.query["highlight"];
      if (highlight && highlight.length > 0) {
        try {
          highlightUrl.value = atob(highlight);
        } catch (e) {
          console.error("highlight error", e);
        }
      }
    });
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !(t == null ? void 0 : t.chromeTab.pinned) && (t == null ? void 0 : t.chromeTab.groupId) === -1
      );
    }
    function tabsForGroup(groupId) {
      return _.filter(
        tabsStore.getCurrentTabs,
        (t) => (t == null ? void 0 : t.chromeTab.groupId) === groupId
      );
    }
    const formatLength = (length, singular, plural) => {
      return length > 1 || length === 0 ? length + " " + plural : length + " " + singular;
    };
    const saveAllPendingTabs = () => {
      TabsetService.saveAllPendingTabs().then(() => $q.notify({
        message: "The tabs have been saved",
        type: "positive"
      })).catch(() => $q.notify({
        message: "There was a problem saving (all) the tabs",
        type: "negative"
      }));
    };
    const saveSelectedPendingTabs = () => TabsetService.saveSelectedPendingTabs();
    const removeSelectedPendingTabs = () => TabsetService.removeSelectedPendingTabs();
    const removeAllPendingTabs = () => TabsetService.removeAllPendingTabs();
    const selectedCount = ref(0);
    const updateSelectionCount = () => {
      selectedCount.value = TabsetService.getSelectedPendingTabs().length;
    };
    const pendingTabsCount = () => {
      var _a, _b, _c;
      let label = formatLength(((_a = tabsStore.pendingTabset) == null ? void 0 : _a.tabs.length) - duplicatesCount.value, "tab", "tabs");
      if (((_b = tabsStore.pendingTabset) == null ? void 0 : _b.tabs.length) - duplicatesCount.value > MAX_TABS_TO_SHOW) {
        label += ", with " + (1 + ((_c = tabsStore.pendingTabset) == null ? void 0 : _c.tabs.length) - MAX_TABS_TO_SHOW) + " hidden";
      }
      if (duplicatesCount.value > 0) {
        label += ", not showing " + duplicatesCount.value + " duplicates";
      }
      return label;
    };
    const setFilter = (val) => {
      console.log("filter", val, filter.value);
      filter.value = val;
    };
    const filteredTabs = () => {
      var _a;
      const noDupliatesTabs = _.filter((_a = tabsStore.pendingTabset) == null ? void 0 : _a.tabs, (t) => !t.isDuplicate);
      if (filter.value && filter.value.trim() !== "") {
        return _.filter(noDupliatesTabs, (t) => (t == null ? void 0 : t.chromeTab.url) && (t == null ? void 0 : t.chromeTab.url.indexOf(filter.value)) >= 0 || (t == null ? void 0 : t.chromeTab.title) && (t == null ? void 0 : t.chromeTab.title.indexOf(filter.value)) >= 0);
      }
      return noDupliatesTabs;
    };
    const restoreDialog = () => {
      $q.dialog({ component: _sfc_main$5 });
    };
    return (_ctx, _cache) => {
      var _a, _b;
      return openBlock(), createElementBlock(Fragment, null, [
        ((_a = unref(tabsStore).pendingTabset) == null ? void 0 : _a.tabs.length) > 0 ? (openBlock(), createBlock(QExpansionItem, {
          key: 0,
          class: "q-mb-lg",
          style: { "border": "3px dotted grey", "border-radius": "8px" },
          "header-class": "text-black",
          "expand-icon-class": "text-black",
          "expand-icon-toggle": "",
          "default-opened": ""
        }, {
          header: withCtx(({ expanded }) => [
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                _hoisted_1$3
              ]),
              _: 1
            }),
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                createVNode(QItemLabel, { lines: "2" }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_2$3, toDisplayString(filter.value ? filter.value : "\xA0"), 1),
                    createBaseVNode("div", _hoisted_3$3, [
                      createTextVNode(toDisplayString(filter.value ? "" : "not filtering") + " ", 1),
                      createVNode(QIcon, {
                        name: filter.value ? "o_filter_alt" : "filter_alt_off",
                        size: "16px"
                      }, {
                        default: withCtx(() => [
                          createVNode(QTooltip, null, {
                            default: withCtx(() => [
                              createTextVNode("Filter shown tabs")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["name"]),
                      createVNode(QPopupEdit, {
                        "model-value": filter.value,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = (val) => setFilter(val))
                      }, {
                        default: withCtx((scope) => [
                          createVNode(QInput, {
                            modelValue: scope.value,
                            "onUpdate:modelValue": ($event) => scope.value = $event,
                            dense: "",
                            autofocus: "",
                            counter: "",
                            onKeypress: withKeys(scope.set, ["enter"])
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "onKeypress"])
                        ]),
                        _: 1
                      }, 8, ["model-value"])
                    ])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(pendingTabsCount()), 1)
              ]),
              _: 1
            })
          ]),
          default: withCtx(() => [
            createVNode(QCard, null, {
              default: withCtx(() => [
                createVNode(QCardSection, null, {
                  default: withCtx(() => [
                    createVNode(TabcardsPending, {
                      tabs: filteredTabs(),
                      onSelectionChanged: updateSelectionCount
                    }, null, 8, ["tabs"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_4$2, [
              unref(TabsetService).getSelectedPendingTabs().length === 0 ? (openBlock(), createElementBlock("span", _hoisted_5$2, [
                createVNode(QBtn, {
                  icon: "file_download",
                  label: "Add all to Tabset  " + unref(tabsStore).currentTabsetName,
                  class: "q-mx-lg",
                  color: "positive",
                  onClick: _cache[1] || (_cache[1] = ($event) => saveAllPendingTabs())
                }, null, 8, ["label"]),
                createVNode(QBtn, {
                  icon: "delete_outline",
                  label: "Remove all",
                  class: "q-mx-lg",
                  color: "negative",
                  onClick: _cache[2] || (_cache[2] = ($event) => removeAllPendingTabs())
                })
              ])) : (openBlock(), createElementBlock("span", _hoisted_6$2, [
                createVNode(QBtn, {
                  icon: "file_download",
                  label: "add selected",
                  color: "positive",
                  class: "q-mx-lg",
                  onClick: _cache[3] || (_cache[3] = ($event) => saveSelectedPendingTabs())
                }),
                createVNode(QBtn, {
                  icon: "delete_outline",
                  label: "remove selected",
                  class: "q-mx-lg",
                  color: "negative",
                  onClick: _cache[4] || (_cache[4] = ($event) => removeSelectedPendingTabs())
                })
              ]))
            ])
          ]),
          _: 1
        })) : createCommentVNode("", true),
        !unref(tabsStore).currentTabsetId && unref(tabsStore).tabsets.size === 0 ? (openBlock(), createBlock(QBanner, {
          key: 1,
          rounded: "",
          class: "bg-amber-1 text-black q-ma-md"
        }, {
          default: withCtx(() => [
            _hoisted_7$2
          ]),
          _: 1
        })) : createCommentVNode("", true),
        !unref(tabsStore).currentTabsetId && unref(tabsStore).tabsets.size > 0 ? (openBlock(), createBlock(QBanner, {
          key: 2,
          rounded: "",
          class: "bg-amber-1 text-black q-ma-md"
        }, {
          default: withCtx(() => [
            _hoisted_8$2
          ]),
          _: 1
        })) : createCommentVNode("", true),
        unref(tabsStore).currentTabsetId ? (openBlock(), createBlock(QToolbar, {
          key: 3,
          class: "text-primary"
        }, {
          default: withCtx(() => {
            var _a2;
            return [
              createBaseVNode("div", _hoisted_9$2, [
                createBaseVNode("div", _hoisted_10$2, [
                  createVNode(QToolbarTitle, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_11$2, [
                        createBaseVNode("div", _hoisted_12$2, [
                          _hoisted_13$2,
                          createTextVNode(),
                          createBaseVNode("span", _hoisted_14$2, [
                            createTextVNode(toDisplayString(unref(tabsStore).currentTabsetName) + " ", 1),
                            unref(featuresStore).debugEnabled ? (openBlock(), createBlock(QTooltip, { key: 0 }, {
                              default: withCtx(() => [
                                createTextVNode("ID: " + toDisplayString(unref(tabsStore).getCurrentTabset.id), 1)
                              ]),
                              _: 1
                            })) : createCommentVNode("", true)
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("div", _hoisted_15, [
                  ((_a2 = unref(tabsStore).getCurrentTabset) == null ? void 0 : _a2.tabs.length) > 0 ? (openBlock(), createBlock(QBtn, {
                    key: 0,
                    flat: "",
                    dense: "",
                    icon: "restore_page",
                    color: "green",
                    label: unref($q).screen.gt.sm ? "Open Tabset..." : "",
                    class: "q-mr-md",
                    onClick: restoreDialog
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Replace your current tabs with all the tabs from this tabset")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])) : createCommentVNode("", true)
                ])
              ])
            ];
          }),
          _: 1
        })) : createCommentVNode("", true),
        unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
          key: 4,
          "header-class": "text-black",
          "expand-icon-class": "text-black",
          "expand-separator": "",
          "default-opened": ""
        }, {
          header: withCtx(({ expanded }) => [
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                createBaseVNode("div", null, [
                  createBaseVNode("span", _hoisted_16, "Pinned Tabs (" + toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")) + ")", 1),
                  _hoisted_17
                ])
              ]),
              _: 1
            })
          ]),
          default: withCtx(() => [
            createVNode(QCard, null, {
              default: withCtx(() => [
                createVNode(QCardSection, null, {
                  default: withCtx(() => [
                    createVNode(Tabcards, {
                      key: "pinnedTabs",
                      tabs: unref(tabsStore).pinnedTabs,
                      group: "pinnedTabs",
                      highlightUrl: highlightUrl.value
                    }, null, 8, ["tabs", "highlightUrl"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })) : createCommentVNode("", true),
        (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
          return openBlock(), createElementBlock(Fragment, null, [
            tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 0,
              "default-opened": "",
              "header-class": "text-black",
              "expand-icon-class": "text-black",
              "expand-separator": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      color: group.color,
                      name: "tab"
                    }, null, 8, ["color"])
                  ]),
                  _: 2
                }, 1024),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createBaseVNode("div", null, [
                      createBaseVNode("span", _hoisted_18, toDisplayString(group.title), 1),
                      _hoisted_19
                    ])
                  ]),
                  _: 2
                }, 1024),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                  ]),
                  _: 2
                }, 1024)
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        (openBlock(), createBlock(Tabcards, {
                          tabs: tabsForGroup(group.id),
                          key: "groupedTabs_" + group.id,
                          group: "groupedTabs_" + group.id,
                          highlightUrl: highlightUrl.value
                        }, null, 8, ["tabs", "group", "highlightUrl"]))
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1024)) : createCommentVNode("", true)
          ], 64);
        }), 256)),
        unref(tabsStore).currentTabsetId && unref(tabsStore).getCurrentTabs.length === 0 && ((_b = unref(tabsStore).pendingTabset) == null ? void 0 : _b.tabs.length) > 0 ? (openBlock(), createBlock(QBanner, {
          key: 5,
          rounded: "",
          class: "bg-amber-1 text-black q-ma-md"
        }, {
          default: withCtx(() => [
            _hoisted_20
          ]),
          _: 1
        })) : unref(tabsStore).currentTabsetId && unref(tabsStore).getCurrentTabs.length === 0 ? (openBlock(), createBlock(QBanner, { key: 6 }, {
          default: withCtx(() => [
            createTextVNode(" To start adding new tabs to this empty tabset, open new browser tabs and come back to this extension to associate them with a tabset."),
            _hoisted_21,
            _hoisted_22
          ]),
          _: 1
        })) : createCommentVNode("", true),
        createVNode(QExpansionItem, {
          icon: "tabs",
          "default-opened": "",
          "data-testid": "expansion_item_unpinnedNoGroup",
          "header-class": "text-black",
          "expand-icon-class": "text-black",
          "expand-separator": ""
        }, {
          header: withCtx(({ expanded }) => [
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                createBaseVNode("div", null, [
                  createBaseVNode("span", _hoisted_23, "Tabs (" + toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")) + ")", 1),
                  _hoisted_24
                ])
              ]),
              _: 1
            }),
            createVNode(QItemSection)
          ]),
          default: withCtx(() => [
            createVNode(QCard, null, {
              default: withCtx(() => [
                createVNode(QCardSection, null, {
                  default: withCtx(() => [
                    createVNode(Tabcards, {
                      tabs: unpinnedNoGroup(),
                      group: "otherTabs",
                      highlightUrl: highlightUrl.value
                    }, null, 8, ["tabs", "highlightUrl"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Tablist",
  props: {
    tabs: {
      type: Array,
      required: true
    },
    showActions: {
      type: Boolean,
      default: false
    }
  },
  emits: ["sendCaption"],
  setup(__props, { emit: emits }) {
    const props = __props;
    ref(null);
    const selectTab = (tab) => {
      console.log("tab selected", tab);
      TabsetService.setOnlySelectedTab(tab);
      const notificationStore = useNotificationsStore();
      notificationStore.setSelectedTab(tab);
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QList, {
        bordered: "",
        separator: ""
      }, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(props.tabs, (tab, index) => {
            return withDirectives((openBlock(), createBlock(QItem, {
              clickable: "",
              onClick: ($event) => selectTab(tab, index),
              autofocus: ""
            }, {
              default: withCtx(() => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => {
                    var _a;
                    return [
                      createVNode(QImg, {
                        class: "rounded-borders",
                        width: "20px",
                        height: "20px",
                        src: (_a = tab.chromeTab) == null ? void 0 : _a.favIconUrl
                      }, {
                        default: withCtx(() => [
                          createVNode(QTooltip, null, {
                            default: withCtx(() => {
                              var _a2;
                              return [
                                createTextVNode(toDisplayString((_a2 = tab.chromeTab) == null ? void 0 : _a2.id) + " / " + toDisplayString(tab.id), 1)
                              ];
                            }),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1032, ["src"])
                    ];
                  }),
                  _: 2
                }, 1024),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createVNode(QItemLabel, null, {
                      default: withCtx(() => {
                        var _a;
                        return [
                          createTextVNode(toDisplayString((_a = tab.chromeTab) == null ? void 0 : _a.title), 1)
                        ];
                      }),
                      _: 2
                    }, 1024),
                    createVNode(QItemLabel, { caption: "" }, {
                      default: withCtx(() => {
                        var _a;
                        return [
                          createTextVNode(toDisplayString((_a = tab.chromeTab) == null ? void 0 : _a.url), 1)
                        ];
                      }),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024),
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "launch",
                      color: "primary",
                      onClick: withModifiers(($event) => {
                        var _a;
                        return unref(Navigation).openOrCreateTab((_a = tab.chromeTab) == null ? void 0 : _a.url);
                      }, ["stop"])
                    }, null, 8, ["onClick"])
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1032, ["onClick"])), [
              [Ripple]
            ]);
          }), 256))
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body2" }, " To start adding new tabs to this empty tabset, open new browser tabs and come back to this extension to associate them with a tabset. ", -1);
const _hoisted_2$2 = { class: "row fit" };
const _hoisted_3$2 = { class: "col-xs-12 col-md-5" };
const _hoisted_4$1 = { class: "row justify-start items-baseline" };
const _hoisted_5$1 = ["textContent"];
const _hoisted_6$1 = { class: "col-xs-12 col-md-7 text-right" };
const _hoisted_7$1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pending Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "These tabs have been used in the current context but have not been saved yet ")
], -1);
const _hoisted_8$1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pinned Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "this browser's window's tabs which are pinned right now")
], -1);
const _hoisted_9$1 = { class: "q-pb-lg" };
const _hoisted_10$1 = { class: "text-weight-bold" };
const _hoisted_11$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_12$1 = { class: "text-weight-bold" };
const _hoisted_13$1 = ["textContent"];
const _hoisted_14$1 = { key: 3 };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "TabsetList",
  setup(__props) {
    useRoute();
    useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    ref(tabsStore.currentTabsetName);
    const otherTabsCaption = ref("current tabs, neither pinned nor grouped...");
    const groupedTabsCaption = ref("current tabs, neither pinned nor grouped");
    const $q = useQuasar();
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1
      );
    }
    function tabsForGroup(groupId) {
      return _.filter(
        tabsStore.getCurrentTabs,
        (t) => t.chromeTab.groupId === groupId
      );
    }
    const formatLength = (length, singular, plural) => {
      return length > 1 ? length + " " + plural : length + " " + singular;
    };
    const saveAllPendingTabs = () => TabsetService.saveAllPendingTabs();
    const setGroupedTabsCaption = (msg) => groupedTabsCaption.value = msg;
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.delete(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const restoreDialog = () => {
      $q.dialog({
        title: "Restore Tabset",
        message: "Would you like to restore this tabset? All current tabs will be closed before.",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.restore(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        unref(tabsStore).active && unref(tabsStore).getCurrentTabs.length === 0 ? (openBlock(), createBlock(QBanner, {
          key: 0,
          rounded: "",
          class: "bg-amber-1 text-black"
        }, {
          default: withCtx(() => [
            _hoisted_1$2
          ]),
          _: 1
        })) : createCommentVNode("", true),
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => {
            var _a;
            return [
              createBaseVNode("div", _hoisted_2$2, [
                createBaseVNode("div", _hoisted_3$2, [
                  createVNode(QToolbarTitle, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_4$1, [
                        createBaseVNode("div", {
                          class: "col-1",
                          style: { "width": "80px" },
                          textContent: toDisplayString("Tabset '" + unref(tabsStore).currentTabsetName + "'")
                        }, null, 8, _hoisted_5$1)
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("div", _hoisted_6$1, [
                  ((_a = unref(tabsStore).getCurrentTabset) == null ? void 0 : _a.tabs.length) > 0 ? (openBlock(), createBlock(QBtn, {
                    key: 0,
                    flat: "",
                    dense: "",
                    icon: "restore_page",
                    color: "green",
                    label: unref($q).screen.gt.sm ? "Open Tabset..." : "",
                    class: "q-mr-md",
                    onClick: restoreDialog
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Replace your current tabs with all the tabs from this tabset")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])) : createCommentVNode("", true),
                  createVNode(QBtn, {
                    flat: "",
                    dense: "",
                    icon: "delete",
                    color: "red",
                    label: unref($q).screen.gt.sm ? "Delete Tabset..." : "",
                    onClick: deleteDialog
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Delete this tabset")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])
                ])
              ])
            ];
          }),
          _: 1
        }),
        createVNode(QList, { class: "rounded-borders" }, {
          default: withCtx(() => {
            var _a;
            return [
              ((_a = unref(tabsStore).pendingTabset) == null ? void 0 : _a.tabs.length) > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 0,
                "header-class": "bg-amber-2 text-black",
                "expand-icon-class": "text-black",
                "expand-separator": "",
                "default-opened": ""
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "push_pin" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      _hoisted_7$1
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => {
                      var _a2;
                      return [
                        createTextVNode(toDisplayString(formatLength((_a2 = unref(tabsStore).pendingTabset) == null ? void 0 : _a2.tabs.length, "tab", "tabs")), 1)
                      ];
                    }),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createBaseVNode("div", null, [
                    unref(_).filter(unref(tabsStore).pendingTabs, (t) => t.status === _ctx.TabStatus.DELETED).length > 1 ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: "cursor-pointer",
                      onClick: _cache[0] || (_cache[0] = ($event) => _ctx.removeClosedTabs())
                    }, "[remove all closed tabs]")) : createCommentVNode("", true),
                    unref(tabsStore).pendingTabs.length > 1 ? (openBlock(), createElementBlock("span", {
                      key: 1,
                      class: "cursor-pointer",
                      onClick: _cache[1] || (_cache[1] = ($event) => saveAllPendingTabs())
                    }, "[save all]")) : createCommentVNode("", true)
                  ]),
                  createVNode(QCard, null, {
                    default: withCtx(() => [
                      createVNode(QCardSection, null, {
                        default: withCtx(() => {
                          var _a2;
                          return [
                            createVNode(Tabcards, {
                              tabs: (_a2 = unref(tabsStore).pendingTabset) == null ? void 0 : _a2.tabs,
                              "show-actions": ""
                            }, null, 8, ["tabs"])
                          ];
                        }),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })) : createCommentVNode("", true),
              unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 1,
                "header-class": "text-black",
                "expand-icon-class": "text-black",
                "expand-separator": "",
                "default-opened": ""
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "push_pin" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      _hoisted_8$1
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")), 1)
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_sfc_main$3, {
                    tabs: unref(tabsStore).pinnedTabs
                  }, null, 8, ["tabs"])
                ]),
                _: 1
              })) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
                return openBlock(), createElementBlock("div", _hoisted_9$1, [
                  tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                    key: 0,
                    "header-class": "text-black",
                    "expand-icon-class": "text-black",
                    "expand-separator": "",
                    "default-opened": ""
                  }, {
                    header: withCtx(({ expanded }) => [
                      createVNode(QItemSection, { avatar: "" }, {
                        default: withCtx(() => [
                          createVNode(QIcon, {
                            color: group.color,
                            name: "tab"
                          }, null, 8, ["color"])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(QItemSection, null, {
                        default: withCtx(() => [
                          createBaseVNode("div", null, [
                            createBaseVNode("span", _hoisted_10$1, "Group " + toDisplayString(group.title), 1),
                            _hoisted_11$1
                          ])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(QItemSection, null, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    default: withCtx(() => [
                      createVNode(_sfc_main$3, {
                        tabs: tabsForGroup(group.id),
                        onSendCaption: setGroupedTabsCaption
                      }, null, 8, ["tabs"])
                    ]),
                    _: 2
                  }, 1024)) : createCommentVNode("", true)
                ]);
              }), 256)),
              unpinnedNoGroup().length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 2,
                icon: "tabs",
                "default-opened": "",
                "header-class": "text-black",
                "expand-icon-class": "text-black"
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "tab" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", null, [
                        createBaseVNode("span", _hoisted_12$1, "Other Tabs (" + toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")) + ")", 1),
                        createBaseVNode("div", {
                          class: "text-caption ellipsis",
                          textContent: toDisplayString(otherTabsCaption.value)
                        }, null, 8, _hoisted_13$1)
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection)
                ]),
                default: withCtx(() => [
                  createVNode(_sfc_main$3, {
                    tabs: unpinnedNoGroup()
                  }, null, 8, ["tabs"])
                ]),
                _: 1
              })) : (openBlock(), createElementBlock("div", _hoisted_14$1, [
                createVNode(_sfc_main$3, {
                  tabs: unpinnedNoGroup()
                }, null, 8, ["tabs"])
              ]))
            ];
          }),
          _: 1
        })
      ], 64);
    };
  }
});
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body2" }, " To start adding new tabs to this empty tabset, open new browser tabs and come back to this extension to associate them with a tabset. ", -1);
const _hoisted_2$1 = { class: "row fit" };
const _hoisted_3$1 = { class: "col-xs-12 col-md-5" };
const _hoisted_4 = { class: "row justify-start items-baseline" };
const _hoisted_5 = ["textContent"];
const _hoisted_6 = { class: "col-xs-12 col-md-7 text-right" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pending Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "These tabs have been used in the current context but have not been saved yet ")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pinned Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "this browser's window's tabs which are pinned right now")
], -1);
const _hoisted_9 = { class: "q-pb-lg" };
const _hoisted_10 = { class: "text-weight-bold" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_12 = { class: "text-weight-bold" };
const _hoisted_13 = ["textContent"];
const _hoisted_14 = { key: 3 };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TabsetThumbnails",
  setup(__props) {
    useRoute();
    useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    ref(tabsStore.currentTabsetName);
    const otherTabsCaption = ref("current tabs, neither pinned nor grouped...");
    const groupedTabsCaption = ref("current tabs, neither pinned nor grouped");
    const $q = useQuasar();
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1 && (t.status === TabStatus.DEFAULT || !t.status)
      );
    }
    function tabsForGroup(groupId) {
      return _.filter(
        tabsStore.getCurrentTabs,
        (t) => t.chromeTab.groupId === groupId
      );
    }
    const formatLength = (length, singular, plural) => {
      return length > 1 ? length + " " + plural : length + " " + singular;
    };
    const removeClosedTabs = () => TabsetService.removeClosedTabs();
    const saveAllPendingTabs = () => TabsetService.saveAllPendingTabs();
    const setGroupedTabsCaption = (msg) => groupedTabsCaption.value = msg;
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.delete(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const restoreDialog = () => {
      $q.dialog({
        title: "Restore Tabset",
        message: "Would you like to restore this tabset? All current tabs will be closed before.",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.restore(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      const _component_TabThumbs = resolveComponent("TabThumbs");
      return openBlock(), createElementBlock(Fragment, null, [
        unref(tabsStore).active && unref(tabsStore).getCurrentTabs.length === 0 ? (openBlock(), createBlock(QBanner, {
          key: 0,
          rounded: "",
          class: "bg-amber-1 text-black"
        }, {
          default: withCtx(() => [
            _hoisted_1$1
          ]),
          _: 1
        })) : createCommentVNode("", true),
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => {
            var _a;
            return [
              createBaseVNode("div", _hoisted_2$1, [
                createBaseVNode("div", _hoisted_3$1, [
                  createVNode(QToolbarTitle, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_4, [
                        createBaseVNode("div", {
                          class: "col-1",
                          style: { "width": "80px" },
                          textContent: toDisplayString("Tabset '" + unref(tabsStore).currentTabsetName + "'")
                        }, null, 8, _hoisted_5)
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("div", _hoisted_6, [
                  ((_a = unref(tabsStore).getCurrentTabset) == null ? void 0 : _a.tabs.length) > 0 ? (openBlock(), createBlock(QBtn, {
                    key: 0,
                    flat: "",
                    dense: "",
                    icon: "restore_page",
                    color: "green",
                    label: unref($q).screen.gt.sm ? "Open Tabset..." : "",
                    class: "q-mr-md",
                    onClick: restoreDialog
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Replace your current tabs with all the tabs from this tabset")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])) : createCommentVNode("", true),
                  createVNode(QBtn, {
                    flat: "",
                    dense: "",
                    icon: "delete",
                    color: "red",
                    label: unref($q).screen.gt.sm ? "Delete Tabset..." : "",
                    onClick: deleteDialog
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Delete this tabset")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["label"])
                ])
              ])
            ];
          }),
          _: 1
        }),
        createVNode(QList, { class: "rounded-borders" }, {
          default: withCtx(() => {
            var _a;
            return [
              ((_a = unref(tabsStore).pendingTabset) == null ? void 0 : _a.tabs.length) > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 0,
                "header-class": "bg-amber-2 text-black",
                "expand-icon-class": "text-black",
                "expand-separator": "",
                "default-opened": ""
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "push_pin" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      _hoisted_7
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => {
                      var _a2;
                      return [
                        createTextVNode(toDisplayString(formatLength((_a2 = unref(tabsStore).pendingTabset) == null ? void 0 : _a2.tabs.length, "tab", "tabs")), 1)
                      ];
                    }),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createBaseVNode("div", null, [
                    unref(_).filter(unref(tabsStore).pendingTabs, (t) => t.status === _ctx.TabStatus.DELETED).length > 1 ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: "cursor-pointer",
                      onClick: _cache[0] || (_cache[0] = ($event) => removeClosedTabs())
                    }, "[remove all closed tabs]")) : createCommentVNode("", true),
                    unref(tabsStore).pendingTabs.length > 1 ? (openBlock(), createElementBlock("span", {
                      key: 1,
                      class: "cursor-pointer",
                      onClick: _cache[1] || (_cache[1] = ($event) => saveAllPendingTabs())
                    }, "[save all]")) : createCommentVNode("", true)
                  ]),
                  createVNode(QCard, null, {
                    default: withCtx(() => [
                      createVNode(QCardSection, null, {
                        default: withCtx(() => {
                          var _a2;
                          return [
                            createVNode(Tabcards, {
                              tabs: (_a2 = unref(tabsStore).pendingTabset) == null ? void 0 : _a2.tabs,
                              "show-actions": ""
                            }, null, 8, ["tabs"])
                          ];
                        }),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })) : createCommentVNode("", true),
              unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 1,
                "header-class": "text-black",
                "expand-icon-class": "text-black",
                "expand-separator": "",
                "default-opened": ""
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "push_pin" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      _hoisted_8
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")), 1)
                    ]),
                    _: 1
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_TabThumbs, {
                    tabs: unref(tabsStore).pinnedTabs
                  }, null, 8, ["tabs"])
                ]),
                _: 1
              })) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
                return openBlock(), createElementBlock("div", _hoisted_9, [
                  tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                    key: 0,
                    "header-class": "text-black",
                    "expand-icon-class": "text-black",
                    "expand-separator": "",
                    "default-opened": ""
                  }, {
                    header: withCtx(({ expanded }) => [
                      createVNode(QItemSection, { avatar: "" }, {
                        default: withCtx(() => [
                          createVNode(QIcon, {
                            color: group.color,
                            name: "tab"
                          }, null, 8, ["color"])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(QItemSection, null, {
                        default: withCtx(() => [
                          createBaseVNode("div", null, [
                            createBaseVNode("span", _hoisted_10, "Group " + toDisplayString(group.title), 1),
                            _hoisted_11
                          ])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(QItemSection, null, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_TabThumbs, {
                        tabs: tabsForGroup(group.id),
                        onSendCaption: setGroupedTabsCaption
                      }, null, 8, ["tabs"])
                    ]),
                    _: 2
                  }, 1024)) : createCommentVNode("", true)
                ]);
              }), 256)),
              unpinnedNoGroup().length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                key: 2,
                icon: "tabs",
                "default-opened": "",
                "header-class": "text-black",
                "expand-icon-class": "text-black"
              }, {
                header: withCtx(({ expanded }) => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QIcon, { name: "tab" })
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", null, [
                        createBaseVNode("span", _hoisted_12, "Other Tabs (" + toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")) + ")", 1),
                        createBaseVNode("div", {
                          class: "text-caption ellipsis",
                          textContent: toDisplayString(otherTabsCaption.value)
                        }, null, 8, _hoisted_13)
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(QItemSection)
                ]),
                default: withCtx(() => [
                  createVNode(_component_TabThumbs, {
                    tabs: unpinnedNoGroup()
                  }, null, 8, ["tabs"])
                ]),
                _: 1
              })) : (openBlock(), createElementBlock("div", _hoisted_14, [
                createVNode(_component_TabThumbs, {
                  tabs: unpinnedNoGroup()
                }, null, 8, ["tabs"])
              ]))
            ];
          }),
          _: 1
        })
      ], 64);
    };
  }
});
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { key: 2 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CurrentTabs",
  setup(__props) {
    useRoute();
    useRouter();
    const localStorage = useQuasar().localStorage;
    useTabsStore();
    useQuasar();
    const layout = ref("grid");
    const layoutFromStorage = localStorage.getItem("layout");
    if (layoutFromStorage) {
      layout.value = layoutFromStorage.toString();
    }
    const selectedTabsetFromStorage = localStorage.getItem("selectedTabset");
    if (selectedTabsetFromStorage) {
      console.log("selecting tabset from storage");
      TabsetService.selectTabset(selectedTabsetFromStorage);
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          layout.value === "list" ? (openBlock(), createElementBlock("div", _hoisted_1, [
            createVNode(_sfc_main$2)
          ])) : layout.value === "thumbnails" ? (openBlock(), createElementBlock("div", _hoisted_2, [
            createVNode(_sfc_main$1)
          ])) : (openBlock(), createElementBlock("div", _hoisted_3, [
            createVNode(_sfc_main$4)
          ])),
          createVNode(_sfc_main$9)
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
