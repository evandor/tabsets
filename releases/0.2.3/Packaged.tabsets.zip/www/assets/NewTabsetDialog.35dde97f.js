import { I as defineComponent, J as useTabsStore, r as ref, c as computed, bk as STRIP_CHARS_IN_USER_INPUT, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, ay as unref, a8 as QDialog, L as useRouter, K as useQuasar, d as createVNode, aF as QCardSection, aG as QInput, aH as withKeys, M as createBaseVNode, aC as toDisplayString, aU as QCheckbox, aA as createTextVNode, a1 as QIcon, aI as QCardActions, aJ as QBtn, ap as withDirectives, aK as QCard, ax as TabsetService } from "./index.ac7851bc.js";
import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Add new Tabset", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please provide a name for the new tabset", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "New Tabset's name:", -1);
const _hoisted_4 = { class: "text-caption text-negative q-mt-none q-pt-none" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NewTabsetDialog",
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const tabsStore = useTabsStore();
    const router = useRouter();
    const $q = useQuasar();
    const newTabsetName = ref("");
    const newTabsetNameExists = ref(false);
    const hideWarning = ref(false);
    const addAutomatically = ref(true);
    const newTabsetNameIsValid = computed(() => {
      return newTabsetName.value.length <= 32 && !STRIP_CHARS_IN_USER_INPUT.test(newTabsetName.value);
    });
    watchEffect(() => {
      newTabsetNameExists.value = !!tabsStore.nameExistsInContextTabset(newTabsetName.value);
    });
    const createNewTabset = () => {
      hideWarning.value = true;
      const tabsToUse = addAutomatically.value ? tabsStore.tabs : [];
      TabsetService.saveOrReplaceFromChromeTabs(newTabsetName.value, tabsToUse, true).then((result) => {
        if (!addAutomatically.value) {
          TabsetService.createPendingFromBrowserTabs();
        }
        newTabsetName.value = "";
        const replaced = result.replaced;
        const merged = result.merged;
        let message = "Empty Tabset " + newTabsetName.value + " created successfully";
        if (replaced && merged) {
          message = "Existing Tabset " + newTabsetName.value + " can be updated now";
        } else if (replaced) {
          message = "Existing Tabset " + newTabsetName.value + " was overwritten";
        }
        hideWarning.value = false;
        router.push("/tabset");
        $q.notify({
          message,
          type: "positive"
        });
      }).catch((ex) => {
        console.error("ex", ex);
        hideWarning.value = false;
        $q.notify({
          message: "There was a problem creating the tabset " + newTabsetName.value,
          type: "warning"
        });
      });
    };
    const newTabsetDialogWarning = () => {
      return !hideWarning.value && tabsStore.nameExistsInContextTabset(newTabsetName.value) ? "Hint: Tabset exists, but you can add tabs" : "";
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  _hoisted_3,
                  createVNode(QInput, {
                    modelValue: newTabsetName.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newTabsetName.value = $event),
                    class: "q-mb-none q-pb-none",
                    dense: "",
                    autofocus: "",
                    "error-message": "Please do not use special Characters, maximum length is 32",
                    error: !unref(newTabsetNameIsValid),
                    "data-testid": "newTabsetName",
                    onKeydown: _cache[1] || (_cache[1] = withKeys(($event) => createNewTabset(), ["enter"]))
                  }, null, 8, ["modelValue", "error"]),
                  createBaseVNode("div", _hoisted_4, toDisplayString(newTabsetDialogWarning()), 1),
                  createVNode(QCheckbox, {
                    modelValue: addAutomatically.value,
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => addAutomatically.value = $event),
                    label: "Add open tabs automatically"
                  }, null, 8, ["modelValue"]),
                  createTextVNode("\xA0 "),
                  createVNode(QIcon, {
                    name: "help",
                    color: "primary",
                    size: "1em"
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("When checked, this will add all your browsers open tabs automatically to the new tabset."),
                          _hoisted_5,
                          createTextVNode(" Otherwise, you have the chance to add all (or selected) tabs yourself later. ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    "data-testid": "newTabsetNameSubmit",
                    label: newTabsetNameExists.value ? "Alter Tabset" : "Create new Tabset",
                    disable: newTabsetName.value.trim().length === 0,
                    onClick: _cache[3] || (_cache[3] = ($event) => createNewTabset())
                  }, null, 8, ["label", "disable"]), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
export { _sfc_main as _ };
