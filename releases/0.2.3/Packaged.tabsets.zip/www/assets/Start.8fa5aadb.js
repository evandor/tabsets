import { Q as QPage } from "./QPage.d2025984.js";
import { I as defineComponent, J as useTabsStore, j as openBlock, k as createBlock, l as withCtx, K as useQuasar, L as useRouter, M as createBaseVNode } from "./index.ac7851bc.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", {
  class: "row justify-center items-center",
  style: { "height": "500px" }
}, [
  /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 content-center" }, " Welcome to Tabsets ")
], -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Start",
  setup(__props) {
    const $q = useQuasar();
    const router = useRouter();
    $q.loading.show({
      message: "Initializing tabsets. Please hang on..."
    });
    setTimeout(() => {
      const tabsStore = useTabsStore();
      if (tabsStore.tabsets.size === 0) {
        router.push("/about");
      } else {
        router.push("/tabset");
      }
      setTimeout(() => {
        $q.loading.hide();
      }, 500);
    }, 2e3);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          _hoisted_1
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
