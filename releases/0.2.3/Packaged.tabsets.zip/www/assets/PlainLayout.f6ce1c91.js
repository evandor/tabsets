import { Q as QLayout, a as QPageContainer } from "./QLayout.53a3ecac.js";
import { _ as _export_sfc } from "./plugin-vue_export-helper.21dcd24c.js";
import { j as openBlock, k as createBlock, l as withCtx, m as resolveComponent, d as createVNode } from "./index.ac7851bc.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_router_view = resolveComponent("router-view");
  return openBlock(), createBlock(QLayout, { view: "hHh lpR fFf" }, {
    default: withCtx(() => [
      createVNode(QPageContainer, null, {
        default: withCtx(() => [
          createVNode(_component_router_view)
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
var PlainLayout = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { PlainLayout as default };
