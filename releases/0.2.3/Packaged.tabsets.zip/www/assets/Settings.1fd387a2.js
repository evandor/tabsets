import { I as defineComponent, J as useTabsStore, av as useFeatureTogglesStore, b0 as useSearchStore, K as useQuasar, r as ref, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, L as useRouter, M as createBaseVNode, d as createVNode, a$ as QRadio, ay as unref, az as createElementBlock, aB as createCommentVNode, aM as renderList, aC as toDisplayString, F as Fragment, bw as INDEX_DB_NAME, aA as createTextVNode, ax as TabsetService, aE as Navigation } from "./index.ac7851bc.js";
import { Q as QPage } from "./QPage.d2025984.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Tabset Settings ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Dark Mode", -1);
const _hoisted_3 = {
  key: 0,
  class: "text-h6"
};
const _hoisted_4 = {
  key: 1,
  class: "row"
};
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "col-3" }, " Select the tabset view style ", -1);
const _hoisted_6 = { class: "col-3" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Ignored Urls", -1);
const _hoisted_8 = {
  key: 2,
  class: "text-h6"
};
const _hoisted_9 = {
  key: 3,
  class: "row"
};
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", { class: "col-3" }, " DB Name ", -1);
const _hoisted_11 = { class: "col-3" };
const _hoisted_12 = {
  key: 4,
  class: "text-h6"
};
const _hoisted_13 = {
  key: 5,
  class: "row"
};
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", { class: "col-3" }, " Search Index ", -1);
const _hoisted_15 = { class: "col-3" };
const _hoisted_16 = {
  key: 6,
  class: "text-h6"
};
const _hoisted_17 = {
  key: 7,
  class: "row"
};
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("div", { class: "col-3" }, " Version 0.1.2 ", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("div", { class: "col-3" }, null, -1);
const _hoisted_20 = { class: "col-3" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Settings",
  setup(__props) {
    const tabsStore = useTabsStore();
    const featuresStore = useFeatureTogglesStore();
    const searchStore = useSearchStore();
    useRouter();
    const localStorage = useQuasar().localStorage;
    const $q = useQuasar();
    const view = ref("grid");
    const indexSize = ref(0);
    const darkMode = ref(localStorage.getItem("darkMode") || false);
    ref(localStorage.getItem("showBookmarks") || false);
    watchEffect(() => {
      console.log("darkMode", darkMode.value, typeof darkMode.value);
      $q.dark.set(darkMode.value);
      localStorage.set("darkMode", darkMode.value);
    });
    watchEffect(() => {
      localStorage.set("layout", view.value);
    });
    watchEffect(() => {
      indexSize.value = searchStore.fuse.getIndex().size();
    });
    const downloadIndex = () => {
      const data = JSON.stringify(searchStore.fuse.getIndex());
      return TabsetService.createFile(data, "tabsetIndex.json");
    };
    const clearIndex = () => searchStore.init();
    const simulateNewVersion = (version) => Navigation.updateAvailable({ version });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => {
          var _a;
          return [
            _hoisted_1,
            _hoisted_2,
            createBaseVNode("div", null, [
              createVNode(QRadio, {
                modelValue: darkMode.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => darkMode.value = $event),
                val: true,
                label: "Enabled"
              }, null, 8, ["modelValue"]),
              createVNode(QRadio, {
                modelValue: darkMode.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => darkMode.value = $event),
                val: false,
                label: "Disabled"
              }, null, 8, ["modelValue"])
            ]),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_3, "Views")) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_4, [
              _hoisted_5,
              createBaseVNode("div", _hoisted_6, [
                createVNode(QRadio, {
                  modelValue: view.value,
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => view.value = $event),
                  val: "grid",
                  label: "Default (Grid)"
                }, null, 8, ["modelValue"]),
                createVNode(QRadio, {
                  disable: !unref(featuresStore).listviewEnabled,
                  modelValue: view.value,
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => view.value = $event),
                  val: "list",
                  label: "List View"
                }, null, 8, ["disable", "modelValue"])
              ])
            ])) : createCommentVNode("", true),
            _hoisted_7,
            (openBlock(true), createElementBlock(Fragment, null, renderList((_a = unref(tabsStore).ignoredTabset) == null ? void 0 : _a.tabs, (t) => {
              return openBlock(), createElementBlock("div", null, toDisplayString(t.chromeTab.url), 1);
            }), 256)),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_8, "Index DB")) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_9, [
              _hoisted_10,
              createBaseVNode("div", _hoisted_11, toDisplayString(unref(INDEX_DB_NAME)), 1)
            ])) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_12, "Search Index")) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_13, [
              _hoisted_14,
              createBaseVNode("div", _hoisted_15, " Current Size: " + toDisplayString(indexSize.value) + " Entries ", 1),
              createBaseVNode("div", { class: "col-3" }, [
                createBaseVNode("span", {
                  class: "text-blue cursor-pointer",
                  onClick: downloadIndex
                }, "[Download]"),
                createTextVNode("\xA0 "),
                createBaseVNode("span", {
                  class: "text-blue cursor-pointer",
                  onClick: clearIndex
                }, "[clear Index]"),
                createTextVNode("\xA0 ")
              ])
            ])) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_16, "Simulate new Version")) : createCommentVNode("", true),
            unref(featuresStore).debugEnabled ? (openBlock(), createElementBlock("div", _hoisted_17, [
              _hoisted_18,
              _hoisted_19,
              createBaseVNode("div", _hoisted_20, [
                createBaseVNode("span", {
                  class: "text-blue cursor-pointer",
                  onClick: _cache[4] || (_cache[4] = ($event) => simulateNewVersion("0.1.2"))
                }, "Simulate"),
                createTextVNode("\xA0 ")
              ])
            ])) : createCommentVNode("", true)
          ];
        }),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
