import { I as defineComponent, J as useTabsStore, j as openBlock, k as createBlock, l as withCtx, M as createBaseVNode, aC as toDisplayString, ay as unref, az as createElementBlock, aA as createTextVNode, d as createVNode, a1 as QIcon, aB as createCommentVNode, au as useNotificationsStore } from "./index.ac7851bc.js";
import { Q as QPage } from "./QPage.d2025984.js";
import { _ as _sfc_main$1 } from "./Fab.577affc8.js";
import "./QTooltip.60dd45e2.js";
import "./use-dialog-plugin-component.220b0d2f.js";
import "./NewTabsetDialog.35dde97f.js";
import "./ReindexDialog.ccfa929c.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ml-md" }, " Welcome to Tabsets ", -1);
const _hoisted_2 = { class: "text-caption q-ml-md q-mb-md" };
const _hoisted_3 = {
  key: 0,
  class: "text-body1 q-ma-md"
};
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "tabset", -1);
const _hoisted_7 = {
  key: 1,
  class: "text-body1 q-ma-md"
};
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Basic Features (Tabsets Free) ", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, [
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Turn your open tabs into a "),
      /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "tabset")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Re-open your "),
      /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "tabsets"),
      /* @__PURE__ */ createTextVNode(" or tabs whenever you need them")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Edit "),
      /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "tabsets")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Search for keywords in your "),
      /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "tabsets")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, "Drag & drop tabs into tabsets"),
    /* @__PURE__ */ createBaseVNode("li", null, "Bookmarks integration"),
    /* @__PURE__ */ createBaseVNode("li", null, "Export and Import Tabsets Data"),
    /* @__PURE__ */ createBaseVNode("li", null, "Search in Tabs (experimental)"),
    /* @__PURE__ */ createBaseVNode("li", null, "Keep pinned and grouped tabsets (experimental)"),
    /* @__PURE__ */ createBaseVNode("li", null, "Thumbnails Preview (experimental)"),
    /* @__PURE__ */ createBaseVNode("li", null, "Dark Mode (experimental)"),
    /* @__PURE__ */ createBaseVNode("li", null, "All data remains on your computer - no backend communication whatsoever"),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Open source: see "),
      /* @__PURE__ */ createBaseVNode("a", {
        href: "https://www.github.com/evandor/tabsets",
        target: "_blank"
      }, "github project")
    ])
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Supported Browsers ", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, [
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, "Chrome"),
    /* @__PURE__ */ createBaseVNode("li", null, "Brave")
  ])
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Official Extension Website ", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, [
  /* @__PURE__ */ createBaseVNode("a", {
    href: "https://tabsets.web.app",
    target: "_blank"
  }, "https://tabsets.web.app")
], -1);
const _hoisted_16 = { key: 2 };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Get started ", -1);
const _hoisted_18 = { class: "text-body1 q-ma-md" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "About",
  setup(__props) {
    const appVersion = "0.2.3";
    const tabsStore = useTabsStore();
    const animateFab = () => useNotificationsStore().animateFab();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          _hoisted_1,
          createBaseVNode("div", _hoisted_2, "Version " + toDisplayString(unref(appVersion)), 1),
          unref(tabsStore).tabsets.size === 0 ? (openBlock(), createElementBlock("div", _hoisted_3, [
            createTextVNode(" Tabsets is a browser extension which helps you organize your tabs."),
            _hoisted_4,
            _hoisted_5,
            createTextVNode(" A "),
            _hoisted_6,
            createTextVNode(" is just a collection of tabs you can give a name to. ")
          ])) : (openBlock(), createElementBlock("div", _hoisted_7, [
            createTextVNode(" Tabsets is a browser extension which helps you organize your tabs."),
            _hoisted_8,
            _hoisted_9,
            createTextVNode(" You are managing "),
            createBaseVNode("b", null, toDisplayString(unref(tabsStore).allTabsCount) + " tabs", 1),
            createTextVNode(" in "),
            createBaseVNode("b", null, toDisplayString(unref(tabsStore).tabsets.size) + " Tabsets", 1),
            createTextVNode(" already. ")
          ])),
          _hoisted_10,
          _hoisted_11,
          _hoisted_12,
          _hoisted_13,
          _hoisted_14,
          _hoisted_15,
          unref(tabsStore).tabsets.size === 0 ? (openBlock(), createElementBlock("div", _hoisted_16, [
            _hoisted_17,
            createBaseVNode("div", _hoisted_18, [
              createTextVNode(" Click on the 'more' sign "),
              createVNode(QIcon, {
                name: "more_horiz",
                size: "24px",
                color: "accent",
                class: "cursor-pointer",
                onClick: _cache[0] || (_cache[0] = ($event) => animateFab())
              }),
              createTextVNode(" on the lower right page. ")
            ])
          ])) : createCommentVNode("", true),
          createVNode(_sfc_main$1)
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
