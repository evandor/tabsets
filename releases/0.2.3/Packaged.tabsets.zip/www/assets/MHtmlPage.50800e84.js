import { a as QToolbarTitle, Q as QToolbar } from "./QToolbar.8ddc4c0b.js";
import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { I as defineComponent, r as ref, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, b1 as useRoute, d as createVNode, M as createBaseVNode, aC as toDisplayString, ay as unref, aJ as QBtn, aA as createTextVNode, bF as IndexedDbPersistenceService } from "./index.ac7851bc.js";
import { Q as QPage } from "./QPage.d2025984.js";
import { d as date } from "./date.afb255f8.js";
const _hoisted_1 = { class: "row fit" };
const _hoisted_2 = { class: "col-xs-12 col-md-5" };
const _hoisted_3 = { class: "row justify-start items-baseline" };
const _hoisted_4 = { class: "col-1" };
const _hoisted_5 = { class: "text-dark" };
const _hoisted_6 = { class: "text-caption" };
const _hoisted_7 = { class: "col-xs-12 col-md-7 text-right" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("iframe", {
  id: "mhtmlframe",
  src: "data:text/html,<p>loading...</p>",
  frameBorder: "0",
  style: { "overflow": "hidden", "height": "100%", "width": "100%", "border": "0px" }
}, null, -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MHtmlPage",
  setup(__props) {
    const route = useRoute();
    const encodedUrl = ref();
    const title = ref();
    const created = ref("");
    watchEffect(() => {
      encodedUrl.value = route.params.encodedUrl;
      if (encodedUrl) {
        IndexedDbPersistenceService.getMHtmlInline(encodedUrl.value).then((res) => {
          var _a, _b, _c, _d;
          (_b = (_a = window.document) == null ? void 0 : _a.getElementById("mhtmlframe")) == null ? void 0 : _b.setAttribute("style", "overflow:hidden;height:" + (window.innerHeight - 50) + "px;width:100%;border:0px");
          (_d = (_c = window.document) == null ? void 0 : _c.getElementById("mhtmlframe")) == null ? void 0 : _d.setAttribute("srcdoc", res["html"]);
          title.value = res["title"];
          created.value = res["created"];
        });
      }
    });
    const openInNewTab = () => IndexedDbPersistenceService.getMHtml(encodedUrl.value);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          createVNode(QToolbar, { class: "text-primary" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createBaseVNode("div", _hoisted_2, [
                  createVNode(QToolbarTitle, { class: "q-mb-lg" }, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_3, [
                        createBaseVNode("div", _hoisted_4, [
                          createBaseVNode("span", _hoisted_5, "Archived Page: " + toDisplayString(title.value), 1)
                        ])
                      ]),
                      createBaseVNode("div", _hoisted_6, "Created " + toDisplayString(unref(date).formatDate(created.value, "DD.MM.YYYY HH:mm")), 1)
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("div", _hoisted_7, [
                  createVNode(QBtn, {
                    flat: "",
                    dense: "",
                    icon: "o_open_in_new",
                    color: "green",
                    label: "Open in new tab",
                    class: "q-mr-md",
                    onClick: openInNewTab
                  }, {
                    default: withCtx(() => [
                      createVNode(QTooltip, null, {
                        default: withCtx(() => [
                          createTextVNode("Open in new tab")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ])
              ])
            ]),
            _: 1
          }),
          _hoisted_8
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
