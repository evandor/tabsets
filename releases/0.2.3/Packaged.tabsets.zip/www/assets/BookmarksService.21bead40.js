import { aX as useBookmarksStore } from "./index.ac7851bc.js";
class BookmarksService {
  async init() {
  }
  deleteBookmarksFolder(folderId) {
    console.log("deleting folder", folderId);
    if (folderId && folderId !== "1") {
      chrome.bookmarks.removeTree(folderId);
    }
  }
  deleteBookmark(bm) {
    chrome.bookmarks.remove(bm.chromeBookmark.id);
    useBookmarksStore().remove(bm);
  }
}
var BookmarksService$1 = new BookmarksService();
export { BookmarksService$1 as B };
