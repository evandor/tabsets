import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { c as computed, n as createComponent, h, aJ as QBtn, i as inject, a1 as QIcon, H as hMergeSlot, g as getCurrentInstance, x as noop, bs as fabKey, ah as useModelToggleProps, aj as useModelToggleEmits, r as ref, aR as uid, am as useModelToggle, q as hSlot, s as provide, p as emptyRenderFn, t as layoutKey, I as defineComponent, aL as useSpacesStore, bk as STRIP_CHARS_IN_USER_INPUT, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, ay as unref, a8 as QDialog, L as useRouter, K as useQuasar, d as createVNode, aF as QCardSection, aG as QInput, aH as withKeys, M as createBaseVNode, aC as toDisplayString, aI as QCardActions, ap as withDirectives, aK as QCard, bt as SpacesService, J as useTabsStore, az as createElementBlock, bu as normalizeClass, au as useNotificationsStore, aA as createTextVNode, aB as createCommentVNode, F as Fragment, aY as Tab, bv as ChromeApi, ax as TabsetService } from "./index.ac7851bc.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
import { _ as _sfc_main$2 } from "./NewTabsetDialog.35dde97f.js";
import { _ as _sfc_main$3 } from "./ReindexDialog.ccfa929c.js";
const labelPositions = ["top", "right", "bottom", "left"];
const useFabProps = {
  type: {
    type: String,
    default: "a"
  },
  outline: Boolean,
  push: Boolean,
  flat: Boolean,
  unelevated: Boolean,
  color: String,
  textColor: String,
  glossy: Boolean,
  square: Boolean,
  padding: String,
  label: {
    type: [String, Number],
    default: ""
  },
  labelPosition: {
    type: String,
    default: "right",
    validator: (v) => labelPositions.includes(v)
  },
  externalLabel: Boolean,
  hideLabel: {
    type: Boolean
  },
  labelClass: [Array, String, Object],
  labelStyle: [Array, String, Object],
  disable: Boolean,
  tabindex: [Number, String]
};
function useFab(props, showing) {
  return {
    formClass: computed(
      () => `q-fab--form-${props.square === true ? "square" : "rounded"}`
    ),
    stacked: computed(
      () => props.externalLabel === false && ["top", "bottom"].includes(props.labelPosition)
    ),
    labelProps: computed(() => {
      if (props.externalLabel === true) {
        const hideLabel = props.hideLabel === null ? showing.value === false : props.hideLabel;
        return {
          action: "push",
          data: {
            class: [
              props.labelClass,
              `q-fab__label q-tooltip--style q-fab__label--external q-fab__label--external-${props.labelPosition}` + (hideLabel === true ? " q-fab__label--external-hidden" : "")
            ],
            style: props.labelStyle
          }
        };
      }
      return {
        action: ["left", "top"].includes(props.labelPosition) ? "unshift" : "push",
        data: {
          class: [
            props.labelClass,
            `q-fab__label q-fab__label--internal q-fab__label--internal-${props.labelPosition}` + (props.hideLabel === true ? " q-fab__label--internal-hidden" : "")
          ],
          style: props.labelStyle
        }
      };
    })
  };
}
const anchorMap = {
  start: "self-end",
  center: "self-center",
  end: "self-start"
};
const anchorValues = Object.keys(anchorMap);
var QFabAction = createComponent({
  name: "QFabAction",
  props: {
    ...useFabProps,
    icon: {
      type: String,
      default: ""
    },
    anchor: {
      type: String,
      validator: (v) => anchorValues.includes(v)
    },
    to: [String, Object],
    replace: Boolean
  },
  emits: ["click"],
  setup(props, { slots, emit }) {
    const $fab = inject(fabKey, () => ({
      showing: { value: true },
      onChildClick: noop
    }));
    const { formClass, labelProps } = useFab(props, $fab.showing);
    const classes = computed(() => {
      const align = anchorMap[props.anchor];
      return formClass.value + (align !== void 0 ? ` ${align}` : "");
    });
    const isDisabled = computed(
      () => props.disable === true || $fab.showing.value !== true
    );
    function click(e) {
      $fab.onChildClick(e);
      emit("click", e);
    }
    function getContent() {
      const child = [];
      if (slots.icon !== void 0) {
        child.push(slots.icon());
      } else if (props.icon !== "") {
        child.push(
          h(QIcon, { name: props.icon })
        );
      }
      if (props.label !== "" || slots.label !== void 0) {
        child[labelProps.value.action](
          h("div", labelProps.value.data, slots.label !== void 0 ? slots.label() : [props.label])
        );
      }
      return hMergeSlot(slots.default, child);
    }
    const vm = getCurrentInstance();
    Object.assign(vm.proxy, { click });
    return () => h(QBtn, {
      class: classes.value,
      ...props,
      noWrap: true,
      stack: props.stacked,
      icon: void 0,
      label: void 0,
      noCaps: true,
      fabMini: true,
      disable: isDisabled.value,
      onClick: click
    }, getContent);
  }
});
const directions = ["up", "right", "down", "left"];
const alignValues = ["left", "center", "right"];
var QFab = createComponent({
  name: "QFab",
  props: {
    ...useFabProps,
    ...useModelToggleProps,
    icon: String,
    activeIcon: String,
    hideIcon: Boolean,
    hideLabel: {
      default: null
    },
    direction: {
      type: String,
      default: "right",
      validator: (v) => directions.includes(v)
    },
    persistent: Boolean,
    verticalActionsAlign: {
      type: String,
      default: "center",
      validator: (v) => alignValues.includes(v)
    }
  },
  emits: useModelToggleEmits,
  setup(props, { slots }) {
    const triggerRef = ref(null);
    const showing = ref(props.modelValue === true);
    const targetUid = uid();
    const { proxy: { $q } } = getCurrentInstance();
    const { formClass, labelProps } = useFab(props, showing);
    const hideOnRouteChange = computed(() => props.persistent !== true);
    const { hide, toggle } = useModelToggle({
      showing,
      hideOnRouteChange
    });
    const slotScope = computed(() => ({ opened: showing.value }));
    const classes = computed(
      () => `q-fab z-fab row inline justify-center q-fab--align-${props.verticalActionsAlign} ${formClass.value}` + (showing.value === true ? " q-fab--opened" : " q-fab--closed")
    );
    const actionClass = computed(
      () => `q-fab__actions flex no-wrap inline q-fab__actions--${props.direction} q-fab__actions--${showing.value === true ? "opened" : "closed"}`
    );
    const actionAttrs = computed(() => {
      const attrs = {
        id: targetUid
      };
      if (showing.value === true) {
        attrs.role = "menu";
      } else {
        attrs["aria-hidden"] = "true";
      }
      return attrs;
    });
    const iconHolderClass = computed(
      () => `q-fab__icon-holder  q-fab__icon-holder--${showing.value === true ? "opened" : "closed"}`
    );
    function getIcon(kebab, camel) {
      const slotFn = slots[kebab];
      const classes2 = `q-fab__${kebab} absolute-full`;
      return slotFn === void 0 ? h(QIcon, { class: classes2, name: props[camel] || $q.iconSet.fab[camel] }) : h("div", { class: classes2 }, slotFn(slotScope.value));
    }
    function getTriggerContent() {
      const child = [];
      props.hideIcon !== true && child.push(
        h("div", { class: iconHolderClass.value }, [
          getIcon("icon", "icon"),
          getIcon("active-icon", "activeIcon")
        ])
      );
      if (props.label !== "" || slots.label !== void 0) {
        child[labelProps.value.action](
          h("div", labelProps.value.data, slots.label !== void 0 ? slots.label(slotScope.value) : [props.label])
        );
      }
      return hMergeSlot(slots.tooltip, child);
    }
    provide(fabKey, {
      showing,
      onChildClick(evt) {
        hide(evt);
        if (triggerRef.value !== null) {
          triggerRef.value.$el.focus();
        }
      }
    });
    return () => h("div", {
      class: classes.value
    }, [
      h(QBtn, {
        ref: triggerRef,
        class: formClass.value,
        ...props,
        noWrap: true,
        stack: props.stacked,
        align: void 0,
        icon: void 0,
        label: void 0,
        noCaps: true,
        fab: true,
        "aria-expanded": showing.value === true ? "true" : "false",
        "aria-haspopup": "true",
        "aria-controls": targetUid,
        "aria-owns": targetUid,
        onClick: toggle
      }, getTriggerContent),
      h("div", { class: actionClass.value, ...actionAttrs.value }, hSlot(slots.default))
    ]);
  }
});
const usePageStickyProps = {
  position: {
    type: String,
    default: "bottom-right",
    validator: (v) => [
      "top-right",
      "top-left",
      "bottom-right",
      "bottom-left",
      "top",
      "right",
      "bottom",
      "left"
    ].includes(v)
  },
  offset: {
    type: Array,
    validator: (v) => v.length === 2
  },
  expand: Boolean
};
function usePageSticky() {
  const { props, proxy: { $q } } = getCurrentInstance();
  const $layout = inject(layoutKey, emptyRenderFn);
  if ($layout === emptyRenderFn) {
    console.error("QPageSticky needs to be child of QLayout");
    return emptyRenderFn;
  }
  const attach = computed(() => {
    const pos = props.position;
    return {
      top: pos.indexOf("top") > -1,
      right: pos.indexOf("right") > -1,
      bottom: pos.indexOf("bottom") > -1,
      left: pos.indexOf("left") > -1,
      vertical: pos === "top" || pos === "bottom",
      horizontal: pos === "left" || pos === "right"
    };
  });
  const top = computed(() => $layout.header.offset);
  const right = computed(() => $layout.right.offset);
  const bottom = computed(() => $layout.footer.offset);
  const left = computed(() => $layout.left.offset);
  const style = computed(() => {
    let posX = 0, posY = 0;
    const side = attach.value;
    const dir = $q.lang.rtl === true ? -1 : 1;
    if (side.top === true && top.value !== 0) {
      posY = `${top.value}px`;
    } else if (side.bottom === true && bottom.value !== 0) {
      posY = `${-bottom.value}px`;
    }
    if (side.left === true && left.value !== 0) {
      posX = `${dir * left.value}px`;
    } else if (side.right === true && right.value !== 0) {
      posX = `${-dir * right.value}px`;
    }
    const css = { transform: `translate(${posX}, ${posY})` };
    if (props.offset) {
      css.margin = `${props.offset[1]}px ${props.offset[0]}px`;
    }
    if (side.vertical === true) {
      if (left.value !== 0) {
        css[$q.lang.rtl === true ? "right" : "left"] = `${left.value}px`;
      }
      if (right.value !== 0) {
        css[$q.lang.rtl === true ? "left" : "right"] = `${right.value}px`;
      }
    } else if (side.horizontal === true) {
      if (top.value !== 0) {
        css.top = `${top.value}px`;
      }
      if (bottom.value !== 0) {
        css.bottom = `${bottom.value}px`;
      }
    }
    return css;
  });
  const classes = computed(
    () => `q-page-sticky row flex-center fixed-${props.position} q-page-sticky--${props.expand === true ? "expand" : "shrink"}`
  );
  function getStickyContent(slots) {
    const content = hSlot(slots.default);
    return h(
      "div",
      {
        class: classes.value,
        style: style.value
      },
      props.expand === true ? content : [h("div", content)]
    );
  }
  return {
    $layout,
    getStickyContent
  };
}
var QPageSticky = createComponent({
  name: "QPageSticky",
  props: usePageStickyProps,
  setup(_, { slots }) {
    const { getStickyContent } = usePageSticky();
    return () => getStickyContent(slots);
  }
});
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Add new Space", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "A 'space' is a way to organize your tabsets. You can add tabsets to one or more spaces and select which space you want to be working on. ", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please provide a name for the new space", -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "New Space's name:", -1);
const _hoisted_5 = { class: "text-caption text-negative q-mt-none q-pt-none" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "NewSpaceDialog",
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const spacesStore = useSpacesStore();
    const router = useRouter();
    const $q = useQuasar();
    const newSpaceName = ref("");
    const newSpaceNameExists = ref(false);
    const hideWarning = ref(false);
    const newSpaceNameIsValid = computed(() => {
      return newSpaceName.value.length <= 32 && !STRIP_CHARS_IN_USER_INPUT.test(newSpaceName.value);
    });
    watchEffect(() => {
      newSpaceNameExists.value = !!spacesStore.nameExists(newSpaceName.value);
    });
    const createNewSpace = () => {
      hideWarning.value = true;
      SpacesService.addNewSpace(newSpaceName.value).then(() => {
        newSpaceName.value = "";
        let message = "New Space " + newSpaceName.value + " created successfully";
        hideWarning.value = false;
        router.push("/spaces");
        $q.notify({
          message,
          type: "positive"
        });
      }).catch((ex) => {
        console.error("ex", ex);
        hideWarning.value = false;
        $q.notify({
          message: "There was a problem creating the Space " + newSpaceName.value,
          type: "warning"
        });
      });
    };
    const newSpaceDialogWarning = () => {
      return !hideWarning.value && spacesStore.nameExists(newSpaceName.value) ? "Space's name already exists!" : "";
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1$1
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$1
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_3$1
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  _hoisted_4$1,
                  createVNode(QInput, {
                    modelValue: newSpaceName.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newSpaceName.value = $event),
                    class: "q-mb-none q-pb-none",
                    dense: "",
                    autofocus: "",
                    "error-message": "Please do not use special Characters, maximum length is 32",
                    error: !unref(newSpaceNameIsValid),
                    "data-testid": "newSpaceName",
                    onKeydown: _cache[1] || (_cache[1] = withKeys(($event) => createNewSpace(), ["enter"]))
                  }, null, 8, ["modelValue", "error"]),
                  createBaseVNode("div", _hoisted_5, toDisplayString(newSpaceDialogWarning()), 1)
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    "data-testid": "newSpaceNameSubmit",
                    label: "Create new Space",
                    disable: newSpaceName.value.trim().length === 0 || newSpaceDialogWarning().length > 0,
                    onClick: _cache[2] || (_cache[2] = ($event) => createNewSpace())
                  }, null, 8, ["disable"]), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Add Url to current tabset", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please provide the url to be added", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Url:", -1);
const _hoisted_4 = { class: "text-body2 text-warning" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Fab",
  setup(__props) {
    const tabsStore = useTabsStore();
    useRouter();
    const $q = useQuasar();
    const url = ref("");
    const showNewTabsetDialog = ref(false);
    const showNewUrlDialog = ref(false);
    const showReindexDialog = ref(false);
    const newSpaceDialog = ref(false);
    watchEffect(() => {
      if (showNewTabsetDialog.value) {
        $q.dialog({
          component: _sfc_main$2
        }).onDismiss(() => {
          showNewTabsetDialog.value = false;
        });
      }
    });
    watchEffect(() => {
      if (showReindexDialog.value) {
        $q.dialog({
          component: _sfc_main$3,
          componentProps: {
            tabsetId: tabsStore.currentTabsetId
          }
        }).onDismiss(() => {
          showReindexDialog.value = false;
        });
      }
    });
    watchEffect(() => {
      if (newSpaceDialog.value) {
        $q.dialog({
          component: _sfc_main$1,
          componentProps: {
            tabsetId: tabsStore.currentTabsetId
          }
        }).onDismiss(() => {
          newSpaceDialog.value = false;
        });
      }
    });
    const createNewUrl = () => {
      console.log("new url", url.value);
      const tab = new Tab(uid(), null);
      tab.created = new Date().getTime();
      tab.chromeTab = ChromeApi.createChromeTabObject(url.value, url.value, null);
      TabsetService.saveToCurrentTabset(tab);
    };
    const newUrlDialogWarning = () => {
      try {
        new URL(url.value);
        return "";
      } catch (err) {
        return "not a proper URL";
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QPageSticky, {
          position: "bottom-right",
          offset: [80, 60]
        }, {
          default: withCtx(() => [
            createVNode(QFab, {
              "data-testid": "fab_widget",
              class: normalizeClass({
                "heartBeat animated": unref(useNotificationsStore)().fabHasElementAnimation,
                "rotateIn animated": unref(useNotificationsStore)().fabHasElementAnimation
              }),
              icon: "more_horiz",
              direction: "up",
              color: "primary"
            }, {
              default: withCtx(() => [
                createVNode(QFabAction, {
                  onClick: _cache[0] || (_cache[0] = ($event) => showNewTabsetDialog.value = true),
                  style: { "width": "170px" },
                  color: "primary",
                  icon: "tabs",
                  label: "New Tabset"
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("Start a new tabset by assigning your open tabs")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                unref(tabsStore).currentTabsetId !== "" && unref(tabsStore).getTabset(unref(tabsStore).currentTabsetId) ? (openBlock(), createBlock(QFabAction, {
                  key: 0,
                  "data-testid": "fab_add_url",
                  onClick: _cache[1] || (_cache[1] = ($event) => showNewUrlDialog.value = true),
                  style: { "width": "170px" },
                  color: "primary",
                  icon: "link",
                  label: "Add Url"
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("Add a Url to the current tabset manually '" + toDisplayString(unref(tabsStore).currentTabsetId) + "'", 1)
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })) : createCommentVNode("", true),
                unref(tabsStore).getCurrentTabs.length > 0 ? (openBlock(), createBlock(QFabAction, {
                  key: 1,
                  onClick: _cache[2] || (_cache[2] = ($event) => newSpaceDialog.value = true),
                  style: { "width": "170px" },
                  color: "accent",
                  icon: "workspaces",
                  label: "Create a new Space"
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("Create a new Space to organize your tabsets")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })) : createCommentVNode("", true),
                unref(tabsStore).currentTabsetId !== "" && unref(tabsStore).getTabset(unref(tabsStore).currentTabsetId) ? (openBlock(), createBlock(QFabAction, {
                  key: 2,
                  onClick: _cache[3] || (_cache[3] = ($event) => showReindexDialog.value = true),
                  style: { "width": "200px" },
                  color: "warning",
                  icon: "database",
                  label: "Re-Index Tabset..."
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("If you are not happy with the search result, you can try to re-index this tabset.")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })) : createCommentVNode("", true)
              ]),
              _: 1
            }, 8, ["class"])
          ]),
          _: 1
        }),
        createVNode(QDialog, {
          modelValue: showNewUrlDialog.value,
          "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => showNewUrlDialog.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(QCard, { style: { "min-width": "350px" } }, {
              default: withCtx(() => [
                createVNode(QCardSection, null, {
                  default: withCtx(() => [
                    _hoisted_1
                  ]),
                  _: 1
                }),
                createVNode(QCardSection, null, {
                  default: withCtx(() => [
                    _hoisted_2
                  ]),
                  _: 1
                }),
                createVNode(QCardSection, { class: "q-pt-none" }, {
                  default: withCtx(() => [
                    _hoisted_3,
                    createVNode(QInput, {
                      dense: "",
                      modelValue: url.value,
                      "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => url.value = $event),
                      "data-testid": "fab_add_url_input",
                      autofocus: "",
                      onKeyup: _cache[5] || (_cache[5] = withKeys(($event) => _ctx.prompt = false, ["enter"]))
                    }, null, 8, ["modelValue"]),
                    createBaseVNode("div", _hoisted_4, toDisplayString(newUrlDialogWarning()), 1)
                  ]),
                  _: 1
                }),
                createVNode(QCardActions, {
                  align: "right",
                  class: "text-primary"
                }, {
                  default: withCtx(() => [
                    withDirectives(createVNode(QBtn, {
                      flat: "",
                      label: "Cancel"
                    }, null, 512), [
                      [ClosePopup]
                    ]),
                    withDirectives(createVNode(QBtn, {
                      flat: "",
                      label: "Add URL",
                      "data-testid": "fab_add_url_submit",
                      disable: url.value.trim().length === 0,
                      onClick: _cache[6] || (_cache[6] = ($event) => createNewUrl())
                    }, null, 8, ["disable"]), [
                      [ClosePopup]
                    ])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 64);
    };
  }
});
export { _sfc_main as _ };
