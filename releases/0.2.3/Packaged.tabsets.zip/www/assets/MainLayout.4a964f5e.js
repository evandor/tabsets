import { n as createComponent, N as useFieldProps, O as useFieldEmits, P as useField, Q as useFieldState, x as noop, r as ref, c as computed, w as watch, R as debounce, S as onBeforeMount, U as onDeactivated, V as onActivated, v as onBeforeUnmount, D as nextTick, h, g as getCurrentInstance, W as useFormProps, X as useFormInputNameAttr, Y as fieldValueIsFilled, Z as isDeepEqual, _ as onBeforeUpdate, $ as onUpdated, a0 as prevent, a1 as QIcon, a2 as useKeyComposition, a3 as stop, a4 as normalizeToInterval, a5 as isKeyCode, a6 as shouldIgnoreKey, a7 as stopAndPrevent, a8 as QDialog, H as hMergeSlot, p as emptyRenderFn, a9 as hUniqueSlot, i as inject, t as layoutKey, aa as createDirective, ab as client, ac as leftClick, ad as addEvt, ae as preventDraggable, af as position, ag as cleanEvt, ah as useModelToggleProps, ai as useDarkProps, aj as useModelToggleEmits, ak as useDark, al as useTimeout, am as useModelToggle, an as useHistory, ao as between, o as onMounted, ap as withDirectives, aq as hDir, q as hSlot, ar as usePreventScroll, as as planClientUpdate, a as onUnmounted, at as clientList, I as defineComponent, au as useNotificationsStore, av as useFeatureTogglesStore, L as useRouter, aw as watchEffect, ax as TabsetService, ay as unref, j as openBlock, az as createElementBlock, M as createBaseVNode, aA as createTextVNode, k as createBlock, l as withCtx, aB as createCommentVNode, d as createVNode, aC as toDisplayString, aD as withModifiers, aE as Navigation$1, J as useTabsStore, K as useQuasar, aF as QCardSection, aG as QInput, aH as withKeys, aI as QCardActions, aJ as QBtn, aK as QCard, aL as useSpacesStore, F as Fragment, aM as renderList, aN as normalizeStyle, aO as Ripple, aP as _, aQ as tabsKey, aR as uid$1, aS as useTick, s as provide, aT as QSpinner, aU as QCheckbox, aV as vShow, aW as injectProp, aX as useBookmarksStore, aY as Tab, aZ as QSeparator, a_ as MHtmlService, a$ as QRadio, b0 as useSearchStore, b1 as useRoute, m as resolveComponent } from "./index.ac7851bc.js";
import { Q as QToolbar, a as QToolbarTitle } from "./QToolbar.8ddc4c0b.js";
import { Q as QChip } from "./QChip.0a3a1859.js";
import { Q as QMenu, a as QBadge } from "./QMenu.39c979c3.js";
import { Q as QItemSection, a as QItemLabel, b as QItem, c as QList } from "./QList.06a62e31.js";
import { b as QResizeObserver, Q as QLayout, a as QPageContainer } from "./QLayout.53a3ecac.js";
import { c as clearSelection, Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
import { Q as QBanner, a as QSlideTransition, V as VueDraggableNext } from "./vue-draggable-next.esm-bundler.d5869de7.js";
import { Q as QImg } from "./QImg.0869baf7.js";
import { d as date } from "./date.afb255f8.js";
import { _ as _export_sfc } from "./plugin-vue_export-helper.21dcd24c.js";
import { B as BookmarksService } from "./BookmarksService.21bead40.js";
import { _ as _sfc_main$b } from "./NewTabsetDialog.35dde97f.js";
var QField = createComponent({
  name: "QField",
  inheritAttrs: false,
  props: useFieldProps,
  emits: useFieldEmits,
  setup() {
    return useField(useFieldState());
  }
});
let rtlHasScrollBug = false;
{
  const scroller = document.createElement("div");
  scroller.setAttribute("dir", "rtl");
  Object.assign(scroller.style, {
    width: "1px",
    height: "1px",
    overflow: "auto"
  });
  const spacer = document.createElement("div");
  Object.assign(spacer.style, {
    width: "1000px",
    height: "1px"
  });
  document.body.appendChild(scroller);
  scroller.appendChild(spacer);
  scroller.scrollLeft = -1e3;
  rtlHasScrollBug = scroller.scrollLeft >= 0;
  scroller.remove();
}
const aggBucketSize = 1e3;
const scrollToEdges = [
  "start",
  "center",
  "end",
  "start-force",
  "center-force",
  "end-force"
];
const filterProto = Array.prototype.filter;
const setOverflowAnchor = window.getComputedStyle(document.body).overflowAnchor === void 0 ? noop : function(contentEl, index) {
  if (contentEl === null) {
    return;
  }
  cancelAnimationFrame(contentEl._qOverflowAnimationFrame);
  contentEl._qOverflowAnimationFrame = requestAnimationFrame(() => {
    if (contentEl === null) {
      return;
    }
    const children = contentEl.children || [];
    filterProto.call(children, (el2) => el2.dataset && el2.dataset.qVsAnchor !== void 0).forEach((el2) => {
      delete el2.dataset.qVsAnchor;
    });
    const el = children[index];
    if (el && el.dataset) {
      el.dataset.qVsAnchor = "";
    }
  });
};
function sumFn(acc, h2) {
  return acc + h2;
}
function getScrollDetails(parent, child, beforeRef, afterRef, horizontal, rtl, stickyStart, stickyEnd) {
  const parentCalc = parent === window ? document.scrollingElement || document.documentElement : parent, propElSize = horizontal === true ? "offsetWidth" : "offsetHeight", details = {
    scrollStart: 0,
    scrollViewSize: -stickyStart - stickyEnd,
    scrollMaxSize: 0,
    offsetStart: -stickyStart,
    offsetEnd: -stickyEnd
  };
  if (horizontal === true) {
    if (parent === window) {
      details.scrollStart = window.pageXOffset || window.scrollX || document.body.scrollLeft || 0;
      details.scrollViewSize += document.documentElement.clientWidth;
    } else {
      details.scrollStart = parentCalc.scrollLeft;
      details.scrollViewSize += parentCalc.clientWidth;
    }
    details.scrollMaxSize = parentCalc.scrollWidth;
    if (rtl === true) {
      details.scrollStart = (rtlHasScrollBug === true ? details.scrollMaxSize - details.scrollViewSize : 0) - details.scrollStart;
    }
  } else {
    if (parent === window) {
      details.scrollStart = window.pageYOffset || window.scrollY || document.body.scrollTop || 0;
      details.scrollViewSize += document.documentElement.clientHeight;
    } else {
      details.scrollStart = parentCalc.scrollTop;
      details.scrollViewSize += parentCalc.clientHeight;
    }
    details.scrollMaxSize = parentCalc.scrollHeight;
  }
  if (beforeRef !== null) {
    for (let el = beforeRef.previousElementSibling; el !== null; el = el.previousElementSibling) {
      if (el.classList.contains("q-virtual-scroll--skip") === false) {
        details.offsetStart += el[propElSize];
      }
    }
  }
  if (afterRef !== null) {
    for (let el = afterRef.nextElementSibling; el !== null; el = el.nextElementSibling) {
      if (el.classList.contains("q-virtual-scroll--skip") === false) {
        details.offsetEnd += el[propElSize];
      }
    }
  }
  if (child !== parent) {
    const parentRect = parentCalc.getBoundingClientRect(), childRect = child.getBoundingClientRect();
    if (horizontal === true) {
      details.offsetStart += childRect.left - parentRect.left;
      details.offsetEnd -= childRect.width;
    } else {
      details.offsetStart += childRect.top - parentRect.top;
      details.offsetEnd -= childRect.height;
    }
    if (parent !== window) {
      details.offsetStart += details.scrollStart;
    }
    details.offsetEnd += details.scrollMaxSize - details.offsetStart;
  }
  return details;
}
function setScroll(parent, scroll, horizontal, rtl) {
  if (scroll === "end") {
    scroll = (parent === window ? document.body : parent)[horizontal === true ? "scrollWidth" : "scrollHeight"];
  }
  if (parent === window) {
    if (horizontal === true) {
      if (rtl === true) {
        scroll = (rtlHasScrollBug === true ? document.body.scrollWidth - document.documentElement.clientWidth : 0) - scroll;
      }
      window.scrollTo(scroll, window.pageYOffset || window.scrollY || document.body.scrollTop || 0);
    } else {
      window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, scroll);
    }
  } else if (horizontal === true) {
    if (rtl === true) {
      scroll = (rtlHasScrollBug === true ? parent.scrollWidth - parent.offsetWidth : 0) - scroll;
    }
    parent.scrollLeft = scroll;
  } else {
    parent.scrollTop = scroll;
  }
}
function sumSize(sizeAgg, size, from, to) {
  if (from >= to) {
    return 0;
  }
  const lastTo = size.length, fromAgg = Math.floor(from / aggBucketSize), toAgg = Math.floor((to - 1) / aggBucketSize) + 1;
  let total = sizeAgg.slice(fromAgg, toAgg).reduce(sumFn, 0);
  if (from % aggBucketSize !== 0) {
    total -= size.slice(fromAgg * aggBucketSize, from).reduce(sumFn, 0);
  }
  if (to % aggBucketSize !== 0 && to !== lastTo) {
    total -= size.slice(to, toAgg * aggBucketSize).reduce(sumFn, 0);
  }
  return total;
}
const commonVirtScrollProps = {
  virtualScrollSliceSize: {
    type: [Number, String],
    default: null
  },
  virtualScrollSliceRatioBefore: {
    type: [Number, String],
    default: 1
  },
  virtualScrollSliceRatioAfter: {
    type: [Number, String],
    default: 1
  },
  virtualScrollItemSize: {
    type: [Number, String],
    default: 24
  },
  virtualScrollStickySizeStart: {
    type: [Number, String],
    default: 0
  },
  virtualScrollStickySizeEnd: {
    type: [Number, String],
    default: 0
  },
  tableColspan: [Number, String]
};
const useVirtualScrollProps = {
  virtualScrollHorizontal: Boolean,
  onVirtualScroll: Function,
  ...commonVirtScrollProps
};
function useVirtualScroll({
  virtualScrollLength,
  getVirtualScrollTarget,
  getVirtualScrollEl,
  virtualScrollItemSizeComputed
}) {
  const vm = getCurrentInstance();
  const { props, emit, proxy } = vm;
  const { $q } = proxy;
  let prevScrollStart, prevToIndex, localScrollViewSize, virtualScrollSizesAgg = [], virtualScrollSizes;
  const virtualScrollPaddingBefore = ref(0);
  const virtualScrollPaddingAfter = ref(0);
  const virtualScrollSliceSizeComputed = ref({});
  const beforeRef = ref(null);
  const afterRef = ref(null);
  const contentRef = ref(null);
  const virtualScrollSliceRange = ref({ from: 0, to: 0 });
  const colspanAttr = computed(() => props.tableColspan !== void 0 ? props.tableColspan : 100);
  if (virtualScrollItemSizeComputed === void 0) {
    virtualScrollItemSizeComputed = computed(() => props.virtualScrollItemSize);
  }
  const needsReset = computed(() => virtualScrollItemSizeComputed.value + ";" + props.virtualScrollHorizontal);
  const needsSliceRecalc = computed(
    () => needsReset.value + ";" + props.virtualScrollSliceRatioBefore + ";" + props.virtualScrollSliceRatioAfter
  );
  watch(needsSliceRecalc, () => {
    setVirtualScrollSize();
  });
  watch(needsReset, reset);
  function reset() {
    localResetVirtualScroll(prevToIndex, true);
  }
  function refresh(toIndex) {
    localResetVirtualScroll(toIndex === void 0 ? prevToIndex : toIndex);
  }
  function scrollTo(toIndex, edge) {
    const scrollEl = getVirtualScrollTarget();
    if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) {
      return;
    }
    const scrollDetails = getScrollDetails(
      scrollEl,
      getVirtualScrollEl(),
      beforeRef.value,
      afterRef.value,
      props.virtualScrollHorizontal,
      $q.lang.rtl,
      props.virtualScrollStickySizeStart,
      props.virtualScrollStickySizeEnd
    );
    localScrollViewSize !== scrollDetails.scrollViewSize && setVirtualScrollSize(scrollDetails.scrollViewSize);
    setVirtualScrollSliceRange(
      scrollEl,
      scrollDetails,
      Math.min(virtualScrollLength.value - 1, Math.max(0, parseInt(toIndex, 10) || 0)),
      0,
      scrollToEdges.indexOf(edge) > -1 ? edge : prevToIndex > -1 && toIndex > prevToIndex ? "end" : "start"
    );
  }
  function localOnVirtualScrollEvt() {
    const scrollEl = getVirtualScrollTarget();
    if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) {
      return;
    }
    const scrollDetails = getScrollDetails(
      scrollEl,
      getVirtualScrollEl(),
      beforeRef.value,
      afterRef.value,
      props.virtualScrollHorizontal,
      $q.lang.rtl,
      props.virtualScrollStickySizeStart,
      props.virtualScrollStickySizeEnd
    ), listLastIndex = virtualScrollLength.value - 1, listEndOffset = scrollDetails.scrollMaxSize - scrollDetails.offsetStart - scrollDetails.offsetEnd - virtualScrollPaddingAfter.value;
    if (prevScrollStart === scrollDetails.scrollStart) {
      return;
    }
    if (scrollDetails.scrollMaxSize <= 0) {
      setVirtualScrollSliceRange(scrollEl, scrollDetails, 0, 0);
      return;
    }
    localScrollViewSize !== scrollDetails.scrollViewSize && setVirtualScrollSize(scrollDetails.scrollViewSize);
    updateVirtualScrollSizes(virtualScrollSliceRange.value.from);
    const scrollMaxStart = Math.floor(scrollDetails.scrollMaxSize - Math.max(scrollDetails.scrollViewSize, scrollDetails.offsetEnd) - Math.min(virtualScrollSizes[listLastIndex], scrollDetails.scrollViewSize / 2));
    if (scrollMaxStart > 0 && Math.ceil(scrollDetails.scrollStart) >= scrollMaxStart) {
      setVirtualScrollSliceRange(
        scrollEl,
        scrollDetails,
        listLastIndex,
        scrollDetails.scrollMaxSize - scrollDetails.offsetEnd - virtualScrollSizesAgg.reduce(sumFn, 0)
      );
      return;
    }
    let toIndex = 0, listOffset = scrollDetails.scrollStart - scrollDetails.offsetStart, offset = listOffset;
    if (listOffset <= listEndOffset && listOffset + scrollDetails.scrollViewSize >= virtualScrollPaddingBefore.value) {
      listOffset -= virtualScrollPaddingBefore.value;
      toIndex = virtualScrollSliceRange.value.from;
      offset = listOffset;
    } else {
      for (let j = 0; listOffset >= virtualScrollSizesAgg[j] && toIndex < listLastIndex; j++) {
        listOffset -= virtualScrollSizesAgg[j];
        toIndex += aggBucketSize;
      }
    }
    while (listOffset > 0 && toIndex < listLastIndex) {
      listOffset -= virtualScrollSizes[toIndex];
      if (listOffset > -scrollDetails.scrollViewSize) {
        toIndex++;
        offset = listOffset;
      } else {
        offset = virtualScrollSizes[toIndex] + listOffset;
      }
    }
    setVirtualScrollSliceRange(
      scrollEl,
      scrollDetails,
      toIndex,
      offset
    );
  }
  function setVirtualScrollSliceRange(scrollEl, scrollDetails, toIndex, offset, align) {
    const alignForce = typeof align === "string" && align.indexOf("-force") > -1;
    const alignEnd = alignForce === true ? align.replace("-force", "") : align;
    const alignRange = alignEnd !== void 0 ? alignEnd : "start";
    let from = Math.max(0, toIndex - virtualScrollSliceSizeComputed.value[alignRange]), to = from + virtualScrollSliceSizeComputed.value.total;
    if (to > virtualScrollLength.value) {
      to = virtualScrollLength.value;
      from = Math.max(0, to - virtualScrollSliceSizeComputed.value.total);
    }
    prevScrollStart = scrollDetails.scrollStart;
    const rangeChanged = from !== virtualScrollSliceRange.value.from || to !== virtualScrollSliceRange.value.to;
    if (rangeChanged === false && alignEnd === void 0) {
      emitScroll(toIndex);
      return;
    }
    const { activeElement } = document;
    const contentEl = contentRef.value;
    if (rangeChanged === true && contentEl !== null && contentEl !== activeElement && contentEl.contains(activeElement) === true) {
      contentEl.addEventListener("focusout", onBlurRefocusFn);
      setTimeout(() => {
        contentEl !== null && contentEl.removeEventListener("focusout", onBlurRefocusFn);
      });
    }
    setOverflowAnchor(contentEl, toIndex - from);
    const sizeBefore = alignEnd !== void 0 ? virtualScrollSizes.slice(from, toIndex).reduce(sumFn, 0) : 0;
    if (rangeChanged === true) {
      const tempTo = to >= virtualScrollSliceRange.value.from && from <= virtualScrollSliceRange.value.to ? virtualScrollSliceRange.value.to : to;
      virtualScrollSliceRange.value = { from, to: tempTo };
      virtualScrollPaddingBefore.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, 0, from);
      virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, to, virtualScrollLength.value);
      requestAnimationFrame(() => {
        if (virtualScrollSliceRange.value.to !== to && prevScrollStart === scrollDetails.scrollStart) {
          virtualScrollSliceRange.value = { from: virtualScrollSliceRange.value.from, to };
          virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, to, virtualScrollLength.value);
        }
      });
    }
    requestAnimationFrame(() => {
      if (prevScrollStart !== scrollDetails.scrollStart) {
        return;
      }
      if (rangeChanged === true) {
        updateVirtualScrollSizes(from);
      }
      const sizeAfter = virtualScrollSizes.slice(from, toIndex).reduce(sumFn, 0), posStart = sizeAfter + scrollDetails.offsetStart + virtualScrollPaddingBefore.value, posEnd = posStart + virtualScrollSizes[toIndex];
      let scrollPosition = posStart + offset;
      if (alignEnd !== void 0) {
        const sizeDiff = sizeAfter - sizeBefore;
        const scrollStart = scrollDetails.scrollStart + sizeDiff;
        scrollPosition = alignForce !== true && scrollStart < posStart && posEnd < scrollStart + scrollDetails.scrollViewSize ? scrollStart : alignEnd === "end" ? posEnd - scrollDetails.scrollViewSize : posStart - (alignEnd === "start" ? 0 : Math.round((scrollDetails.scrollViewSize - virtualScrollSizes[toIndex]) / 2));
      }
      prevScrollStart = scrollPosition;
      setScroll(
        scrollEl,
        scrollPosition,
        props.virtualScrollHorizontal,
        $q.lang.rtl
      );
      emitScroll(toIndex);
    });
  }
  function updateVirtualScrollSizes(from) {
    const contentEl = contentRef.value;
    if (contentEl) {
      const children = filterProto.call(
        contentEl.children,
        (el) => el.classList && el.classList.contains("q-virtual-scroll--skip") === false
      ), childrenLength = children.length, sizeFn = props.virtualScrollHorizontal === true ? (el) => el.getBoundingClientRect().width : (el) => el.offsetHeight;
      let index = from, size, diff;
      for (let i = 0; i < childrenLength; ) {
        size = sizeFn(children[i]);
        i++;
        while (i < childrenLength && children[i].classList.contains("q-virtual-scroll--with-prev") === true) {
          size += sizeFn(children[i]);
          i++;
        }
        diff = size - virtualScrollSizes[index];
        if (diff !== 0) {
          virtualScrollSizes[index] += diff;
          virtualScrollSizesAgg[Math.floor(index / aggBucketSize)] += diff;
        }
        index++;
      }
    }
  }
  function onBlurRefocusFn() {
    contentRef.value !== null && contentRef.value !== void 0 && contentRef.value.focus();
  }
  function localResetVirtualScroll(toIndex, fullReset) {
    const defaultSize = 1 * virtualScrollItemSizeComputed.value;
    if (fullReset === true || Array.isArray(virtualScrollSizes) === false) {
      virtualScrollSizes = [];
    }
    const oldVirtualScrollSizesLength = virtualScrollSizes.length;
    virtualScrollSizes.length = virtualScrollLength.value;
    for (let i = virtualScrollLength.value - 1; i >= oldVirtualScrollSizesLength; i--) {
      virtualScrollSizes[i] = defaultSize;
    }
    const jMax = Math.floor((virtualScrollLength.value - 1) / aggBucketSize);
    virtualScrollSizesAgg = [];
    for (let j = 0; j <= jMax; j++) {
      let size = 0;
      const iMax = Math.min((j + 1) * aggBucketSize, virtualScrollLength.value);
      for (let i = j * aggBucketSize; i < iMax; i++) {
        size += virtualScrollSizes[i];
      }
      virtualScrollSizesAgg.push(size);
    }
    prevToIndex = -1;
    prevScrollStart = void 0;
    virtualScrollPaddingBefore.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, 0, virtualScrollSliceRange.value.from);
    virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, virtualScrollSliceRange.value.to, virtualScrollLength.value);
    if (toIndex >= 0) {
      updateVirtualScrollSizes(virtualScrollSliceRange.value.from);
      nextTick(() => {
        scrollTo(toIndex);
      });
    } else {
      onVirtualScrollEvt();
    }
  }
  function setVirtualScrollSize(scrollViewSize) {
    if (scrollViewSize === void 0 && typeof window !== "undefined") {
      const scrollEl = getVirtualScrollTarget();
      if (scrollEl !== void 0 && scrollEl !== null && scrollEl.nodeType !== 8) {
        scrollViewSize = getScrollDetails(
          scrollEl,
          getVirtualScrollEl(),
          beforeRef.value,
          afterRef.value,
          props.virtualScrollHorizontal,
          $q.lang.rtl,
          props.virtualScrollStickySizeStart,
          props.virtualScrollStickySizeEnd
        ).scrollViewSize;
      }
    }
    localScrollViewSize = scrollViewSize;
    const virtualScrollSliceRatioBefore = parseFloat(props.virtualScrollSliceRatioBefore) || 0;
    const virtualScrollSliceRatioAfter = parseFloat(props.virtualScrollSliceRatioAfter) || 0;
    const multiplier = 1 + virtualScrollSliceRatioBefore + virtualScrollSliceRatioAfter;
    const view = scrollViewSize === void 0 || scrollViewSize <= 0 ? 1 : Math.ceil(scrollViewSize / virtualScrollItemSizeComputed.value);
    const baseSize = Math.max(
      1,
      view,
      Math.ceil((props.virtualScrollSliceSize > 0 ? props.virtualScrollSliceSize : 10) / multiplier)
    );
    virtualScrollSliceSizeComputed.value = {
      total: Math.ceil(baseSize * multiplier),
      start: Math.ceil(baseSize * virtualScrollSliceRatioBefore),
      center: Math.ceil(baseSize * (0.5 + virtualScrollSliceRatioBefore)),
      end: Math.ceil(baseSize * (1 + virtualScrollSliceRatioBefore)),
      view
    };
  }
  function padVirtualScroll(tag, content) {
    const paddingSize = props.virtualScrollHorizontal === true ? "width" : "height";
    const style = {
      ["--q-virtual-scroll-item-" + paddingSize]: virtualScrollItemSizeComputed.value + "px"
    };
    return [
      tag === "tbody" ? h(tag, {
        class: "q-virtual-scroll__padding",
        key: "before",
        ref: beforeRef
      }, [
        h("tr", [
          h("td", {
            style: { [paddingSize]: `${virtualScrollPaddingBefore.value}px`, ...style },
            colspan: colspanAttr.value
          })
        ])
      ]) : h(tag, {
        class: "q-virtual-scroll__padding",
        key: "before",
        ref: beforeRef,
        style: { [paddingSize]: `${virtualScrollPaddingBefore.value}px`, ...style }
      }),
      h(tag, {
        class: "q-virtual-scroll__content",
        key: "content",
        ref: contentRef,
        tabindex: -1
      }, content.flat()),
      tag === "tbody" ? h(tag, {
        class: "q-virtual-scroll__padding",
        key: "after",
        ref: afterRef
      }, [
        h("tr", [
          h("td", {
            style: { [paddingSize]: `${virtualScrollPaddingAfter.value}px`, ...style },
            colspan: colspanAttr.value
          })
        ])
      ]) : h(tag, {
        class: "q-virtual-scroll__padding",
        key: "after",
        ref: afterRef,
        style: { [paddingSize]: `${virtualScrollPaddingAfter.value}px`, ...style }
      })
    ];
  }
  function emitScroll(index) {
    if (prevToIndex !== index) {
      props.onVirtualScroll !== void 0 && emit("virtualScroll", {
        index,
        from: virtualScrollSliceRange.value.from,
        to: virtualScrollSliceRange.value.to - 1,
        direction: index < prevToIndex ? "decrease" : "increase",
        ref: proxy
      });
      prevToIndex = index;
    }
  }
  setVirtualScrollSize();
  const onVirtualScrollEvt = debounce(
    localOnVirtualScrollEvt,
    $q.platform.is.ios === true ? 120 : 35
  );
  onBeforeMount(() => {
    setVirtualScrollSize();
  });
  let shouldActivate = false;
  onDeactivated(() => {
    shouldActivate = true;
  });
  onActivated(() => {
    if (shouldActivate !== true) {
      return;
    }
    const scrollEl = getVirtualScrollTarget();
    if (prevScrollStart !== void 0 && scrollEl !== void 0 && scrollEl !== null && scrollEl.nodeType !== 8) {
      setScroll(
        scrollEl,
        prevScrollStart,
        props.virtualScrollHorizontal,
        $q.lang.rtl
      );
    } else {
      scrollTo(prevToIndex);
    }
  });
  onBeforeUnmount(() => {
    onVirtualScrollEvt.cancel();
  });
  Object.assign(proxy, { scrollTo, reset, refresh });
  return {
    virtualScrollSliceRange,
    virtualScrollSliceSizeComputed,
    setVirtualScrollSize,
    onVirtualScrollEvt,
    localResetVirtualScroll,
    padVirtualScroll,
    scrollTo,
    reset,
    refresh
  };
}
const validateNewValueMode = (v) => ["add", "add-unique", "toggle"].includes(v);
const reEscapeList = ".*+?^${}()|[]\\";
const fieldPropsList = Object.keys(useFieldProps);
var QSelect = createComponent({
  name: "QSelect",
  inheritAttrs: false,
  props: {
    ...useVirtualScrollProps,
    ...useFormProps,
    ...useFieldProps,
    modelValue: {
      required: true
    },
    multiple: Boolean,
    displayValue: [String, Number],
    displayValueHtml: Boolean,
    dropdownIcon: String,
    options: {
      type: Array,
      default: () => []
    },
    optionValue: [Function, String],
    optionLabel: [Function, String],
    optionDisable: [Function, String],
    hideSelected: Boolean,
    hideDropdownIcon: Boolean,
    fillInput: Boolean,
    maxValues: [Number, String],
    optionsDense: Boolean,
    optionsDark: {
      type: Boolean,
      default: null
    },
    optionsSelectedClass: String,
    optionsHtml: Boolean,
    optionsCover: Boolean,
    menuShrink: Boolean,
    menuAnchor: String,
    menuSelf: String,
    menuOffset: Array,
    popupContentClass: String,
    popupContentStyle: [String, Array, Object],
    useInput: Boolean,
    useChips: Boolean,
    newValueMode: {
      type: String,
      validator: validateNewValueMode
    },
    mapOptions: Boolean,
    emitValue: Boolean,
    inputDebounce: {
      type: [Number, String],
      default: 500
    },
    inputClass: [Array, String, Object],
    inputStyle: [Array, String, Object],
    tabindex: {
      type: [String, Number],
      default: 0
    },
    autocomplete: String,
    transitionShow: String,
    transitionHide: String,
    transitionDuration: [String, Number],
    behavior: {
      type: String,
      validator: (v) => ["default", "menu", "dialog"].includes(v),
      default: "default"
    },
    virtualScrollItemSize: {
      type: [Number, String],
      default: void 0
    },
    onNewValue: Function,
    onFilter: Function
  },
  emits: [
    ...useFieldEmits,
    "add",
    "remove",
    "inputValue",
    "newValue",
    "keyup",
    "keypress",
    "keydown",
    "filterAbort"
  ],
  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance();
    const { $q } = proxy;
    const menu = ref(false);
    const dialog = ref(false);
    const optionIndex = ref(-1);
    const inputValue = ref("");
    const dialogFieldFocused = ref(false);
    const innerLoadingIndicator = ref(false);
    let inputTimer, innerValueCache, hasDialog, userInputValue, filterId, defaultInputValue, transitionShowComputed, searchBuffer, searchBufferExp;
    const inputRef = ref(null);
    const targetRef = ref(null);
    const menuRef = ref(null);
    const dialogRef = ref(null);
    const menuContentRef = ref(null);
    const nameProp = useFormInputNameAttr(props);
    const onComposition = useKeyComposition(onInput);
    const virtualScrollLength = computed(() => Array.isArray(props.options) ? props.options.length : 0);
    const virtualScrollItemSizeComputed = computed(() => props.virtualScrollItemSize === void 0 ? props.optionsDense === true ? 24 : 48 : props.virtualScrollItemSize);
    const {
      virtualScrollSliceRange,
      virtualScrollSliceSizeComputed,
      localResetVirtualScroll,
      padVirtualScroll,
      onVirtualScrollEvt,
      scrollTo,
      setVirtualScrollSize
    } = useVirtualScroll({
      virtualScrollLength,
      getVirtualScrollTarget,
      getVirtualScrollEl,
      virtualScrollItemSizeComputed
    });
    const state = useFieldState();
    const innerValue = computed(() => {
      const mapNull = props.mapOptions === true && props.multiple !== true, val = props.modelValue !== void 0 && (props.modelValue !== null || mapNull === true) ? props.multiple === true && Array.isArray(props.modelValue) ? props.modelValue : [props.modelValue] : [];
      if (props.mapOptions === true && Array.isArray(props.options) === true) {
        const cache = props.mapOptions === true && innerValueCache !== void 0 ? innerValueCache : [];
        const values = val.map((v) => getOption(v, cache));
        return props.modelValue === null && mapNull === true ? values.filter((v) => v !== null) : values;
      }
      return val;
    });
    const innerFieldProps = computed(() => {
      const acc = {};
      fieldPropsList.forEach((key) => {
        const val = props[key];
        if (val !== void 0) {
          acc[key] = val;
        }
      });
      return acc;
    });
    const isOptionsDark = computed(() => props.optionsDark === null ? state.isDark.value : props.optionsDark);
    const hasValue = computed(() => fieldValueIsFilled(innerValue.value));
    const computedInputClass = computed(() => {
      let cls = "q-field__input q-placeholder col";
      if (props.hideSelected === true || innerValue.value.length === 0) {
        return [cls, props.inputClass];
      }
      cls += " q-field__input--padding";
      return props.inputClass === void 0 ? cls : [cls, props.inputClass];
    });
    const menuContentClass = computed(
      () => (props.virtualScrollHorizontal === true ? "q-virtual-scroll--horizontal" : "") + (props.popupContentClass ? " " + props.popupContentClass : "")
    );
    const noOptions = computed(() => virtualScrollLength.value === 0);
    const selectedString = computed(
      () => innerValue.value.map((opt) => getOptionLabel.value(opt)).join(", ")
    );
    const needsHtmlFn = computed(() => props.optionsHtml === true ? () => true : (opt) => opt !== void 0 && opt !== null && opt.html === true);
    const valueAsHtml = computed(() => props.displayValueHtml === true || props.displayValue === void 0 && (props.optionsHtml === true || innerValue.value.some(needsHtmlFn.value)));
    const tabindex = computed(() => state.focused.value === true ? props.tabindex : -1);
    const comboboxAttrs = computed(() => ({
      tabindex: props.tabindex,
      role: "combobox",
      "aria-label": props.label,
      "aria-readonly": props.readonly === true ? "true" : "false",
      "aria-autocomplete": props.useInput === true ? "list" : "none",
      "aria-expanded": menu.value === true ? "true" : "false",
      "aria-owns": `${state.targetUid.value}_lb`,
      "aria-controls": `${state.targetUid.value}_lb`
    }));
    const listboxAttrs = computed(() => {
      const attrs = {
        id: `${state.targetUid.value}_lb`,
        role: "listbox",
        "aria-multiselectable": props.multiple === true ? "true" : "false"
      };
      if (optionIndex.value >= 0) {
        attrs["aria-activedescendant"] = `${state.targetUid.value}_${optionIndex.value}`;
      }
      return attrs;
    });
    const selectedScope = computed(() => {
      return innerValue.value.map((opt, i) => ({
        index: i,
        opt,
        html: needsHtmlFn.value(opt),
        selected: true,
        removeAtIndex: removeAtIndexAndFocus,
        toggleOption,
        tabindex: tabindex.value
      }));
    });
    const optionScope = computed(() => {
      if (virtualScrollLength.value === 0) {
        return [];
      }
      const { from, to } = virtualScrollSliceRange.value;
      return props.options.slice(from, to).map((opt, i) => {
        const disable = isOptionDisabled.value(opt) === true;
        const index = from + i;
        const itemProps = {
          clickable: true,
          active: false,
          activeClass: computedOptionsSelectedClass.value,
          manualFocus: true,
          focused: false,
          disable,
          tabindex: -1,
          dense: props.optionsDense,
          dark: isOptionsDark.value,
          role: "option",
          id: `${state.targetUid.value}_${index}`,
          onClick: () => {
            toggleOption(opt);
          }
        };
        if (disable !== true) {
          isOptionSelected(opt) === true && (itemProps.active = true);
          optionIndex.value === index && (itemProps.focused = true);
          itemProps["aria-selected"] = itemProps.active === true ? "true" : "false";
          if ($q.platform.is.desktop === true) {
            itemProps.onMousemove = () => {
              menu.value === true && setOptionIndex(index);
            };
          }
        }
        return {
          index,
          opt,
          html: needsHtmlFn.value(opt),
          label: getOptionLabel.value(opt),
          selected: itemProps.active,
          focused: itemProps.focused,
          toggleOption,
          setOptionIndex,
          itemProps
        };
      });
    });
    const dropdownArrowIcon = computed(() => props.dropdownIcon !== void 0 ? props.dropdownIcon : $q.iconSet.arrow.dropdown);
    const squaredMenu = computed(
      () => props.optionsCover === false && props.outlined !== true && props.standout !== true && props.borderless !== true && props.rounded !== true
    );
    const computedOptionsSelectedClass = computed(() => props.optionsSelectedClass !== void 0 ? props.optionsSelectedClass : props.color !== void 0 ? `text-${props.color}` : "");
    const getOptionValue = computed(() => getPropValueFn(props.optionValue, "value"));
    const getOptionLabel = computed(() => getPropValueFn(props.optionLabel, "label"));
    const isOptionDisabled = computed(() => getPropValueFn(props.optionDisable, "disable"));
    const innerOptionsValue = computed(() => innerValue.value.map((opt) => getOptionValue.value(opt)));
    const inputControlEvents = computed(() => {
      const evt = {
        onInput,
        onChange: onComposition,
        onKeydown: onTargetKeydown,
        onKeyup: onTargetAutocomplete,
        onKeypress: onTargetKeypress,
        onFocus: selectInputText,
        onClick(e) {
          hasDialog === true && stop(e);
        }
      };
      evt.onCompositionstart = evt.onCompositionupdate = evt.onCompositionend = onComposition;
      return evt;
    });
    watch(innerValue, (val) => {
      innerValueCache = val;
      if (props.useInput === true && props.fillInput === true && props.multiple !== true && state.innerLoading.value !== true && (dialog.value !== true && menu.value !== true || hasValue.value !== true)) {
        userInputValue !== true && resetInputValue();
        if (dialog.value === true || menu.value === true) {
          filter("");
        }
      }
    }, { immediate: true });
    watch(() => props.fillInput, resetInputValue);
    watch(menu, updateMenu);
    watch(virtualScrollLength, rerenderMenu);
    function getEmittingOptionValue(opt) {
      return props.emitValue === true ? getOptionValue.value(opt) : opt;
    }
    function removeAtIndex(index) {
      if (index > -1 && index < innerValue.value.length) {
        if (props.multiple === true) {
          const model = props.modelValue.slice();
          emit("remove", { index, value: model.splice(index, 1)[0] });
          emit("update:modelValue", model);
        } else {
          emit("update:modelValue", null);
        }
      }
    }
    function removeAtIndexAndFocus(index) {
      removeAtIndex(index);
      state.focus();
    }
    function add(opt, unique) {
      const val = getEmittingOptionValue(opt);
      if (props.multiple !== true) {
        props.fillInput === true && updateInputValue(
          getOptionLabel.value(opt),
          true,
          true
        );
        emit("update:modelValue", val);
        return;
      }
      if (innerValue.value.length === 0) {
        emit("add", { index: 0, value: val });
        emit("update:modelValue", props.multiple === true ? [val] : val);
        return;
      }
      if (unique === true && isOptionSelected(opt) === true) {
        return;
      }
      if (props.maxValues !== void 0 && props.modelValue.length >= props.maxValues) {
        return;
      }
      const model = props.modelValue.slice();
      emit("add", { index: model.length, value: val });
      model.push(val);
      emit("update:modelValue", model);
    }
    function toggleOption(opt, keepOpen) {
      if (state.editable.value !== true || opt === void 0 || isOptionDisabled.value(opt) === true) {
        return;
      }
      const optValue = getOptionValue.value(opt);
      if (props.multiple !== true) {
        if (keepOpen !== true) {
          updateInputValue(
            props.fillInput === true ? getOptionLabel.value(opt) : "",
            true,
            true
          );
          hidePopup();
        }
        targetRef.value !== null && targetRef.value.focus();
        if (innerValue.value.length === 0 || isDeepEqual(getOptionValue.value(innerValue.value[0]), optValue) !== true) {
          emit("update:modelValue", props.emitValue === true ? optValue : opt);
        }
        return;
      }
      (hasDialog !== true || dialogFieldFocused.value === true) && state.focus();
      selectInputText();
      if (innerValue.value.length === 0) {
        const val = props.emitValue === true ? optValue : opt;
        emit("add", { index: 0, value: val });
        emit("update:modelValue", props.multiple === true ? [val] : val);
        return;
      }
      const model = props.modelValue.slice(), index = innerOptionsValue.value.findIndex((v) => isDeepEqual(v, optValue));
      if (index > -1) {
        emit("remove", { index, value: model.splice(index, 1)[0] });
      } else {
        if (props.maxValues !== void 0 && model.length >= props.maxValues) {
          return;
        }
        const val = props.emitValue === true ? optValue : opt;
        emit("add", { index: model.length, value: val });
        model.push(val);
      }
      emit("update:modelValue", model);
    }
    function setOptionIndex(index) {
      if ($q.platform.is.desktop !== true) {
        return;
      }
      const val = index > -1 && index < virtualScrollLength.value ? index : -1;
      if (optionIndex.value !== val) {
        optionIndex.value = val;
      }
    }
    function moveOptionSelection(offset = 1, skipInputValue) {
      if (menu.value === true) {
        let index = optionIndex.value;
        do {
          index = normalizeToInterval(
            index + offset,
            -1,
            virtualScrollLength.value - 1
          );
        } while (index !== -1 && index !== optionIndex.value && isOptionDisabled.value(props.options[index]) === true);
        if (optionIndex.value !== index) {
          setOptionIndex(index);
          scrollTo(index);
          if (skipInputValue !== true && props.useInput === true && props.fillInput === true) {
            setInputValue(
              index >= 0 ? getOptionLabel.value(props.options[index]) : defaultInputValue
            );
          }
        }
      }
    }
    function getOption(value2, valueCache) {
      const fn = (opt) => isDeepEqual(getOptionValue.value(opt), value2);
      return props.options.find(fn) || valueCache.find(fn) || value2;
    }
    function getPropValueFn(propValue, defaultVal) {
      const val = propValue !== void 0 ? propValue : defaultVal;
      return typeof val === "function" ? val : (opt) => opt !== null && typeof opt === "object" && val in opt ? opt[val] : opt;
    }
    function isOptionSelected(opt) {
      const val = getOptionValue.value(opt);
      return innerOptionsValue.value.find((v) => isDeepEqual(v, val)) !== void 0;
    }
    function selectInputText(e) {
      if (props.useInput === true && targetRef.value !== null && (e === void 0 || targetRef.value === e.target && e.target.value === selectedString.value)) {
        targetRef.value.select();
      }
    }
    function onTargetKeyup(e) {
      if (isKeyCode(e, 27) === true && menu.value === true) {
        stop(e);
        hidePopup();
        resetInputValue();
      }
      emit("keyup", e);
    }
    function onTargetAutocomplete(e) {
      const { value: value2 } = e.target;
      if (e.keyCode !== void 0) {
        onTargetKeyup(e);
        return;
      }
      e.target.value = "";
      clearTimeout(inputTimer);
      resetInputValue();
      if (typeof value2 === "string" && value2.length > 0) {
        const needle = value2.toLocaleLowerCase();
        const findFn = (extractFn) => {
          const option = props.options.find((opt) => extractFn.value(opt).toLocaleLowerCase() === needle);
          if (option === void 0) {
            return false;
          }
          if (innerValue.value.indexOf(option) === -1) {
            toggleOption(option);
          } else {
            hidePopup();
          }
          return true;
        };
        const fillFn = (afterFilter) => {
          if (findFn(getOptionValue) === true) {
            return;
          }
          if (findFn(getOptionLabel) === true || afterFilter === true) {
            return;
          }
          filter(value2, true, () => fillFn(true));
        };
        fillFn();
      } else {
        state.clearValue(e);
      }
    }
    function onTargetKeypress(e) {
      emit("keypress", e);
    }
    function onTargetKeydown(e) {
      emit("keydown", e);
      if (shouldIgnoreKey(e) === true) {
        return;
      }
      const newValueModeValid = inputValue.value.length > 0 && (props.newValueMode !== void 0 || props.onNewValue !== void 0);
      const tabShouldSelect = e.shiftKey !== true && props.multiple !== true && (optionIndex.value > -1 || newValueModeValid === true);
      if (e.keyCode === 27) {
        prevent(e);
        return;
      }
      if (e.keyCode === 9 && tabShouldSelect === false) {
        closeMenu();
        return;
      }
      if (e.target === void 0 || e.target.id !== state.targetUid.value) {
        return;
      }
      if (e.keyCode === 40 && state.innerLoading.value !== true && menu.value === false) {
        stopAndPrevent(e);
        showPopup();
        return;
      }
      if (e.keyCode === 8 && props.hideSelected !== true && inputValue.value.length === 0) {
        if (props.multiple === true && Array.isArray(props.modelValue) === true) {
          removeAtIndex(props.modelValue.length - 1);
        } else if (props.multiple !== true && props.modelValue !== null) {
          emit("update:modelValue", null);
        }
        return;
      }
      if ((e.keyCode === 35 || e.keyCode === 36) && (typeof inputValue.value !== "string" || inputValue.value.length === 0)) {
        stopAndPrevent(e);
        optionIndex.value = -1;
        moveOptionSelection(e.keyCode === 36 ? 1 : -1, props.multiple);
      }
      if ((e.keyCode === 33 || e.keyCode === 34) && virtualScrollSliceSizeComputed.value !== void 0) {
        stopAndPrevent(e);
        optionIndex.value = Math.max(
          -1,
          Math.min(
            virtualScrollLength.value,
            optionIndex.value + (e.keyCode === 33 ? -1 : 1) * virtualScrollSliceSizeComputed.value.view
          )
        );
        moveOptionSelection(e.keyCode === 33 ? 1 : -1, props.multiple);
      }
      if (e.keyCode === 38 || e.keyCode === 40) {
        stopAndPrevent(e);
        moveOptionSelection(e.keyCode === 38 ? -1 : 1, props.multiple);
      }
      const optionsLength = virtualScrollLength.value;
      if (searchBuffer === void 0 || searchBufferExp < Date.now()) {
        searchBuffer = "";
      }
      if (optionsLength > 0 && props.useInput !== true && e.key !== void 0 && e.key.length === 1 && e.altKey === e.ctrlKey && (e.keyCode !== 32 || searchBuffer.length > 0)) {
        menu.value !== true && showPopup(e);
        const char = e.key.toLocaleLowerCase(), keyRepeat = searchBuffer.length === 1 && searchBuffer[0] === char;
        searchBufferExp = Date.now() + 1500;
        if (keyRepeat === false) {
          stopAndPrevent(e);
          searchBuffer += char;
        }
        const searchRe = new RegExp("^" + searchBuffer.split("").map((l) => reEscapeList.indexOf(l) > -1 ? "\\" + l : l).join(".*"), "i");
        let index = optionIndex.value;
        if (keyRepeat === true || index < 0 || searchRe.test(getOptionLabel.value(props.options[index])) !== true) {
          do {
            index = normalizeToInterval(index + 1, -1, optionsLength - 1);
          } while (index !== optionIndex.value && (isOptionDisabled.value(props.options[index]) === true || searchRe.test(getOptionLabel.value(props.options[index])) !== true));
        }
        if (optionIndex.value !== index) {
          nextTick(() => {
            setOptionIndex(index);
            scrollTo(index);
            if (index >= 0 && props.useInput === true && props.fillInput === true) {
              setInputValue(getOptionLabel.value(props.options[index]));
            }
          });
        }
        return;
      }
      if (e.keyCode !== 13 && (e.keyCode !== 32 || props.useInput === true || searchBuffer !== "") && (e.keyCode !== 9 || tabShouldSelect === false)) {
        return;
      }
      e.keyCode !== 9 && stopAndPrevent(e);
      if (optionIndex.value > -1 && optionIndex.value < optionsLength) {
        toggleOption(props.options[optionIndex.value]);
        return;
      }
      if (newValueModeValid === true) {
        const done = (val, mode) => {
          if (mode) {
            if (validateNewValueMode(mode) !== true) {
              return;
            }
          } else {
            mode = props.newValueMode;
          }
          if (val === void 0 || val === null) {
            return;
          }
          updateInputValue("", props.multiple !== true, true);
          const fn = mode === "toggle" ? toggleOption : add;
          fn(val, mode === "add-unique");
          if (props.multiple !== true) {
            targetRef.value !== null && targetRef.value.focus();
            hidePopup();
          }
        };
        if (props.onNewValue !== void 0) {
          emit("newValue", inputValue.value, done);
        } else {
          done(inputValue.value);
        }
        if (props.multiple !== true) {
          return;
        }
      }
      if (menu.value === true) {
        closeMenu();
      } else if (state.innerLoading.value !== true) {
        showPopup();
      }
    }
    function getVirtualScrollEl() {
      return hasDialog === true ? menuContentRef.value : menuRef.value !== null && menuRef.value.contentEl !== null ? menuRef.value.contentEl : void 0;
    }
    function getVirtualScrollTarget() {
      return getVirtualScrollEl();
    }
    function getSelection() {
      if (props.hideSelected === true) {
        return [];
      }
      if (slots["selected-item"] !== void 0) {
        return selectedScope.value.map((scope) => slots["selected-item"](scope)).slice();
      }
      if (slots.selected !== void 0) {
        return [].concat(slots.selected());
      }
      if (props.useChips === true) {
        return selectedScope.value.map((scope, i) => h(QChip, {
          key: "option-" + i,
          removable: state.editable.value === true && isOptionDisabled.value(scope.opt) !== true,
          dense: true,
          textColor: props.color,
          tabindex: tabindex.value,
          onRemove() {
            scope.removeAtIndex(i);
          }
        }, () => h("span", {
          class: "ellipsis",
          [scope.html === true ? "innerHTML" : "textContent"]: getOptionLabel.value(scope.opt)
        })));
      }
      return [
        h("span", {
          [valueAsHtml.value === true ? "innerHTML" : "textContent"]: props.displayValue !== void 0 ? props.displayValue : selectedString.value
        })
      ];
    }
    function getAllOptions() {
      if (noOptions.value === true) {
        return slots["no-option"] !== void 0 ? slots["no-option"]({ inputValue: inputValue.value }) : void 0;
      }
      const fn = slots.option !== void 0 ? slots.option : (scope) => {
        return h(QItem, {
          key: scope.index,
          ...scope.itemProps
        }, () => {
          return h(
            QItemSection,
            () => h(
              QItemLabel,
              () => h("span", {
                [scope.html === true ? "innerHTML" : "textContent"]: scope.label
              })
            )
          );
        });
      };
      let options = padVirtualScroll("div", optionScope.value.map(fn));
      if (slots["before-options"] !== void 0) {
        options = slots["before-options"]().concat(options);
      }
      return hMergeSlot(slots["after-options"], options);
    }
    function getInput(fromDialog, isTarget) {
      const attrs = isTarget === true ? { ...comboboxAttrs.value, ...state.splitAttrs.attributes.value } : void 0;
      const data = {
        ref: isTarget === true ? targetRef : void 0,
        key: "i_t",
        class: computedInputClass.value,
        style: props.inputStyle,
        value: inputValue.value !== void 0 ? inputValue.value : "",
        type: "search",
        ...attrs,
        id: isTarget === true ? state.targetUid.value : void 0,
        maxlength: props.maxlength,
        autocomplete: props.autocomplete,
        "data-autofocus": fromDialog !== true && props.autofocus === true || void 0,
        disabled: props.disable === true,
        readonly: props.readonly === true,
        ...inputControlEvents.value
      };
      if (fromDialog !== true && hasDialog === true) {
        if (Array.isArray(data.class) === true) {
          data.class = [...data.class, "no-pointer-events"];
        } else {
          data.class += " no-pointer-events";
        }
      }
      return h("input", data);
    }
    function onInput(e) {
      clearTimeout(inputTimer);
      if (e && e.target && e.target.qComposing === true) {
        return;
      }
      setInputValue(e.target.value || "");
      userInputValue = true;
      defaultInputValue = inputValue.value;
      if (state.focused.value !== true && (hasDialog !== true || dialogFieldFocused.value === true)) {
        state.focus();
      }
      if (props.onFilter !== void 0) {
        inputTimer = setTimeout(() => {
          filter(inputValue.value);
        }, props.inputDebounce);
      }
    }
    function setInputValue(val) {
      if (inputValue.value !== val) {
        inputValue.value = val;
        emit("inputValue", val);
      }
    }
    function updateInputValue(val, noFiltering, internal) {
      userInputValue = internal !== true;
      if (props.useInput === true) {
        setInputValue(val);
        if (noFiltering === true || internal !== true) {
          defaultInputValue = val;
        }
        noFiltering !== true && filter(val);
      }
    }
    function filter(val, keepClosed, afterUpdateFn) {
      if (props.onFilter === void 0 || keepClosed !== true && state.focused.value !== true) {
        return;
      }
      if (state.innerLoading.value === true) {
        emit("filterAbort");
      } else {
        state.innerLoading.value = true;
        innerLoadingIndicator.value = true;
      }
      if (val !== "" && props.multiple !== true && innerValue.value.length > 0 && userInputValue !== true && val === getOptionLabel.value(innerValue.value[0])) {
        val = "";
      }
      const localFilterId = setTimeout(() => {
        menu.value === true && (menu.value = false);
      }, 10);
      clearTimeout(filterId);
      filterId = localFilterId;
      emit(
        "filter",
        val,
        (fn, afterFn) => {
          if ((keepClosed === true || state.focused.value === true) && filterId === localFilterId) {
            clearTimeout(filterId);
            typeof fn === "function" && fn();
            innerLoadingIndicator.value = false;
            nextTick(() => {
              state.innerLoading.value = false;
              if (state.editable.value === true) {
                if (keepClosed === true) {
                  menu.value === true && hidePopup();
                } else if (menu.value === true) {
                  updateMenu(true);
                } else {
                  menu.value = true;
                }
              }
              typeof afterFn === "function" && nextTick(() => {
                afterFn(proxy);
              });
              typeof afterUpdateFn === "function" && nextTick(() => {
                afterUpdateFn(proxy);
              });
            });
          }
        },
        () => {
          if (state.focused.value === true && filterId === localFilterId) {
            clearTimeout(filterId);
            state.innerLoading.value = false;
            innerLoadingIndicator.value = false;
          }
          menu.value === true && (menu.value = false);
        }
      );
    }
    function getMenu() {
      return h(QMenu, {
        ref: menuRef,
        class: menuContentClass.value,
        style: props.popupContentStyle,
        modelValue: menu.value,
        fit: props.menuShrink !== true,
        cover: props.optionsCover === true && noOptions.value !== true && props.useInput !== true,
        anchor: props.menuAnchor,
        self: props.menuSelf,
        offset: props.menuOffset,
        dark: isOptionsDark.value,
        noParentEvent: true,
        noRefocus: true,
        noFocus: true,
        square: squaredMenu.value,
        transitionShow: props.transitionShow,
        transitionHide: props.transitionHide,
        transitionDuration: props.transitionDuration,
        separateClosePopup: true,
        ...listboxAttrs.value,
        onScrollPassive: onVirtualScrollEvt,
        onBeforeShow: onControlPopupShow,
        onBeforeHide: onMenuBeforeHide,
        onShow: onMenuShow
      }, getAllOptions);
    }
    function onMenuBeforeHide(e) {
      onControlPopupHide(e);
      closeMenu();
    }
    function onMenuShow() {
      setVirtualScrollSize();
    }
    function onDialogFieldFocus(e) {
      stop(e);
      targetRef.value !== null && targetRef.value.focus();
      dialogFieldFocused.value = true;
      window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, 0);
    }
    function onDialogFieldBlur(e) {
      stop(e);
      nextTick(() => {
        dialogFieldFocused.value = false;
      });
    }
    function getDialog() {
      const content = [
        h(QField, {
          class: `col-auto ${state.fieldClass.value}`,
          ...innerFieldProps.value,
          for: state.targetUid.value,
          dark: isOptionsDark.value,
          square: true,
          loading: innerLoadingIndicator.value,
          itemAligned: false,
          filled: true,
          stackLabel: inputValue.value.length > 0,
          ...state.splitAttrs.listeners.value,
          onFocus: onDialogFieldFocus,
          onBlur: onDialogFieldBlur
        }, {
          ...slots,
          rawControl: () => state.getControl(true),
          before: void 0,
          after: void 0
        })
      ];
      menu.value === true && content.push(
        h("div", {
          ref: menuContentRef,
          class: menuContentClass.value + " scroll",
          style: props.popupContentStyle,
          ...listboxAttrs.value,
          onClick: prevent,
          onScrollPassive: onVirtualScrollEvt
        }, getAllOptions())
      );
      return h(QDialog, {
        ref: dialogRef,
        modelValue: dialog.value,
        position: props.useInput === true ? "top" : void 0,
        transitionShow: transitionShowComputed,
        transitionHide: props.transitionHide,
        transitionDuration: props.transitionDuration,
        onBeforeShow: onControlPopupShow,
        onBeforeHide: onDialogBeforeHide,
        onHide: onDialogHide,
        onShow: onDialogShow
      }, () => h("div", {
        class: "q-select__dialog" + (isOptionsDark.value === true ? " q-select__dialog--dark q-dark" : "") + (dialogFieldFocused.value === true ? " q-select__dialog--focused" : "")
      }, content));
    }
    function onDialogBeforeHide(e) {
      onControlPopupHide(e);
      if (dialogRef.value !== null) {
        dialogRef.value.__updateRefocusTarget(
          state.rootRef.value.querySelector(".q-field__native > [tabindex]:last-child")
        );
      }
      state.focused.value = false;
    }
    function onDialogHide(e) {
      hidePopup();
      state.focused.value === false && emit("blur", e);
      resetInputValue();
    }
    function onDialogShow() {
      const el = document.activeElement;
      if ((el === null || el.id !== state.targetUid.value) && targetRef.value !== null && targetRef.value !== el) {
        targetRef.value.focus();
      }
      setVirtualScrollSize();
    }
    function closeMenu() {
      if (dialog.value === true) {
        return;
      }
      optionIndex.value = -1;
      if (menu.value === true) {
        menu.value = false;
      }
      if (state.focused.value === false) {
        clearTimeout(filterId);
        filterId = void 0;
        if (state.innerLoading.value === true) {
          emit("filterAbort");
          state.innerLoading.value = false;
          innerLoadingIndicator.value = false;
        }
      }
    }
    function showPopup(e) {
      if (state.editable.value !== true) {
        return;
      }
      if (hasDialog === true) {
        state.onControlFocusin(e);
        dialog.value = true;
        nextTick(() => {
          state.focus();
        });
      } else {
        state.focus();
      }
      if (props.onFilter !== void 0) {
        filter(inputValue.value);
      } else if (noOptions.value !== true || slots["no-option"] !== void 0) {
        menu.value = true;
      }
    }
    function hidePopup() {
      dialog.value = false;
      closeMenu();
    }
    function resetInputValue() {
      props.useInput === true && updateInputValue(
        props.multiple !== true && props.fillInput === true && innerValue.value.length > 0 ? getOptionLabel.value(innerValue.value[0]) || "" : "",
        true,
        true
      );
    }
    function updateMenu(show) {
      let optionIndex2 = -1;
      if (show === true) {
        if (innerValue.value.length > 0) {
          const val = getOptionValue.value(innerValue.value[0]);
          optionIndex2 = props.options.findIndex((v) => isDeepEqual(getOptionValue.value(v), val));
        }
        localResetVirtualScroll(optionIndex2);
      }
      setOptionIndex(optionIndex2);
    }
    function rerenderMenu(newLength, oldLength) {
      if (menu.value === true && state.innerLoading.value === false) {
        localResetVirtualScroll(-1, true);
        nextTick(() => {
          if (menu.value === true && state.innerLoading.value === false) {
            if (newLength > oldLength) {
              localResetVirtualScroll();
            } else {
              updateMenu(true);
            }
          }
        });
      }
    }
    function updateMenuPosition() {
      if (dialog.value === false && menuRef.value !== null) {
        menuRef.value.updatePosition();
      }
    }
    function onControlPopupShow(e) {
      e !== void 0 && stop(e);
      emit("popupShow", e);
      state.hasPopupOpen = true;
      state.onControlFocusin(e);
    }
    function onControlPopupHide(e) {
      e !== void 0 && stop(e);
      emit("popupHide", e);
      state.hasPopupOpen = false;
      state.onControlFocusout(e);
    }
    function updatePreState() {
      hasDialog = $q.platform.is.mobile !== true && props.behavior !== "dialog" ? false : props.behavior !== "menu" && (props.useInput === true ? slots["no-option"] !== void 0 || props.onFilter !== void 0 || noOptions.value === false : true);
      transitionShowComputed = $q.platform.is.ios === true && hasDialog === true && props.useInput === true ? "fade" : props.transitionShow;
    }
    onBeforeUpdate(updatePreState);
    onUpdated(updateMenuPosition);
    updatePreState();
    onBeforeUnmount(() => {
      clearTimeout(inputTimer);
    });
    Object.assign(proxy, {
      showPopup,
      hidePopup,
      removeAtIndex,
      add,
      toggleOption,
      getOptionIndex: () => optionIndex.value,
      setOptionIndex,
      moveOptionSelection,
      filter,
      updateMenuPosition,
      updateInputValue,
      isOptionSelected,
      getEmittingOptionValue,
      isOptionDisabled: (...args) => isOptionDisabled.value.apply(null, args) === true,
      getOptionValue: (...args) => getOptionValue.value.apply(null, args),
      getOptionLabel: (...args) => getOptionLabel.value.apply(null, args)
    });
    Object.assign(state, {
      innerValue,
      fieldClass: computed(
        () => `q-select q-field--auto-height q-select--with${props.useInput !== true ? "out" : ""}-input q-select--with${props.useChips !== true ? "out" : ""}-chips q-select--${props.multiple === true ? "multiple" : "single"}`
      ),
      inputRef,
      targetRef,
      hasValue,
      showPopup,
      floatingLabel: computed(
        () => props.hideSelected !== true && hasValue.value === true || typeof inputValue.value === "number" || inputValue.value.length > 0 || fieldValueIsFilled(props.displayValue)
      ),
      getControlChild: () => {
        if (state.editable.value !== false && (dialog.value === true || noOptions.value !== true || slots["no-option"] !== void 0)) {
          return hasDialog === true ? getDialog() : getMenu();
        } else if (state.hasPopupOpen === true) {
          state.hasPopupOpen = false;
        }
      },
      controlEvents: {
        onFocusin(e) {
          state.onControlFocusin(e);
        },
        onFocusout(e) {
          state.onControlFocusout(e, () => {
            resetInputValue();
            closeMenu();
          });
        },
        onClick(e) {
          prevent(e);
          if (hasDialog !== true && menu.value === true) {
            closeMenu();
            targetRef.value !== null && targetRef.value.focus();
            return;
          }
          showPopup(e);
        }
      },
      getControl: (fromDialog) => {
        const child = getSelection();
        const isTarget = fromDialog === true || dialog.value !== true || hasDialog !== true;
        if (props.useInput === true) {
          child.push(getInput(fromDialog, isTarget));
        } else if (state.editable.value === true) {
          const attrs2 = isTarget === true ? comboboxAttrs.value : void 0;
          child.push(
            h("input", {
              ref: isTarget === true ? targetRef : void 0,
              key: "d_t",
              class: "q-select__focus-target",
              id: isTarget === true ? state.targetUid.value : void 0,
              readonly: true,
              "data-autofocus": fromDialog !== true && props.autofocus === true || void 0,
              ...attrs2,
              onKeydown: onTargetKeydown,
              onKeyup: onTargetKeyup,
              onKeypress: onTargetKeypress
            })
          );
          if (isTarget === true && typeof props.autocomplete === "string" && props.autocomplete.length > 0) {
            child.push(
              h("input", {
                class: "q-select__autocomplete-input",
                autocomplete: props.autocomplete,
                tabindex: -1,
                onKeyup: onTargetAutocomplete
              })
            );
          }
        }
        if (nameProp.value !== void 0 && props.disable !== true && innerOptionsValue.value.length > 0) {
          const opts = innerOptionsValue.value.map((value2) => h("option", { value: value2, selected: true }));
          child.push(
            h("select", {
              class: "hidden",
              name: nameProp.value,
              multiple: props.multiple
            }, opts)
          );
        }
        const attrs = props.useInput === true || isTarget !== true ? void 0 : state.splitAttrs.attributes.value;
        return h("div", {
          class: "q-field__native row items-center",
          ...attrs
        }, child);
      },
      getInnerAppend: () => props.loading !== true && innerLoadingIndicator.value !== true && props.hideDropdownIcon !== true ? [
        h(QIcon, {
          class: "q-select__dropdown-icon" + (menu.value === true ? " rotate-180" : ""),
          name: dropdownArrowIcon.value
        })
      ] : null
    });
    return useField(state);
  }
});
const space = h("div", { class: "q-space" });
var QSpace = createComponent({
  name: "QSpace",
  setup() {
    return () => space;
  }
});
var QHeader = createComponent({
  name: "QHeader",
  props: {
    modelValue: {
      type: Boolean,
      default: true
    },
    reveal: Boolean,
    revealOffset: {
      type: Number,
      default: 250
    },
    bordered: Boolean,
    elevated: Boolean,
    heightHint: {
      type: [String, Number],
      default: 50
    }
  },
  emits: ["reveal", "focusin"],
  setup(props, { slots, emit }) {
    const { proxy: { $q } } = getCurrentInstance();
    const $layout = inject(layoutKey, emptyRenderFn);
    if ($layout === emptyRenderFn) {
      console.error("QHeader needs to be child of QLayout");
      return emptyRenderFn;
    }
    const size = ref(parseInt(props.heightHint, 10));
    const revealed = ref(true);
    const fixed = computed(
      () => props.reveal === true || $layout.view.value.indexOf("H") > -1 || $q.platform.is.ios && $layout.isContainer.value === true
    );
    const offset = computed(() => {
      if (props.modelValue !== true) {
        return 0;
      }
      if (fixed.value === true) {
        return revealed.value === true ? size.value : 0;
      }
      const offset2 = size.value - $layout.scroll.value.position;
      return offset2 > 0 ? offset2 : 0;
    });
    const hidden = computed(
      () => props.modelValue !== true || fixed.value === true && revealed.value !== true
    );
    const revealOnFocus = computed(
      () => props.modelValue === true && hidden.value === true && props.reveal === true
    );
    const classes = computed(
      () => "q-header q-layout__section--marginal " + (fixed.value === true ? "fixed" : "absolute") + "-top" + (props.bordered === true ? " q-header--bordered" : "") + (hidden.value === true ? " q-header--hidden" : "") + (props.modelValue !== true ? " q-layout--prevent-focus" : "")
    );
    const style = computed(() => {
      const view = $layout.rows.value.top, css = {};
      if (view[0] === "l" && $layout.left.space === true) {
        css[$q.lang.rtl === true ? "right" : "left"] = `${$layout.left.size}px`;
      }
      if (view[2] === "r" && $layout.right.space === true) {
        css[$q.lang.rtl === true ? "left" : "right"] = `${$layout.right.size}px`;
      }
      return css;
    });
    function updateLayout(prop, val) {
      $layout.update("header", prop, val);
    }
    function updateLocal(prop, val) {
      if (prop.value !== val) {
        prop.value = val;
      }
    }
    function onResize({ height }) {
      updateLocal(size, height);
      updateLayout("size", height);
    }
    function onFocusin(evt) {
      if (revealOnFocus.value === true) {
        updateLocal(revealed, true);
      }
      emit("focusin", evt);
    }
    watch(() => props.modelValue, (val) => {
      updateLayout("space", val);
      updateLocal(revealed, true);
      $layout.animate();
    });
    watch(offset, (val) => {
      updateLayout("offset", val);
    });
    watch(() => props.reveal, (val) => {
      val === false && updateLocal(revealed, props.modelValue);
    });
    watch(revealed, (val) => {
      $layout.animate();
      emit("reveal", val);
    });
    watch($layout.scroll, (scroll) => {
      props.reveal === true && updateLocal(
        revealed,
        scroll.direction === "up" || scroll.position <= props.revealOffset || scroll.position - scroll.inflectionPoint < 100
      );
    });
    const instance = {};
    $layout.instances.header = instance;
    props.modelValue === true && updateLayout("size", size.value);
    updateLayout("space", props.modelValue);
    updateLayout("offset", offset.value);
    onBeforeUnmount(() => {
      if ($layout.instances.header === instance) {
        $layout.instances.header = void 0;
        updateLayout("size", 0);
        updateLayout("offset", 0);
        updateLayout("space", false);
      }
    });
    return () => {
      const child = hUniqueSlot(slots.default, []);
      props.elevated === true && child.push(
        h("div", {
          class: "q-layout__shadow absolute-full overflow-hidden no-pointer-events"
        })
      );
      child.push(
        h(QResizeObserver, {
          debounce: 0,
          onResize
        })
      );
      return h("header", {
        class: classes.value,
        style: style.value,
        onFocusin
      }, child);
    };
  }
});
const modifiersAll = {
  left: true,
  right: true,
  up: true,
  down: true,
  horizontal: true,
  vertical: true
};
const directionList = Object.keys(modifiersAll);
modifiersAll.all = true;
function getModifierDirections(mod) {
  const dir = {};
  for (const direction of directionList) {
    if (mod[direction] === true) {
      dir[direction] = true;
    }
  }
  if (Object.keys(dir).length === 0) {
    return modifiersAll;
  }
  if (dir.horizontal === true) {
    dir.left = dir.right = true;
  } else if (dir.left === true && dir.right === true) {
    dir.horizontal = true;
  }
  if (dir.vertical === true) {
    dir.up = dir.down = true;
  } else if (dir.up === true && dir.down === true) {
    dir.vertical = true;
  }
  if (dir.horizontal === true && dir.vertical === true) {
    dir.all = true;
  }
  return dir;
}
function shouldStart(evt, ctx) {
  return ctx.event === void 0 && evt.target !== void 0 && evt.target.draggable !== true && typeof ctx.handler === "function" && evt.target.nodeName.toUpperCase() !== "INPUT" && (evt.qClonedBy === void 0 || evt.qClonedBy.indexOf(ctx.uid) === -1);
}
function getChanges(evt, ctx, isFinal) {
  const pos = position(evt);
  let dir, distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y, absX = Math.abs(distX), absY = Math.abs(distY);
  const direction = ctx.direction;
  if (direction.horizontal === true && direction.vertical !== true) {
    dir = distX < 0 ? "left" : "right";
  } else if (direction.horizontal !== true && direction.vertical === true) {
    dir = distY < 0 ? "up" : "down";
  } else if (direction.up === true && distY < 0) {
    dir = "up";
    if (absX > absY) {
      if (direction.left === true && distX < 0) {
        dir = "left";
      } else if (direction.right === true && distX > 0) {
        dir = "right";
      }
    }
  } else if (direction.down === true && distY > 0) {
    dir = "down";
    if (absX > absY) {
      if (direction.left === true && distX < 0) {
        dir = "left";
      } else if (direction.right === true && distX > 0) {
        dir = "right";
      }
    }
  } else if (direction.left === true && distX < 0) {
    dir = "left";
    if (absX < absY) {
      if (direction.up === true && distY < 0) {
        dir = "up";
      } else if (direction.down === true && distY > 0) {
        dir = "down";
      }
    }
  } else if (direction.right === true && distX > 0) {
    dir = "right";
    if (absX < absY) {
      if (direction.up === true && distY < 0) {
        dir = "up";
      } else if (direction.down === true && distY > 0) {
        dir = "down";
      }
    }
  }
  let synthetic = false;
  if (dir === void 0 && isFinal === false) {
    if (ctx.event.isFirst === true || ctx.event.lastDir === void 0) {
      return {};
    }
    dir = ctx.event.lastDir;
    synthetic = true;
    if (dir === "left" || dir === "right") {
      pos.left -= distX;
      absX = 0;
      distX = 0;
    } else {
      pos.top -= distY;
      absY = 0;
      distY = 0;
    }
  }
  return {
    synthetic,
    payload: {
      evt,
      touch: ctx.event.mouse !== true,
      mouse: ctx.event.mouse === true,
      position: pos,
      direction: dir,
      isFirst: ctx.event.isFirst,
      isFinal: isFinal === true,
      duration: Date.now() - ctx.event.time,
      distance: {
        x: absX,
        y: absY
      },
      offset: {
        x: distX,
        y: distY
      },
      delta: {
        x: pos.left - ctx.event.lastX,
        y: pos.top - ctx.event.lastY
      }
    }
  };
}
let uid = 0;
var TouchPan = createDirective(
  {
    name: "touch-pan",
    beforeMount(el, { value: value2, modifiers }) {
      if (modifiers.mouse !== true && client.has.touch !== true) {
        return;
      }
      function handleEvent(evt, mouseEvent) {
        if (modifiers.mouse === true && mouseEvent === true) {
          stopAndPrevent(evt);
        } else {
          modifiers.stop === true && stop(evt);
          modifiers.prevent === true && prevent(evt);
        }
      }
      const ctx = {
        uid: "qvtp_" + uid++,
        handler: value2,
        modifiers,
        direction: getModifierDirections(modifiers),
        noop,
        mouseStart(evt) {
          if (shouldStart(evt, ctx) && leftClick(evt)) {
            addEvt(ctx, "temp", [
              [document, "mousemove", "move", "notPassiveCapture"],
              [document, "mouseup", "end", "passiveCapture"]
            ]);
            ctx.start(evt, true);
          }
        },
        touchStart(evt) {
          if (shouldStart(evt, ctx)) {
            const target = evt.target;
            addEvt(ctx, "temp", [
              [target, "touchmove", "move", "notPassiveCapture"],
              [target, "touchcancel", "end", "passiveCapture"],
              [target, "touchend", "end", "passiveCapture"]
            ]);
            ctx.start(evt);
          }
        },
        start(evt, mouseEvent) {
          client.is.firefox === true && preventDraggable(el, true);
          ctx.lastEvt = evt;
          if (mouseEvent === true || modifiers.stop === true) {
            if (ctx.direction.all !== true && (mouseEvent !== true || ctx.modifiers.mouseAllDir !== true && ctx.modifiers.mousealldir !== true)) {
              const clone = evt.type.indexOf("mouse") > -1 ? new MouseEvent(evt.type, evt) : new TouchEvent(evt.type, evt);
              evt.defaultPrevented === true && prevent(clone);
              evt.cancelBubble === true && stop(clone);
              Object.assign(clone, {
                qKeyEvent: evt.qKeyEvent,
                qClickOutside: evt.qClickOutside,
                qAnchorHandled: evt.qAnchorHandled,
                qClonedBy: evt.qClonedBy === void 0 ? [ctx.uid] : evt.qClonedBy.concat(ctx.uid)
              });
              ctx.initialEvent = {
                target: evt.target,
                event: clone
              };
            }
            stop(evt);
          }
          const { left, top } = position(evt);
          ctx.event = {
            x: left,
            y: top,
            time: Date.now(),
            mouse: mouseEvent === true,
            detected: false,
            isFirst: true,
            isFinal: false,
            lastX: left,
            lastY: top
          };
        },
        move(evt) {
          if (ctx.event === void 0) {
            return;
          }
          const pos = position(evt), distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y;
          if (distX === 0 && distY === 0) {
            return;
          }
          ctx.lastEvt = evt;
          const isMouseEvt = ctx.event.mouse === true;
          const start = () => {
            handleEvent(evt, isMouseEvt);
            let cursor;
            if (modifiers.preserveCursor !== true && modifiers.preservecursor !== true) {
              cursor = document.documentElement.style.cursor || "";
              document.documentElement.style.cursor = "grabbing";
            }
            isMouseEvt === true && document.body.classList.add("no-pointer-events--children");
            document.body.classList.add("non-selectable");
            clearSelection();
            ctx.styleCleanup = (withDelayedFn) => {
              ctx.styleCleanup = void 0;
              if (cursor !== void 0) {
                document.documentElement.style.cursor = cursor;
              }
              document.body.classList.remove("non-selectable");
              if (isMouseEvt === true) {
                const remove = () => {
                  document.body.classList.remove("no-pointer-events--children");
                };
                if (withDelayedFn !== void 0) {
                  setTimeout(() => {
                    remove();
                    withDelayedFn();
                  }, 50);
                } else {
                  remove();
                }
              } else if (withDelayedFn !== void 0) {
                withDelayedFn();
              }
            };
          };
          if (ctx.event.detected === true) {
            ctx.event.isFirst !== true && handleEvent(evt, ctx.event.mouse);
            const { payload, synthetic } = getChanges(evt, ctx, false);
            if (payload !== void 0) {
              if (ctx.handler(payload) === false) {
                ctx.end(evt);
              } else {
                if (ctx.styleCleanup === void 0 && ctx.event.isFirst === true) {
                  start();
                }
                ctx.event.lastX = payload.position.left;
                ctx.event.lastY = payload.position.top;
                ctx.event.lastDir = synthetic === true ? void 0 : payload.direction;
                ctx.event.isFirst = false;
              }
            }
            return;
          }
          if (ctx.direction.all === true || isMouseEvt === true && (ctx.modifiers.mouseAllDir === true || ctx.modifiers.mousealldir === true)) {
            start();
            ctx.event.detected = true;
            ctx.move(evt);
            return;
          }
          const absX = Math.abs(distX), absY = Math.abs(distY);
          if (absX !== absY) {
            if (ctx.direction.horizontal === true && absX > absY || ctx.direction.vertical === true && absX < absY || ctx.direction.up === true && absX < absY && distY < 0 || ctx.direction.down === true && absX < absY && distY > 0 || ctx.direction.left === true && absX > absY && distX < 0 || ctx.direction.right === true && absX > absY && distX > 0) {
              ctx.event.detected = true;
              ctx.move(evt);
            } else {
              ctx.end(evt, true);
            }
          }
        },
        end(evt, abort) {
          if (ctx.event === void 0) {
            return;
          }
          cleanEvt(ctx, "temp");
          client.is.firefox === true && preventDraggable(el, false);
          if (abort === true) {
            ctx.styleCleanup !== void 0 && ctx.styleCleanup();
            if (ctx.event.detected !== true && ctx.initialEvent !== void 0) {
              ctx.initialEvent.target.dispatchEvent(ctx.initialEvent.event);
            }
          } else if (ctx.event.detected === true) {
            ctx.event.isFirst === true && ctx.handler(getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx).payload);
            const { payload } = getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx, true);
            const fn = () => {
              ctx.handler(payload);
            };
            if (ctx.styleCleanup !== void 0) {
              ctx.styleCleanup(fn);
            } else {
              fn();
            }
          }
          ctx.event = void 0;
          ctx.initialEvent = void 0;
          ctx.lastEvt = void 0;
        }
      };
      el.__qtouchpan = ctx;
      if (modifiers.mouse === true) {
        const capture = modifiers.mouseCapture === true || modifiers.mousecapture === true ? "Capture" : "";
        addEvt(ctx, "main", [
          [el, "mousedown", "mouseStart", `passive${capture}`]
        ]);
      }
      client.has.touch === true && addEvt(ctx, "main", [
        [el, "touchstart", "touchStart", `passive${modifiers.capture === true ? "Capture" : ""}`],
        [el, "touchmove", "noop", "notPassiveCapture"]
      ]);
    },
    updated(el, bindings) {
      const ctx = el.__qtouchpan;
      if (ctx !== void 0) {
        if (bindings.oldValue !== bindings.value) {
          typeof value !== "function" && ctx.end();
          ctx.handler = bindings.value;
        }
        ctx.direction = getModifierDirections(bindings.modifiers);
      }
    },
    beforeUnmount(el) {
      const ctx = el.__qtouchpan;
      if (ctx !== void 0) {
        ctx.event !== void 0 && ctx.end();
        cleanEvt(ctx, "main");
        cleanEvt(ctx, "temp");
        client.is.firefox === true && preventDraggable(el, false);
        ctx.styleCleanup !== void 0 && ctx.styleCleanup();
        delete el.__qtouchpan;
      }
    }
  }
);
const duration = 150;
var QDrawer = createComponent({
  name: "QDrawer",
  inheritAttrs: false,
  props: {
    ...useModelToggleProps,
    ...useDarkProps,
    side: {
      type: String,
      default: "left",
      validator: (v) => ["left", "right"].includes(v)
    },
    width: {
      type: Number,
      default: 300
    },
    mini: Boolean,
    miniToOverlay: Boolean,
    miniWidth: {
      type: Number,
      default: 57
    },
    breakpoint: {
      type: Number,
      default: 1023
    },
    showIfAbove: Boolean,
    behavior: {
      type: String,
      validator: (v) => ["default", "desktop", "mobile"].includes(v),
      default: "default"
    },
    bordered: Boolean,
    elevated: Boolean,
    overlay: Boolean,
    persistent: Boolean,
    noSwipeOpen: Boolean,
    noSwipeClose: Boolean,
    noSwipeBackdrop: Boolean
  },
  emits: [
    ...useModelToggleEmits,
    "onLayout",
    "miniState"
  ],
  setup(props, { slots, emit, attrs }) {
    const vm = getCurrentInstance();
    const { proxy: { $q } } = vm;
    const isDark = useDark(props, $q);
    const { preventBodyScroll } = usePreventScroll();
    const { registerTimeout, removeTimeout } = useTimeout();
    const $layout = inject(layoutKey, emptyRenderFn);
    if ($layout === emptyRenderFn) {
      console.error("QDrawer needs to be child of QLayout");
      return emptyRenderFn;
    }
    let lastDesktopState, timerMini, layoutTotalWidthWatcher;
    const belowBreakpoint = ref(
      props.behavior === "mobile" || props.behavior !== "desktop" && $layout.totalWidth.value <= props.breakpoint
    );
    const isMini = computed(
      () => props.mini === true && belowBreakpoint.value !== true
    );
    const size = computed(() => isMini.value === true ? props.miniWidth : props.width);
    const showing = ref(
      props.showIfAbove === true && belowBreakpoint.value === false ? true : props.modelValue === true
    );
    const hideOnRouteChange = computed(
      () => props.persistent !== true && (belowBreakpoint.value === true || onScreenOverlay.value === true)
    );
    function handleShow(evt, noEvent) {
      addToHistory();
      evt !== false && $layout.animate();
      applyPosition(0);
      if (belowBreakpoint.value === true) {
        const otherInstance = $layout.instances[otherSide.value];
        if (otherInstance !== void 0 && otherInstance.belowBreakpoint === true) {
          otherInstance.hide(false);
        }
        applyBackdrop(1);
        $layout.isContainer.value !== true && preventBodyScroll(true);
      } else {
        applyBackdrop(0);
        evt !== false && setScrollable(false);
      }
      registerTimeout(() => {
        evt !== false && setScrollable(true);
        noEvent !== true && emit("show", evt);
      }, duration);
    }
    function handleHide(evt, noEvent) {
      removeFromHistory();
      evt !== false && $layout.animate();
      applyBackdrop(0);
      applyPosition(stateDirection.value * size.value);
      cleanup();
      if (noEvent !== true) {
        registerTimeout(() => {
          emit("hide", evt);
        }, duration);
      } else {
        removeTimeout();
      }
    }
    const { show, hide } = useModelToggle({
      showing,
      hideOnRouteChange,
      handleShow,
      handleHide
    });
    const { addToHistory, removeFromHistory } = useHistory(showing, hide, hideOnRouteChange);
    const instance = {
      belowBreakpoint,
      hide
    };
    const rightSide = computed(() => props.side === "right");
    const stateDirection = computed(
      () => ($q.lang.rtl === true ? -1 : 1) * (rightSide.value === true ? 1 : -1)
    );
    const flagBackdropBg = ref(0);
    const flagPanning = ref(false);
    const flagMiniAnimate = ref(false);
    const flagContentPosition = ref(
      size.value * stateDirection.value
    );
    const otherSide = computed(() => rightSide.value === true ? "left" : "right");
    const offset = computed(() => showing.value === true && belowBreakpoint.value === false && props.overlay === false ? props.miniToOverlay === true ? props.miniWidth : size.value : 0);
    const fixed = computed(
      () => props.overlay === true || props.miniToOverlay === true || $layout.view.value.indexOf(rightSide.value ? "R" : "L") > -1 || $q.platform.is.ios === true && $layout.isContainer.value === true
    );
    const onLayout = computed(
      () => props.overlay === false && showing.value === true && belowBreakpoint.value === false
    );
    const onScreenOverlay = computed(
      () => props.overlay === true && showing.value === true && belowBreakpoint.value === false
    );
    const backdropClass = computed(
      () => "fullscreen q-drawer__backdrop" + (showing.value === false && flagPanning.value === false ? " hidden" : "")
    );
    const backdropStyle = computed(() => ({
      backgroundColor: `rgba(0,0,0,${flagBackdropBg.value * 0.4})`
    }));
    const headerSlot = computed(() => rightSide.value === true ? $layout.rows.value.top[2] === "r" : $layout.rows.value.top[0] === "l");
    const footerSlot = computed(() => rightSide.value === true ? $layout.rows.value.bottom[2] === "r" : $layout.rows.value.bottom[0] === "l");
    const aboveStyle = computed(() => {
      const css = {};
      if ($layout.header.space === true && headerSlot.value === false) {
        if (fixed.value === true) {
          css.top = `${$layout.header.offset}px`;
        } else if ($layout.header.space === true) {
          css.top = `${$layout.header.size}px`;
        }
      }
      if ($layout.footer.space === true && footerSlot.value === false) {
        if (fixed.value === true) {
          css.bottom = `${$layout.footer.offset}px`;
        } else if ($layout.footer.space === true) {
          css.bottom = `${$layout.footer.size}px`;
        }
      }
      return css;
    });
    const style = computed(() => {
      const style2 = {
        width: `${size.value}px`,
        transform: `translateX(${flagContentPosition.value}px)`
      };
      return belowBreakpoint.value === true ? style2 : Object.assign(style2, aboveStyle.value);
    });
    const contentClass = computed(
      () => "q-drawer__content fit " + ($layout.isContainer.value !== true ? "scroll" : "overflow-auto")
    );
    const classes = computed(
      () => `q-drawer q-drawer--${props.side}` + (flagMiniAnimate.value === true ? " q-drawer--mini-animate" : "") + (props.bordered === true ? " q-drawer--bordered" : "") + (isDark.value === true ? " q-drawer--dark q-dark" : "") + (flagPanning.value === true ? " no-transition" : showing.value === true ? "" : " q-layout--prevent-focus") + (belowBreakpoint.value === true ? " fixed q-drawer--on-top q-drawer--mobile q-drawer--top-padding" : ` q-drawer--${isMini.value === true ? "mini" : "standard"}` + (fixed.value === true || onLayout.value !== true ? " fixed" : "") + (props.overlay === true || props.miniToOverlay === true ? " q-drawer--on-top" : "") + (headerSlot.value === true ? " q-drawer--top-padding" : ""))
    );
    const openDirective = computed(() => {
      const dir = $q.lang.rtl === true ? props.side : otherSide.value;
      return [[
        TouchPan,
        onOpenPan,
        void 0,
        {
          [dir]: true,
          mouse: true
        }
      ]];
    });
    const contentCloseDirective = computed(() => {
      const dir = $q.lang.rtl === true ? otherSide.value : props.side;
      return [[
        TouchPan,
        onClosePan,
        void 0,
        {
          [dir]: true,
          mouse: true
        }
      ]];
    });
    const backdropCloseDirective = computed(() => {
      const dir = $q.lang.rtl === true ? otherSide.value : props.side;
      return [[
        TouchPan,
        onClosePan,
        void 0,
        {
          [dir]: true,
          mouse: true,
          mouseAllDir: true
        }
      ]];
    });
    function updateBelowBreakpoint() {
      updateLocal(belowBreakpoint, props.behavior === "mobile" || props.behavior !== "desktop" && $layout.totalWidth.value <= props.breakpoint);
    }
    watch(belowBreakpoint, (val) => {
      if (val === true) {
        lastDesktopState = showing.value;
        showing.value === true && hide(false);
      } else if (props.overlay === false && props.behavior !== "mobile" && lastDesktopState !== false) {
        if (showing.value === true) {
          applyPosition(0);
          applyBackdrop(0);
          cleanup();
        } else {
          show(false);
        }
      }
    });
    watch(() => props.side, (newSide, oldSide) => {
      if ($layout.instances[oldSide] === instance) {
        $layout.instances[oldSide] = void 0;
        $layout[oldSide].space = false;
        $layout[oldSide].offset = 0;
      }
      $layout.instances[newSide] = instance;
      $layout[newSide].size = size.value;
      $layout[newSide].space = onLayout.value;
      $layout[newSide].offset = offset.value;
    });
    watch($layout.totalWidth, () => {
      if ($layout.isContainer.value === true || document.qScrollPrevented !== true) {
        updateBelowBreakpoint();
      }
    });
    watch(
      () => props.behavior + props.breakpoint,
      updateBelowBreakpoint
    );
    watch($layout.isContainer, (val) => {
      showing.value === true && preventBodyScroll(val !== true);
      val === true && updateBelowBreakpoint();
    });
    watch($layout.scrollbarWidth, () => {
      applyPosition(showing.value === true ? 0 : void 0);
    });
    watch(offset, (val) => {
      updateLayout("offset", val);
    });
    watch(onLayout, (val) => {
      emit("onLayout", val);
      updateLayout("space", val);
    });
    watch(rightSide, () => {
      applyPosition();
    });
    watch(size, (val) => {
      applyPosition();
      updateSizeOnLayout(props.miniToOverlay, val);
    });
    watch(() => props.miniToOverlay, (val) => {
      updateSizeOnLayout(val, size.value);
    });
    watch(() => $q.lang.rtl, () => {
      applyPosition();
    });
    watch(() => props.mini, () => {
      if (props.modelValue === true) {
        animateMini();
        $layout.animate();
      }
    });
    watch(isMini, (val) => {
      emit("miniState", val);
    });
    function applyPosition(position2) {
      if (position2 === void 0) {
        nextTick(() => {
          position2 = showing.value === true ? 0 : size.value;
          applyPosition(stateDirection.value * position2);
        });
      } else {
        if ($layout.isContainer.value === true && rightSide.value === true && (belowBreakpoint.value === true || Math.abs(position2) === size.value)) {
          position2 += stateDirection.value * $layout.scrollbarWidth.value;
        }
        flagContentPosition.value = position2;
      }
    }
    function applyBackdrop(x) {
      flagBackdropBg.value = x;
    }
    function setScrollable(v) {
      const action = v === true ? "remove" : $layout.isContainer.value !== true ? "add" : "";
      action !== "" && document.body.classList[action]("q-body--drawer-toggle");
    }
    function animateMini() {
      clearTimeout(timerMini);
      if (vm.proxy && vm.proxy.$el) {
        vm.proxy.$el.classList.add("q-drawer--mini-animate");
      }
      flagMiniAnimate.value = true;
      timerMini = setTimeout(() => {
        flagMiniAnimate.value = false;
        if (vm && vm.proxy && vm.proxy.$el) {
          vm.proxy.$el.classList.remove("q-drawer--mini-animate");
        }
      }, 150);
    }
    function onOpenPan(evt) {
      if (showing.value !== false) {
        return;
      }
      const width = size.value, position2 = between(evt.distance.x, 0, width);
      if (evt.isFinal === true) {
        const opened = position2 >= Math.min(75, width);
        if (opened === true) {
          show();
        } else {
          $layout.animate();
          applyBackdrop(0);
          applyPosition(stateDirection.value * width);
        }
        flagPanning.value = false;
        return;
      }
      applyPosition(
        ($q.lang.rtl === true ? rightSide.value !== true : rightSide.value) ? Math.max(width - position2, 0) : Math.min(0, position2 - width)
      );
      applyBackdrop(
        between(position2 / width, 0, 1)
      );
      if (evt.isFirst === true) {
        flagPanning.value = true;
      }
    }
    function onClosePan(evt) {
      if (showing.value !== true) {
        return;
      }
      const width = size.value, dir = evt.direction === props.side, position2 = ($q.lang.rtl === true ? dir !== true : dir) ? between(evt.distance.x, 0, width) : 0;
      if (evt.isFinal === true) {
        const opened = Math.abs(position2) < Math.min(75, width);
        if (opened === true) {
          $layout.animate();
          applyBackdrop(1);
          applyPosition(0);
        } else {
          hide();
        }
        flagPanning.value = false;
        return;
      }
      applyPosition(stateDirection.value * position2);
      applyBackdrop(between(1 - position2 / width, 0, 1));
      if (evt.isFirst === true) {
        flagPanning.value = true;
      }
    }
    function cleanup() {
      preventBodyScroll(false);
      setScrollable(true);
    }
    function updateLayout(prop, val) {
      $layout.update(props.side, prop, val);
    }
    function updateLocal(prop, val) {
      if (prop.value !== val) {
        prop.value = val;
      }
    }
    function updateSizeOnLayout(miniToOverlay, size2) {
      updateLayout("size", miniToOverlay === true ? props.miniWidth : size2);
    }
    $layout.instances[props.side] = instance;
    updateSizeOnLayout(props.miniToOverlay, size.value);
    updateLayout("space", onLayout.value);
    updateLayout("offset", offset.value);
    if (props.showIfAbove === true && props.modelValue !== true && showing.value === true && props["onUpdate:modelValue"] !== void 0) {
      emit("update:modelValue", true);
    }
    onMounted(() => {
      emit("onLayout", onLayout.value);
      emit("miniState", isMini.value);
      lastDesktopState = props.showIfAbove === true;
      const fn = () => {
        const action = showing.value === true ? handleShow : handleHide;
        action(false, true);
      };
      if ($layout.totalWidth.value !== 0) {
        nextTick(fn);
        return;
      }
      layoutTotalWidthWatcher = watch($layout.totalWidth, () => {
        layoutTotalWidthWatcher();
        layoutTotalWidthWatcher = void 0;
        if (showing.value === false && props.showIfAbove === true && belowBreakpoint.value === false) {
          show(false);
        } else {
          fn();
        }
      });
    });
    onBeforeUnmount(() => {
      layoutTotalWidthWatcher !== void 0 && layoutTotalWidthWatcher();
      clearTimeout(timerMini);
      showing.value === true && cleanup();
      if ($layout.instances[props.side] === instance) {
        $layout.instances[props.side] = void 0;
        updateLayout("size", 0);
        updateLayout("offset", 0);
        updateLayout("space", false);
      }
    });
    return () => {
      const child = [];
      if (belowBreakpoint.value === true) {
        props.noSwipeOpen === false && child.push(
          withDirectives(
            h("div", {
              key: "open",
              class: `q-drawer__opener fixed-${props.side}`,
              "aria-hidden": "true"
            }),
            openDirective.value
          )
        );
        child.push(
          hDir(
            "div",
            {
              ref: "backdrop",
              class: backdropClass.value,
              style: backdropStyle.value,
              "aria-hidden": "true",
              onClick: hide
            },
            void 0,
            "backdrop",
            props.noSwipeBackdrop !== true && showing.value === true,
            () => backdropCloseDirective.value
          )
        );
      }
      const mini = isMini.value === true && slots.mini !== void 0;
      const content = [
        h(
          "div",
          {
            ...attrs,
            key: "" + mini,
            class: [
              contentClass.value,
              attrs.class
            ]
          },
          mini === true ? slots.mini() : hSlot(slots.default)
        )
      ];
      if (props.elevated === true && showing.value === true) {
        content.push(
          h("div", {
            class: "q-layout__shadow absolute-full overflow-hidden no-pointer-events"
          })
        );
      }
      child.push(
        hDir(
          "aside",
          { ref: "content", class: classes.value, style: style.value },
          content,
          "contentclose",
          props.noSwipeClose !== true && belowBreakpoint.value === true,
          () => contentCloseDirective.value
        )
      );
      return h("div", { class: "q-drawer-container" }, child);
    };
  }
});
function useMeta(metaOptions) {
  {
    const meta = { active: true };
    if (typeof metaOptions === "function") {
      const content = computed(metaOptions);
      meta.val = content.value;
      watch(content, (val) => {
        meta.val = val;
        meta.active === true && planClientUpdate();
      });
    } else {
      meta.val = metaOptions;
    }
    clientList.push(meta);
    planClientUpdate();
    onActivated(() => {
      meta.active = true;
      planClientUpdate();
    });
    onDeactivated(() => {
      meta.active = false;
      planClientUpdate();
    });
    onUnmounted(() => {
      clientList.splice(clientList.indexOf(meta), 1);
      planClientUpdate();
    });
  }
}
const _hoisted_1$8 = { key: 0 };
const _hoisted_2$8 = {
  class: "row items-baseline q-mx-md q-pa-none",
  style: { "width": "265px", "border-top": "1px dotted grey" }
};
const _hoisted_3$4 = { class: "col-12 q-mb-md" };
const _hoisted_4$3 = {
  class: "row items-baseline q-mx-md q-my-none",
  style: { "width": "265px" }
};
const _hoisted_5$1 = { class: "col-2" };
const _hoisted_6 = { class: "col-10 text-body1 ellipsis" };
const _hoisted_7 = { class: "col-12 text-body2 ellipsis" };
const _hoisted_8 = { class: "col-12" };
const _hoisted_9 = { class: "text-overline ellipsis" };
const _hoisted_10 = {
  class: "row q-mx-md q-my-none",
  style: { "width": "265px", "border": "0 solid yellow" }
};
const _hoisted_11 = { class: "col-12" };
const _hoisted_12 = { class: "col-12" };
const _hoisted_13 = { class: "row q-ma-sm" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " created ", -1);
const _hoisted_15 = { class: "col-7" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " updated ", -1);
const _hoisted_17 = { class: "col-7" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " last Active ", -1);
const _hoisted_19 = { class: "col-7" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " activated# ", -1);
const _hoisted_21 = { class: "col-7" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " History ", -1);
const _hoisted_23 = { class: "col-7" };
const _hoisted_24 = {
  key: 0,
  class: "col-5"
};
const _hoisted_25 = {
  key: 1,
  class: "col-7"
};
const _hoisted_26 = {
  key: 2,
  class: "col-5"
};
const _hoisted_27 = {
  key: 3,
  class: "col-7"
};
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "TabInfo",
  setup(__props) {
    const notificationStore = useNotificationsStore();
    const featuresStore = useFeatureTogglesStore();
    const router = useRouter();
    const thumbnail = ref("");
    const content = ref("");
    watchEffect(() => {
      if (notificationStore.selectedTab) {
        TabsetService.getThumbnailFor(notificationStore.selectedTab).then((data) => {
          if (data) {
            thumbnail.value = data.thumbnail;
          }
        });
        TabsetService.getContentFor(notificationStore.selectedTab).then((data) => {
          if (data) {
            content.value = data.content;
          }
        });
      }
    });
    function getShortHostname(host) {
      const nrOfDots = (host.match(/\./g) || []).length;
      if (nrOfDots >= 2) {
        return host.substring(host.indexOf(".", nrOfDots - 2) + 1);
      }
      return host;
    }
    function getHost(urlAsString, shorten = true) {
      try {
        const url = new URL(urlAsString);
        if (!shorten) {
          return url.protocol + "://" + url.host.toString();
        }
        return getShortHostname(url.host);
      } catch (e) {
        return "---";
      }
    }
    const showTabDetails = () => {
      if (useFeatureTogglesStore().debugEnabled) {
        router.push("/tab/" + notificationStore.selectedTab.id);
      }
    };
    return (_ctx, _cache) => {
      var _a, _b, _c;
      return unref(notificationStore).selectedTab ? (openBlock(), createElementBlock("div", _hoisted_1$8, [
        createBaseVNode("div", _hoisted_2$8, [
          createBaseVNode("div", _hoisted_3$4, [
            createTextVNode("\xA0 "),
            unref(notificationStore).selectedTab.isDuplicate ? (openBlock(), createBlock(QBanner, {
              key: 0,
              rounded: "",
              class: "bg-amber-1 text-black"
            }, {
              default: withCtx(() => [
                createTextVNode("This tab has duplicates in this tabset ")
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ])
        ]),
        createBaseVNode("div", _hoisted_4$3, [
          createBaseVNode("div", _hoisted_5$1, [
            createVNode(QImg, {
              class: "rounded-borders",
              width: "24px",
              height: "24px",
              src: (_a = unref(notificationStore).selectedTab.chromeTab) == null ? void 0 : _a.favIconUrl
            }, {
              default: withCtx(() => [
                unref(featuresStore).debugEnabled ? (openBlock(), createBlock(QTooltip, { key: 0 }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(notificationStore).selectedTab.chromeTab.favIconUrl) + " / " + toDisplayString(unref(notificationStore).selectedTab.chromeTab.id) + " / " + toDisplayString(unref(notificationStore).selectedTab.id), 1)
                  ]),
                  _: 1
                })) : createCommentVNode("", true)
              ]),
              _: 1
            }, 8, ["src"])
          ]),
          createBaseVNode("div", _hoisted_6, toDisplayString(getHost((_b = unref(notificationStore).selectedTab.chromeTab) == null ? void 0 : _b.url, true)), 1),
          createBaseVNode("div", _hoisted_7, toDisplayString((_c = unref(notificationStore).selectedTab.chromeTab) == null ? void 0 : _c.title), 1),
          createBaseVNode("div", _hoisted_8, [
            createBaseVNode("div", _hoisted_9, [
              createTextVNode(toDisplayString(unref(notificationStore).selectedTab.chromeTab.url) + "\xA0", 1),
              createVNode(QIcon, {
                name: "launch",
                color: "secondary",
                onClick: _cache[0] || (_cache[0] = withModifiers(($event) => {
                  var _a2;
                  return unref(Navigation$1).openOrCreateTab((_a2 = _ctx.tab.chromeTab) == null ? void 0 : _a2.url);
                }, ["stop"]))
              })
            ])
          ])
        ]),
        createBaseVNode("div", _hoisted_10, [
          createBaseVNode("div", _hoisted_11, [
            createVNode(QImg, {
              src: thumbnail.value,
              width: "265px",
              style: { "border": "1px solid grey" },
              onClick: showTabDetails
            }, null, 8, ["src"])
          ]),
          createBaseVNode("div", _hoisted_12, [
            createBaseVNode("div", _hoisted_13, [
              _hoisted_14,
              createBaseVNode("div", _hoisted_15, toDisplayString(unref(date).formatDate(unref(notificationStore).selectedTab.created, "DD.MM.YYYY HH:mm")), 1),
              _hoisted_16,
              createBaseVNode("div", _hoisted_17, toDisplayString(unref(date).formatDate(unref(notificationStore).selectedTab.updated, "DD.MM.YYYY HH:mm")), 1),
              _hoisted_18,
              createBaseVNode("div", _hoisted_19, toDisplayString(unref(date).formatDate(unref(notificationStore).selectedTab.lastActive, "DD.MM.YYYY HH:mm")), 1),
              _hoisted_20,
              createBaseVNode("div", _hoisted_21, toDisplayString(unref(notificationStore).selectedTab.activatedCount), 1),
              _hoisted_22,
              createBaseVNode("div", _hoisted_23, toDisplayString(unref(notificationStore).selectedTab.history), 1),
              unref(notificationStore).selectedTab.bookmarkId ? (openBlock(), createElementBlock("div", _hoisted_24, " Bookmark ID ")) : createCommentVNode("", true),
              unref(notificationStore).selectedTab.bookmarkId ? (openBlock(), createElementBlock("div", _hoisted_25, toDisplayString(unref(notificationStore).selectedTab.bookmarkId), 1)) : createCommentVNode("", true),
              unref(notificationStore).selectedTab.bookmarkUrl ? (openBlock(), createElementBlock("div", _hoisted_26, " Bookmark URL ")) : createCommentVNode("", true),
              unref(notificationStore).selectedTab.bookmarkUrl ? (openBlock(), createElementBlock("div", _hoisted_27, toDisplayString(unref(notificationStore).selectedTab.bookmarkUrl), 1)) : createCommentVNode("", true)
            ])
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$7 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Tabset", -1);
const _hoisted_2$7 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please provide a new name for this tabset", -1);
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Tabset's name:", -1);
const _hoisted_4$2 = { class: "text-body2 text-warning" };
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "EditTabset",
  props: {
    tabsetId: {
      type: String,
      required: true
    },
    tabsetName: {
      type: String,
      required: true
    }
  },
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const props = __props;
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const tabsStore = useTabsStore();
    useRouter();
    const $q = useQuasar();
    const newTabsetName = ref(props.tabsetName);
    const newTabsetNameExists = ref(false);
    const hideWarning = ref(false);
    watchEffect(() => {
      newTabsetNameExists.value = !!tabsStore.nameExistsInContextTabset(newTabsetName.value);
    });
    const updateTabset = () => {
      TabsetService.rename(props.tabsetId, newTabsetName.value);
      $q.notify({
        message: "The tabset has been renamed",
        type: "positive"
      });
    };
    const newTabsetDialogWarning = () => {
      return !hideWarning.value && newTabsetName.value !== props.tabsetName && tabsStore.nameExistsInContextTabset(newTabsetName.value) ? "Tabset already exists" : "";
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1$7
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$7
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  _hoisted_3$3,
                  createVNode(QInput, {
                    dense: "",
                    modelValue: newTabsetName.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newTabsetName.value = $event),
                    autofocus: "",
                    onKeydown: _cache[1] || (_cache[1] = withKeys(($event) => updateTabset(), ["enter"]))
                  }, null, 8, ["modelValue"]),
                  createBaseVNode("div", _hoisted_4$2, toDisplayString(newTabsetDialogWarning()), 1)
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    label: "Rename Tabset",
                    disable: newTabsetName.value.trim().length === 0 || newTabsetName.value.trim() === props.tabsetName || newTabsetDialogWarning() !== "",
                    onClick: _cache[2] || (_cache[2] = ($event) => updateTabset())
                  }, null, 8, ["disable"]), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
var Navigation_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$6 = { key: 0 };
const _hoisted_2$6 = {
  key: 0,
  class: "text-body2 q-pa-lg"
};
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "Navigation",
  setup(__props) {
    const router = useRouter();
    const tabsStore = useTabsStore();
    useFeatureTogglesStore();
    const spacesStore = useSpacesStore();
    const showDeleteButton = ref(/* @__PURE__ */ new Map());
    const showEditButton = ref(/* @__PURE__ */ new Map());
    const $q = useQuasar();
    $q.localStorage;
    ref("");
    ref(false);
    $q.loadingBar.setDefaults({
      color: "green",
      size: "10px",
      position: "bottom"
    });
    const selectTabset = (tabsetId) => {
      TabsetService.selectTabset(tabsetId);
      router.push("/tabset");
    };
    const tabsets = () => {
      let tabsets2 = [...tabsStore.tabsets.values()];
      if (spacesStore.spaces && spacesStore.spaces.size > 0) {
        if (spacesStore.space && spacesStore.space.id && spacesStore.space.id.length > 0) {
          tabsets2 = _.filter(tabsets2, (ts) => ts.spaces && ts.spaces.indexOf(spacesStore.space.id) >= 0);
        } else {
          tabsets2 = _.filter(tabsets2, (ts) => ts.spaces && ts.spaces.length === 0);
        }
      }
      return _.sortBy(tabsets2, ["name"]);
    };
    const onDrop = (evt, tabsetId) => {
      if (evt.dataTransfer && tabsetId) {
        const tabId = evt.dataTransfer.getData("text/plain");
        TabsetService.moveToTabset(tabId, tabsetId);
      } else {
        console.log("got error dropping tab", tabsetId);
      }
    };
    const tabsetLabel = (tabset) => {
      var _a, _b, _c;
      return ((_a = tabset.tabs) == null ? void 0 : _a.length) > 1 ? tabset.name + " (" + ((_b = tabset.tabs) == null ? void 0 : _b.length) + " tabs)" : tabset.name + " (" + ((_c = tabset.tabs) == null ? void 0 : _c.length) + " tab)";
    };
    const showButtons = (tabsetId, show) => {
      showDeleteButton.value.set(tabsetId, show);
      showEditButton.value.set(tabsetId, show);
    };
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk(() => {
        TabsetService.delete(tabsStore.currentTabsetId);
        router.push("/about");
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const editDialog = (tabset) => $q.dialog({
      component: _sfc_main$9,
      componentProps: {
        tabsetId: tabset.id,
        tabsetName: tabset.name
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QList, { class: "q-mt-md" }, {
        default: withCtx(() => [
          createVNode(QToolbar, null, {
            default: withCtx(() => [
              createVNode(QToolbarTitle, { style: { "font-size": "16px" } }, {
                default: withCtx(() => [
                  createTextVNode("Tabsets "),
                  unref(tabsStore).tabsets.size > 3 ? (openBlock(), createElementBlock("span", _hoisted_1$6, "(" + toDisplayString(unref(tabsStore).tabsets.size) + ")", 1)) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          unref(tabsStore).tabsets.size === 0 ? (openBlock(), createElementBlock("div", _hoisted_2$6, [
            createVNode(QBanner, {
              rounded: "",
              class: "bg-amber-1"
            }, {
              default: withCtx(() => [
                createTextVNode(" No Tabsets (yet) ")
              ]),
              _: 1
            })
          ])) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(tabsets(), (tabset, index) => {
            return withDirectives((openBlock(), createBlock(QItem, {
              key: "local_" + tabset.id,
              "data-testid": "navigation_tabset_" + index,
              clickable: "",
              onClick: ($event) => selectTabset(tabset.id),
              onMouseover: ($event) => showButtons(tabset.id, true),
              onMouseleave: ($event) => showButtons(tabset.id, false),
              style: normalizeStyle(tabset.id === unref(tabsStore).currentTabsetId ? "background-color:#efefef" : "border:0px solid #bfbfbf")
            }, {
              default: withCtx(() => [
                createVNode(QItemSection, {
                  onDrop: ($event) => onDrop($event, tabset.id),
                  onDragover: _cache[0] || (_cache[0] = withModifiers(() => {
                  }, ["prevent"])),
                  onDragenter: _cache[1] || (_cache[1] = withModifiers(() => {
                  }, ["prevent"]))
                }, {
                  default: withCtx(() => [
                    createVNode(QItemLabel, {
                      textContent: toDisplayString(tabsetLabel(tabset))
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1032, ["onDrop"]),
                showEditButton.value.get(tabset.id) ? (openBlock(), createBlock(QItemSection, {
                  key: 0,
                  avatar: ""
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "edit",
                      color: "positive",
                      size: "2em",
                      onClick: ($event) => editDialog(tabset)
                    }, {
                      default: withCtx(() => [
                        createVNode(QTooltip, null, {
                          default: withCtx(() => [
                            createTextVNode("Edit the tabset's name...")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["onClick"])
                  ]),
                  _: 2
                }, 1024)) : createCommentVNode("", true),
                showDeleteButton.value.get(tabset.id) ? (openBlock(), createBlock(QItemSection, {
                  key: 1,
                  avatar: "",
                  "data-testid": "navigation_tabset_delete_" + index
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "delete_outline",
                      color: "negative",
                      size: "18px",
                      onClick: deleteDialog
                    }, {
                      default: withCtx(() => [
                        createVNode(QTooltip, null, {
                          default: withCtx(() => [
                            createTextVNode("Delete this tabset...")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 2
                }, 1032, ["data-testid"])) : createCommentVNode("", true)
              ]),
              _: 2
            }, 1032, ["data-testid", "onClick", "onMouseover", "onMouseleave", "style"])), [
              [Ripple]
            ]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
var Navigation = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-9b600056"]]);
let id = 0;
const useTabEmits = ["click", "keydown"];
const useTabProps = {
  icon: String,
  label: [Number, String],
  alert: [Boolean, String],
  alertIcon: String,
  name: {
    type: [Number, String],
    default: () => `t_${id++}`
  },
  noCaps: Boolean,
  tabindex: [String, Number],
  disable: Boolean,
  contentClass: String,
  ripple: {
    type: [Boolean, Object],
    default: true
  }
};
function useTab(props, slots, emit, routeData) {
  const $tabs = inject(tabsKey, emptyRenderFn);
  if ($tabs === emptyRenderFn) {
    console.error("QTab/QRouteTab component needs to be child of QTabs");
    return emptyRenderFn;
  }
  const { proxy } = getCurrentInstance();
  const blurTargetRef = ref(null);
  const rootRef = ref(null);
  const tabIndicatorRef = ref(null);
  const ripple = computed(() => props.disable === true || props.ripple === false ? false : Object.assign(
    { keyCodes: [13, 32], early: true },
    props.ripple === true ? {} : props.ripple
  ));
  const isActive = computed(() => $tabs.currentModel.value === props.name);
  const classes = computed(
    () => "q-tab relative-position self-stretch flex flex-center text-center" + (isActive.value === true ? " q-tab--active" + ($tabs.tabProps.value.activeClass ? " " + $tabs.tabProps.value.activeClass : "") + ($tabs.tabProps.value.activeColor ? ` text-${$tabs.tabProps.value.activeColor}` : "") + ($tabs.tabProps.value.activeBgColor ? ` bg-${$tabs.tabProps.value.activeBgColor}` : "") : " q-tab--inactive") + (props.icon && props.label && $tabs.tabProps.value.inlineLabel === false ? " q-tab--full" : "") + (props.noCaps === true || $tabs.tabProps.value.noCaps === true ? " q-tab--no-caps" : "") + (props.disable === true ? " disabled" : " q-focusable q-hoverable cursor-pointer") + (routeData !== void 0 ? routeData.linkClass.value : "")
  );
  const innerClass = computed(
    () => "q-tab__content self-stretch flex-center relative-position q-anchor--skip non-selectable " + ($tabs.tabProps.value.inlineLabel === true ? "row no-wrap q-tab__content--inline" : "column") + (props.contentClass !== void 0 ? ` ${props.contentClass}` : "")
  );
  const tabIndex = computed(() => props.disable === true || $tabs.hasFocus.value === true || isActive.value === false && $tabs.hasActiveTab.value === true ? -1 : props.tabindex || 0);
  function onClick(e, keyboard) {
    if (keyboard !== true && blurTargetRef.value !== null) {
      blurTargetRef.value.focus();
    }
    if (props.disable === true) {
      if (routeData !== void 0 && routeData.hasRouterLink.value === true) {
        stopAndPrevent(e);
      }
      return;
    }
    if (routeData === void 0) {
      $tabs.updateModel({ name: props.name });
      emit("click", e);
      return;
    }
    if (routeData.hasRouterLink.value === true) {
      const go = (opts = {}) => {
        let hardError;
        const reqId = opts.to === void 0 || isDeepEqual(opts.to, props.to) === true ? $tabs.avoidRouteWatcher = uid$1() : null;
        return routeData.navigateToRouterLink(e, { ...opts, returnRouterError: true }).catch((err) => {
          hardError = err;
        }).then((softError) => {
          if (reqId === $tabs.avoidRouteWatcher) {
            $tabs.avoidRouteWatcher = false;
            if (hardError === void 0 && (softError === void 0 || softError.message.startsWith("Avoided redundant navigation") === true)) {
              $tabs.updateModel({ name: props.name });
            }
          }
          if (opts.returnRouterError === true) {
            return hardError !== void 0 ? Promise.reject(hardError) : softError;
          }
        });
      };
      emit("click", e, go);
      e.defaultPrevented !== true && go();
      return;
    }
    emit("click", e);
  }
  function onKeydown(e) {
    if (isKeyCode(e, [13, 32])) {
      onClick(e, true);
    } else if (shouldIgnoreKey(e) !== true && e.keyCode >= 35 && e.keyCode <= 40 && e.altKey !== true && e.metaKey !== true) {
      $tabs.onKbdNavigate(e.keyCode, proxy.$el) === true && stopAndPrevent(e);
    }
    emit("keydown", e);
  }
  function getContent() {
    const narrow = $tabs.tabProps.value.narrowIndicator, content = [], indicator = h("div", {
      ref: tabIndicatorRef,
      class: [
        "q-tab__indicator",
        $tabs.tabProps.value.indicatorClass
      ]
    });
    props.icon !== void 0 && content.push(
      h(QIcon, {
        class: "q-tab__icon",
        name: props.icon
      })
    );
    props.label !== void 0 && content.push(
      h("div", { class: "q-tab__label" }, props.label)
    );
    props.alert !== false && content.push(
      props.alertIcon !== void 0 ? h(QIcon, {
        class: "q-tab__alert-icon",
        color: props.alert !== true ? props.alert : void 0,
        name: props.alertIcon
      }) : h("div", {
        class: "q-tab__alert" + (props.alert !== true ? ` text-${props.alert}` : "")
      })
    );
    narrow === true && content.push(indicator);
    const node = [
      h("div", { class: "q-focus-helper", tabindex: -1, ref: blurTargetRef }),
      h("div", { class: innerClass.value }, hMergeSlot(slots.default, content))
    ];
    narrow === false && node.push(indicator);
    return node;
  }
  const tabData = {
    name: computed(() => props.name),
    rootRef,
    tabIndicatorRef,
    routeData
  };
  onBeforeUnmount(() => {
    $tabs.unregisterTab(tabData);
  });
  onMounted(() => {
    $tabs.registerTab(tabData);
  });
  function renderTab(tag, customData) {
    const data = {
      ref: rootRef,
      class: classes.value,
      tabindex: tabIndex.value,
      role: "tab",
      "aria-selected": isActive.value === true ? "true" : "false",
      "aria-disabled": props.disable === true ? "true" : void 0,
      onClick,
      onKeydown,
      ...customData
    };
    return withDirectives(
      h(tag, data, getContent()),
      [[Ripple, ripple.value]]
    );
  }
  return { renderTab, $tabs };
}
var QTab = createComponent({
  name: "QTab",
  props: useTabProps,
  emits: useTabEmits,
  setup(props, { slots, emit }) {
    const { renderTab } = useTab(props, slots, emit);
    return () => renderTab("div");
  }
});
function getIndicatorClass(color, top, vertical) {
  const pos = vertical === true ? ["left", "right"] : ["top", "bottom"];
  return `absolute-${top === true ? pos[0] : pos[1]}${color ? ` text-${color}` : ""}`;
}
const alignValues = ["left", "center", "right", "justify"];
var QTabs = createComponent({
  name: "QTabs",
  props: {
    modelValue: [Number, String],
    align: {
      type: String,
      default: "center",
      validator: (v) => alignValues.includes(v)
    },
    breakpoint: {
      type: [String, Number],
      default: 600
    },
    vertical: Boolean,
    shrink: Boolean,
    stretch: Boolean,
    activeClass: String,
    activeColor: String,
    activeBgColor: String,
    indicatorColor: String,
    leftIcon: String,
    rightIcon: String,
    outsideArrows: Boolean,
    mobileArrows: Boolean,
    switchIndicator: Boolean,
    narrowIndicator: Boolean,
    inlineLabel: Boolean,
    noCaps: Boolean,
    dense: Boolean,
    contentClass: String,
    "onUpdate:modelValue": [Function, Array]
  },
  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance();
    const { $q } = proxy;
    const { registerTick: registerScrollTick } = useTick();
    const { registerTick: registerUpdateArrowsTick } = useTick();
    const { registerTick: registerAnimateTick } = useTick();
    const { registerTimeout: registerFocusTimeout, removeTimeout: removeFocusTimeout } = useTimeout();
    const { registerTimeout: registerScrollToTabTimeout, removeTimeout: removeScrollToTabTimeout } = useTimeout();
    const rootRef = ref(null);
    const contentRef = ref(null);
    const currentModel = ref(props.modelValue);
    const scrollable = ref(false);
    const leftArrow = ref(true);
    const rightArrow = ref(false);
    const justify = ref(false);
    const arrowsEnabled = computed(
      () => $q.platform.is.desktop === true || props.mobileArrows === true
    );
    const tabDataList = [];
    const tabDataListLen = ref(0);
    const hasFocus = ref(false);
    let animateTimer, scrollTimer, unwatchRoute;
    let localUpdateArrows = arrowsEnabled.value === true ? updateArrowsFn : noop;
    const tabProps = computed(() => ({
      activeClass: props.activeClass,
      activeColor: props.activeColor,
      activeBgColor: props.activeBgColor,
      indicatorClass: getIndicatorClass(
        props.indicatorColor,
        props.switchIndicator,
        props.vertical
      ),
      narrowIndicator: props.narrowIndicator,
      inlineLabel: props.inlineLabel,
      noCaps: props.noCaps
    }));
    const hasActiveTab = computed(() => {
      const len = tabDataListLen.value;
      const val = currentModel.value;
      for (let i = 0; i < len; i++) {
        if (tabDataList[i].name.value === val) {
          return true;
        }
      }
      return false;
    });
    const alignClass = computed(() => {
      const align = scrollable.value === true ? "left" : justify.value === true ? "justify" : props.align;
      return `q-tabs__content--align-${align}`;
    });
    const classes = computed(
      () => `q-tabs row no-wrap items-center q-tabs--${scrollable.value === true ? "" : "not-"}scrollable q-tabs--${props.vertical === true ? "vertical" : "horizontal"} q-tabs__arrows--${arrowsEnabled.value === true && props.outsideArrows === true ? "outside" : "inside"}` + (props.dense === true ? " q-tabs--dense" : "") + (props.shrink === true ? " col-shrink" : "") + (props.stretch === true ? " self-stretch" : "")
    );
    const innerClass = computed(
      () => "q-tabs__content row no-wrap items-center self-stretch hide-scrollbar relative-position " + alignClass.value + (props.contentClass !== void 0 ? ` ${props.contentClass}` : "") + ($q.platform.is.mobile === true ? " scroll" : "")
    );
    const domProps = computed(() => props.vertical === true ? { container: "height", content: "offsetHeight", scroll: "scrollHeight" } : { container: "width", content: "offsetWidth", scroll: "scrollWidth" });
    const isRTL = computed(() => props.vertical !== true && $q.lang.rtl === true);
    const rtlPosCorrection = computed(() => rtlHasScrollBug === false && isRTL.value === true);
    watch(isRTL, localUpdateArrows);
    watch(() => props.modelValue, (name) => {
      updateModel({ name, setCurrent: true, skipEmit: true });
    });
    watch(() => props.outsideArrows, () => {
      recalculateScroll();
    });
    watch(arrowsEnabled, (v) => {
      localUpdateArrows = v === true ? updateArrowsFn : noop;
      recalculateScroll();
    });
    function updateModel({ name, setCurrent, skipEmit, fromRoute }) {
      if (currentModel.value !== name) {
        if (skipEmit !== true && props["onUpdate:modelValue"] !== void 0) {
          emit("update:modelValue", name);
        }
        if (setCurrent === true || props["onUpdate:modelValue"] === void 0) {
          animate(currentModel.value, name);
          currentModel.value = name;
        }
      }
    }
    function recalculateScroll() {
      registerScrollTick(() => {
        updateContainer({
          width: rootRef.value.offsetWidth,
          height: rootRef.value.offsetHeight
        });
      });
    }
    function updateContainer(domSize) {
      if (domProps.value === void 0 || contentRef.value === null) {
        return;
      }
      const size = domSize[domProps.value.container], scrollSize = Math.min(
        contentRef.value[domProps.value.scroll],
        Array.prototype.reduce.call(
          contentRef.value.children,
          (acc, el) => acc + (el[domProps.value.content] || 0),
          0
        )
      ), scroll = size > 0 && scrollSize > size;
      scrollable.value = scroll;
      scroll === true && registerUpdateArrowsTick(localUpdateArrows);
      justify.value = size < parseInt(props.breakpoint, 10);
    }
    function animate(oldName, newName) {
      const oldTab = oldName !== void 0 && oldName !== null && oldName !== "" ? tabDataList.find((tab) => tab.name.value === oldName) : null, newTab = newName !== void 0 && newName !== null && newName !== "" ? tabDataList.find((tab) => tab.name.value === newName) : null;
      if (oldTab && newTab) {
        const oldEl = oldTab.tabIndicatorRef.value, newEl = newTab.tabIndicatorRef.value;
        clearTimeout(animateTimer);
        oldEl.style.transition = "none";
        oldEl.style.transform = "none";
        newEl.style.transition = "none";
        newEl.style.transform = "none";
        const oldPos = oldEl.getBoundingClientRect(), newPos = newEl.getBoundingClientRect();
        newEl.style.transform = props.vertical === true ? `translate3d(0,${oldPos.top - newPos.top}px,0) scale3d(1,${newPos.height ? oldPos.height / newPos.height : 1},1)` : `translate3d(${oldPos.left - newPos.left}px,0,0) scale3d(${newPos.width ? oldPos.width / newPos.width : 1},1,1)`;
        registerAnimateTick(() => {
          animateTimer = setTimeout(() => {
            newEl.style.transition = "transform .25s cubic-bezier(.4, 0, .2, 1)";
            newEl.style.transform = "none";
          }, 70);
        });
      }
      if (newTab && scrollable.value === true) {
        scrollToTabEl(newTab.rootRef.value);
      }
    }
    function scrollToTabEl(el) {
      const { left, width, top, height } = contentRef.value.getBoundingClientRect(), newPos = el.getBoundingClientRect();
      let offset = props.vertical === true ? newPos.top - top : newPos.left - left;
      if (offset < 0) {
        contentRef.value[props.vertical === true ? "scrollTop" : "scrollLeft"] += Math.floor(offset);
        localUpdateArrows();
        return;
      }
      offset += props.vertical === true ? newPos.height - height : newPos.width - width;
      if (offset > 0) {
        contentRef.value[props.vertical === true ? "scrollTop" : "scrollLeft"] += Math.ceil(offset);
        localUpdateArrows();
      }
    }
    function updateArrowsFn() {
      const content = contentRef.value;
      if (content !== null) {
        const rect = content.getBoundingClientRect(), pos = props.vertical === true ? content.scrollTop : Math.abs(content.scrollLeft);
        if (isRTL.value === true) {
          leftArrow.value = Math.ceil(pos + rect.width) < content.scrollWidth - 1;
          rightArrow.value = pos > 0;
        } else {
          leftArrow.value = pos > 0;
          rightArrow.value = props.vertical === true ? Math.ceil(pos + rect.height) < content.scrollHeight : Math.ceil(pos + rect.width) < content.scrollWidth;
        }
      }
    }
    function animScrollTo(value2) {
      stopAnimScroll();
      scrollTimer = setInterval(() => {
        if (scrollTowards(value2) === true) {
          stopAnimScroll();
        }
      }, 5);
    }
    function scrollToStart() {
      animScrollTo(rtlPosCorrection.value === true ? Number.MAX_SAFE_INTEGER : 0);
    }
    function scrollToEnd() {
      animScrollTo(rtlPosCorrection.value === true ? 0 : Number.MAX_SAFE_INTEGER);
    }
    function stopAnimScroll() {
      clearInterval(scrollTimer);
    }
    function onKbdNavigate(keyCode, fromEl) {
      const tabs = Array.prototype.filter.call(
        contentRef.value.children,
        (el) => el === fromEl || el.matches && el.matches(".q-tab.q-focusable") === true
      );
      const len = tabs.length;
      if (len === 0) {
        return;
      }
      if (keyCode === 36) {
        scrollToTabEl(tabs[0]);
        tabs[0].focus();
        return true;
      }
      if (keyCode === 35) {
        scrollToTabEl(tabs[len - 1]);
        tabs[len - 1].focus();
        return true;
      }
      const dirPrev = keyCode === (props.vertical === true ? 38 : 37);
      const dirNext = keyCode === (props.vertical === true ? 40 : 39);
      const dir = dirPrev === true ? -1 : dirNext === true ? 1 : void 0;
      if (dir !== void 0) {
        const rtlDir = isRTL.value === true ? -1 : 1;
        const index = tabs.indexOf(fromEl) + dir * rtlDir;
        if (index >= 0 && index < len) {
          scrollToTabEl(tabs[index]);
          tabs[index].focus({ preventScroll: true });
        }
        return true;
      }
    }
    const posFn = computed(() => rtlPosCorrection.value === true ? { get: (content) => Math.abs(content.scrollLeft), set: (content, pos) => {
      content.scrollLeft = -pos;
    } } : props.vertical === true ? { get: (content) => content.scrollTop, set: (content, pos) => {
      content.scrollTop = pos;
    } } : { get: (content) => content.scrollLeft, set: (content, pos) => {
      content.scrollLeft = pos;
    } });
    function scrollTowards(value2) {
      const content = contentRef.value, { get, set } = posFn.value;
      let done = false, pos = get(content);
      const direction = value2 < pos ? -1 : 1;
      pos += direction * 5;
      if (pos < 0) {
        done = true;
        pos = 0;
      } else if (direction === -1 && pos <= value2 || direction === 1 && pos >= value2) {
        done = true;
        pos = value2;
      }
      set(content, pos);
      localUpdateArrows();
      return done;
    }
    function hasQueryIncluded(targetQuery, matchingQuery) {
      for (const key in targetQuery) {
        if (targetQuery[key] !== matchingQuery[key]) {
          return false;
        }
      }
      return true;
    }
    function updateActiveRoute() {
      let name = null, bestScore = { matchedLen: 0, queryDiff: 9999, hrefLen: 0 };
      const list = tabDataList.filter((tab) => tab.routeData !== void 0 && tab.routeData.hasRouterLink.value === true);
      const { hash: currentHash, query: currentQuery } = proxy.$route;
      const currentQueryLen = Object.keys(currentQuery).length;
      for (const tab of list) {
        const exact = tab.routeData.exact.value === true;
        if (tab.routeData[exact === true ? "linkIsExactActive" : "linkIsActive"].value !== true) {
          continue;
        }
        const { hash, query, matched, href } = tab.routeData.resolvedLink.value;
        const queryLen = Object.keys(query).length;
        if (exact === true) {
          if (hash !== currentHash) {
            continue;
          }
          if (queryLen !== currentQueryLen || hasQueryIncluded(currentQuery, query) === false) {
            continue;
          }
          name = tab.name.value;
          break;
        }
        if (hash !== "" && hash !== currentHash) {
          continue;
        }
        if (queryLen !== 0 && hasQueryIncluded(query, currentQuery) === false) {
          continue;
        }
        const newScore = {
          matchedLen: matched.length,
          queryDiff: currentQueryLen - queryLen,
          hrefLen: href.length - hash.length
        };
        if (newScore.matchedLen > bestScore.matchedLen) {
          name = tab.name.value;
          bestScore = newScore;
          continue;
        } else if (newScore.matchedLen !== bestScore.matchedLen) {
          continue;
        }
        if (newScore.queryDiff < bestScore.queryDiff) {
          name = tab.name.value;
          bestScore = newScore;
        } else if (newScore.queryDiff !== bestScore.queryDiff) {
          continue;
        }
        if (newScore.hrefLen > bestScore.hrefLen) {
          name = tab.name.value;
          bestScore = newScore;
        }
      }
      if (name === null && tabDataList.some((tab) => tab.routeData === void 0 && tab.name.value === currentModel.value) === true) {
        return;
      }
      updateModel({ name, setCurrent: true });
    }
    function onFocusin(e) {
      removeFocusTimeout();
      if (hasFocus.value !== true && rootRef.value !== null && e.target && typeof e.target.closest === "function") {
        const tab = e.target.closest(".q-tab");
        if (tab && rootRef.value.contains(tab) === true) {
          hasFocus.value = true;
          scrollable.value === true && scrollToTabEl(tab);
        }
      }
    }
    function onFocusout() {
      registerFocusTimeout(() => {
        hasFocus.value = false;
      }, 30);
    }
    function verifyRouteModel() {
      if ($tabs.avoidRouteWatcher === false) {
        registerScrollToTabTimeout(updateActiveRoute);
      } else {
        removeScrollToTabTimeout();
      }
    }
    function watchRoute() {
      if (unwatchRoute === void 0) {
        const unwatch = watch(() => proxy.$route.fullPath, verifyRouteModel);
        unwatchRoute = () => {
          unwatch();
          unwatchRoute = void 0;
        };
      }
    }
    function registerTab(tabData) {
      tabDataList.push(tabData);
      tabDataListLen.value++;
      recalculateScroll();
      if (tabData.routeData === void 0 || proxy.$route === void 0) {
        registerScrollToTabTimeout(() => {
          if (scrollable.value === true) {
            const value2 = currentModel.value;
            const newTab = value2 !== void 0 && value2 !== null && value2 !== "" ? tabDataList.find((tab) => tab.name.value === value2) : null;
            newTab && scrollToTabEl(newTab.rootRef.value);
          }
        });
      } else {
        watchRoute();
        if (tabData.routeData.hasRouterLink.value === true) {
          verifyRouteModel();
        }
      }
    }
    function unregisterTab(tabData) {
      tabDataList.splice(tabDataList.indexOf(tabData), 1);
      tabDataListLen.value--;
      recalculateScroll();
      if (unwatchRoute !== void 0 && tabData.routeData !== void 0) {
        if (tabDataList.every((tab) => tab.routeData === void 0) === true) {
          unwatchRoute();
        }
        verifyRouteModel();
      }
    }
    const $tabs = {
      currentModel,
      tabProps,
      hasFocus,
      hasActiveTab,
      registerTab,
      unregisterTab,
      verifyRouteModel,
      updateModel,
      onKbdNavigate,
      avoidRouteWatcher: false
    };
    provide(tabsKey, $tabs);
    function cleanup() {
      clearTimeout(animateTimer);
      stopAnimScroll();
      unwatchRoute !== void 0 && unwatchRoute();
    }
    let hadRouteWatcher;
    onBeforeUnmount(cleanup);
    onDeactivated(() => {
      hadRouteWatcher = unwatchRoute !== void 0;
      cleanup();
    });
    onActivated(() => {
      hadRouteWatcher === true && watchRoute();
      recalculateScroll();
    });
    return () => {
      const child = [
        h(QResizeObserver, { onResize: updateContainer }),
        h("div", {
          ref: contentRef,
          class: innerClass.value,
          onScroll: localUpdateArrows
        }, hSlot(slots.default))
      ];
      arrowsEnabled.value === true && child.push(
        h(QIcon, {
          class: "q-tabs__arrow q-tabs__arrow--left absolute q-tab__icon" + (leftArrow.value === true ? "" : " q-tabs__arrow--faded"),
          name: props.leftIcon || $q.iconSet.tabs[props.vertical === true ? "up" : "left"],
          onMousedownPassive: scrollToStart,
          onTouchstartPassive: scrollToStart,
          onMouseupPassive: stopAnimScroll,
          onMouseleavePassive: stopAnimScroll,
          onTouchendPassive: stopAnimScroll
        }),
        h(QIcon, {
          class: "q-tabs__arrow q-tabs__arrow--right absolute q-tab__icon" + (rightArrow.value === true ? "" : " q-tabs__arrow--faded"),
          name: props.rightIcon || $q.iconSet.tabs[props.vertical === true ? "down" : "right"],
          onMousedownPassive: scrollToEnd,
          onTouchstartPassive: scrollToEnd,
          onMouseupPassive: stopAnimScroll,
          onMouseleavePassive: stopAnimScroll,
          onTouchendPassive: stopAnimScroll
        })
      );
      return h("div", {
        ref: rootRef,
        class: classes.value,
        role: "tablist",
        onFocusin,
        onFocusout
      }, child);
    };
  }
});
const tickStrategyOptions = ["none", "strict", "leaf", "leaf-filtered"];
var QTree = createComponent({
  name: "QTree",
  props: {
    ...useDarkProps,
    nodes: {
      type: Array,
      required: true
    },
    nodeKey: {
      type: String,
      required: true
    },
    labelKey: {
      type: String,
      default: "label"
    },
    childrenKey: {
      type: String,
      default: "children"
    },
    dense: Boolean,
    color: String,
    controlColor: String,
    textColor: String,
    selectedColor: String,
    icon: String,
    tickStrategy: {
      type: String,
      default: "none",
      validator: (v) => tickStrategyOptions.includes(v)
    },
    ticked: Array,
    expanded: Array,
    selected: {},
    noSelectionUnset: Boolean,
    defaultExpandAll: Boolean,
    accordion: Boolean,
    filter: String,
    filterMethod: Function,
    duration: Number,
    noConnectors: Boolean,
    noTransition: Boolean,
    noNodesLabel: String,
    noResultsLabel: String
  },
  emits: [
    "update:expanded",
    "update:ticked",
    "update:selected",
    "lazyLoad",
    "afterShow",
    "afterHide"
  ],
  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance();
    const { $q } = proxy;
    const isDark = useDark(props, $q);
    const lazy = ref({});
    const innerTicked = ref(props.ticked || []);
    const innerExpanded = ref(props.expanded || []);
    let blurTargets = {};
    onBeforeUpdate(() => {
      blurTargets = {};
    });
    const classes = computed(
      () => `q-tree q-tree--${props.dense === true ? "dense" : "standard"}` + (props.noConnectors === true ? " q-tree--no-connectors" : "") + (isDark.value === true ? " q-tree--dark" : "") + (props.color !== void 0 ? ` text-${props.color}` : "")
    );
    const hasSelection = computed(() => props.selected !== void 0);
    const computedIcon = computed(() => props.icon || $q.iconSet.tree.icon);
    const computedControlColor = computed(() => props.controlColor || props.color);
    const textColorClass = computed(() => props.textColor !== void 0 ? ` text-${props.textColor}` : "");
    const selectedColorClass = computed(() => {
      const color = props.selectedColor || props.color;
      return color ? ` text-${color}` : "";
    });
    const computedFilterMethod = computed(() => props.filterMethod !== void 0 ? props.filterMethod : (node, filter) => {
      const filt = filter.toLowerCase();
      return node[props.labelKey] && node[props.labelKey].toLowerCase().indexOf(filt) > -1;
    });
    const meta = computed(() => {
      const meta2 = {};
      const travel = (node, parent) => {
        const tickStrategy = node.tickStrategy || (parent ? parent.tickStrategy : props.tickStrategy);
        const key = node[props.nodeKey], isParent = node[props.childrenKey] && node[props.childrenKey].length > 0, selectable = node.disabled !== true && hasSelection.value === true && node.selectable !== false, expandable = node.disabled !== true && node.expandable !== false, hasTicking = tickStrategy !== "none", strictTicking = tickStrategy === "strict", leafFilteredTicking = tickStrategy === "leaf-filtered", leafTicking = tickStrategy === "leaf" || tickStrategy === "leaf-filtered";
        let tickable = node.disabled !== true && node.tickable !== false;
        if (leafTicking === true && tickable === true && parent && parent.tickable !== true) {
          tickable = false;
        }
        let localLazy = node.lazy;
        if (localLazy === true && lazy.value[key] !== void 0 && Array.isArray(node[props.childrenKey]) === true) {
          localLazy = lazy.value[key];
        }
        const m = {
          key,
          parent,
          isParent,
          lazy: localLazy,
          disabled: node.disabled,
          link: node.disabled !== true && (selectable === true || expandable === true && (isParent === true || localLazy === true)),
          children: [],
          matchesFilter: props.filter ? computedFilterMethod.value(node, props.filter) : true,
          selected: key === props.selected && selectable === true,
          selectable,
          expanded: isParent === true ? innerExpanded.value.includes(key) : false,
          expandable,
          noTick: node.noTick === true || strictTicking !== true && localLazy && localLazy !== "loaded",
          tickable,
          tickStrategy,
          hasTicking,
          strictTicking,
          leafFilteredTicking,
          leafTicking,
          ticked: strictTicking === true ? innerTicked.value.includes(key) : isParent === true ? false : innerTicked.value.includes(key)
        };
        meta2[key] = m;
        if (isParent === true) {
          m.children = node[props.childrenKey].map((n) => travel(n, m));
          if (props.filter) {
            if (m.matchesFilter !== true) {
              m.matchesFilter = m.children.some((n) => n.matchesFilter);
            } else if (m.noTick !== true && m.disabled !== true && m.tickable === true && leafFilteredTicking === true && m.children.every((n) => n.matchesFilter !== true || n.noTick === true || n.tickable !== true) === true) {
              m.tickable = false;
            }
          }
          if (m.matchesFilter === true) {
            if (m.noTick !== true && strictTicking !== true && m.children.every((n) => n.noTick) === true) {
              m.noTick = true;
            }
            if (leafTicking) {
              m.ticked = false;
              m.indeterminate = m.children.some((node2) => node2.indeterminate === true);
              m.tickable = m.tickable === true && m.children.some((node2) => node2.tickable);
              if (m.indeterminate !== true) {
                const sel = m.children.reduce((acc, meta3) => meta3.ticked === true ? acc + 1 : acc, 0);
                if (sel === m.children.length) {
                  m.ticked = true;
                } else if (sel > 0) {
                  m.indeterminate = true;
                }
              }
              if (m.indeterminate === true) {
                m.indeterminateNextState = m.children.every((meta3) => meta3.tickable !== true || meta3.ticked !== true);
              }
            }
          }
        }
        return m;
      };
      props.nodes.forEach((node) => travel(node, null));
      return meta2;
    });
    watch(() => props.ticked, (val) => {
      innerTicked.value = val;
    });
    watch(() => props.expanded, (val) => {
      innerExpanded.value = val;
    });
    function getNodeByKey(key) {
      const reduce = [].reduce;
      const find = (result, node) => {
        if (result || !node) {
          return result;
        }
        if (Array.isArray(node) === true) {
          return reduce.call(Object(node), find, result);
        }
        if (node[props.nodeKey] === key) {
          return node;
        }
        if (node[props.childrenKey]) {
          return find(null, node[props.childrenKey]);
        }
      };
      return find(null, props.nodes);
    }
    function getTickedNodes() {
      return innerTicked.value.map((key) => getNodeByKey(key));
    }
    function getExpandedNodes() {
      return innerExpanded.value.map((key) => getNodeByKey(key));
    }
    function isExpanded(key) {
      return key && meta.value[key] ? meta.value[key].expanded : false;
    }
    function collapseAll() {
      if (props.expanded !== void 0) {
        emit("update:expanded", []);
      } else {
        innerExpanded.value = [];
      }
    }
    function expandAll() {
      const expanded = innerExpanded.value, travel = (node) => {
        if (node[props.childrenKey] && node[props.childrenKey].length > 0) {
          if (node.expandable !== false && node.disabled !== true) {
            expanded.push(node[props.nodeKey]);
            node[props.childrenKey].forEach(travel);
          }
        }
      };
      props.nodes.forEach(travel);
      if (props.expanded !== void 0) {
        emit("update:expanded", expanded);
      } else {
        innerExpanded.value = expanded;
      }
    }
    function setExpanded(key, state, node = getNodeByKey(key), m = meta.value[key]) {
      if (m.lazy && m.lazy !== "loaded") {
        if (m.lazy === "loading") {
          return;
        }
        lazy.value[key] = "loading";
        if (Array.isArray(node[props.childrenKey]) !== true) {
          node[props.childrenKey] = [];
        }
        emit("lazyLoad", {
          node,
          key,
          done: (children) => {
            lazy.value[key] = "loaded";
            node[props.childrenKey] = Array.isArray(children) === true ? children : [];
            nextTick(() => {
              const localMeta = meta.value[key];
              if (localMeta && localMeta.isParent === true) {
                localSetExpanded(key, true);
              }
            });
          },
          fail: () => {
            delete lazy.value[key];
            if (node[props.childrenKey].length === 0) {
              delete node[props.childrenKey];
            }
          }
        });
      } else if (m.isParent === true && m.expandable === true) {
        localSetExpanded(key, state);
      }
    }
    function localSetExpanded(key, state) {
      let target = innerExpanded.value;
      const shouldEmit = props.expanded !== void 0;
      if (shouldEmit === true) {
        target = target.slice();
      }
      if (state) {
        if (props.accordion) {
          if (meta.value[key]) {
            const collapse = [];
            if (meta.value[key].parent) {
              meta.value[key].parent.children.forEach((m) => {
                if (m.key !== key && m.expandable === true) {
                  collapse.push(m.key);
                }
              });
            } else {
              props.nodes.forEach((node) => {
                const k = node[props.nodeKey];
                if (k !== key) {
                  collapse.push(k);
                }
              });
            }
            if (collapse.length > 0) {
              target = target.filter((k) => collapse.includes(k) === false);
            }
          }
        }
        target = target.concat([key]).filter((key2, index, self) => self.indexOf(key2) === index);
      } else {
        target = target.filter((k) => k !== key);
      }
      if (shouldEmit === true) {
        emit("update:expanded", target);
      } else {
        innerExpanded.value = target;
      }
    }
    function isTicked(key) {
      return key && meta.value[key] ? meta.value[key].ticked : false;
    }
    function setTicked(keys, state) {
      let target = innerTicked.value;
      const shouldEmit = props.ticked !== void 0;
      if (shouldEmit === true) {
        target = target.slice();
      }
      if (state) {
        target = target.concat(keys).filter((key, index, self) => self.indexOf(key) === index);
      } else {
        target = target.filter((k) => keys.includes(k) === false);
      }
      if (shouldEmit === true) {
        emit("update:ticked", target);
      }
    }
    function getSlotScope(node, meta2, key) {
      const scope = { tree: proxy, node, key, color: props.color, dark: isDark.value };
      injectProp(
        scope,
        "expanded",
        () => {
          return meta2.expanded;
        },
        (val) => {
          val !== meta2.expanded && setExpanded(key, val);
        }
      );
      injectProp(
        scope,
        "ticked",
        () => {
          return meta2.ticked;
        },
        (val) => {
          val !== meta2.ticked && setTicked([key], val);
        }
      );
      return scope;
    }
    function getChildren(nodes) {
      return (props.filter ? nodes.filter((n) => meta.value[n[props.nodeKey]].matchesFilter) : nodes).map((child) => getNode(child));
    }
    function getNodeMedia(node) {
      if (node.icon !== void 0) {
        return h(QIcon, {
          class: "q-tree__icon q-mr-sm",
          name: node.icon,
          color: node.iconColor
        });
      }
      const src = node.img || node.avatar;
      if (src) {
        return h("img", {
          class: `q-tree__${node.img ? "img" : "avatar"} q-mr-sm`,
          src
        });
      }
    }
    function onShow() {
      emit("afterShow");
    }
    function onHide() {
      emit("afterHide");
    }
    function getNode(node) {
      const key = node[props.nodeKey], m = meta.value[key], header = node.header ? slots[`header-${node.header}`] || slots["default-header"] : slots["default-header"];
      const children = m.isParent === true ? getChildren(node[props.childrenKey]) : [];
      const isParent = children.length > 0 || m.lazy && m.lazy !== "loaded";
      let body = node.body ? slots[`body-${node.body}`] || slots["default-body"] : slots["default-body"];
      const slotScope = header !== void 0 || body !== void 0 ? getSlotScope(node, m, key) : null;
      if (body !== void 0) {
        body = h("div", { class: "q-tree__node-body relative-position" }, [
          h("div", { class: textColorClass.value }, [
            body(slotScope)
          ])
        ]);
      }
      return h("div", {
        key,
        class: `q-tree__node relative-position q-tree__node--${isParent === true ? "parent" : "child"}`
      }, [
        h("div", {
          class: "q-tree__node-header relative-position row no-wrap items-center" + (m.link === true ? " q-tree__node--link q-hoverable q-focusable" : "") + (m.selected === true ? " q-tree__node--selected" : "") + (m.disabled === true ? " q-tree__node--disabled" : ""),
          tabindex: m.link === true ? 0 : -1,
          onClick: (e) => {
            onClick(node, m, e);
          },
          onKeypress(e) {
            if (shouldIgnoreKey(e) !== true) {
              if (e.keyCode === 13) {
                onClick(node, m, e, true);
              } else if (e.keyCode === 32) {
                onExpandClick(node, m, e, true);
              }
            }
          }
        }, [
          h("div", {
            class: "q-focus-helper",
            tabindex: -1,
            ref: (el) => {
              blurTargets[m.key] = el;
            }
          }),
          m.lazy === "loading" ? h(QSpinner, {
            class: "q-tree__spinner",
            color: computedControlColor.value
          }) : isParent === true ? h(QIcon, {
            class: "q-tree__arrow" + (m.expanded === true ? " q-tree__arrow--rotate" : ""),
            name: computedIcon.value,
            onClick(e) {
              onExpandClick(node, m, e);
            }
          }) : null,
          m.hasTicking === true && m.noTick !== true ? h(QCheckbox, {
            class: "q-tree__tickbox",
            modelValue: m.indeterminate === true ? null : m.ticked,
            color: computedControlColor.value,
            dark: isDark.value,
            dense: true,
            keepColor: true,
            disable: m.tickable !== true,
            onKeydown: stopAndPrevent,
            "onUpdate:modelValue": (v) => {
              onTickedClick(m, v);
            }
          }) : null,
          h("div", {
            class: "q-tree__node-header-content col row no-wrap items-center" + (m.selected === true ? selectedColorClass.value : textColorClass.value)
          }, [
            header ? header(slotScope) : [
              getNodeMedia(node),
              h("div", node[props.labelKey])
            ]
          ])
        ]),
        isParent === true ? props.noTransition === true ? h("div", {
          class: "q-tree__node-collapsible" + textColorClass.value,
          key: `${key}__q`
        }, [
          body,
          h("div", {
            class: "q-tree__children" + (m.disabled === true ? " q-tree__node--disabled" : "")
          }, m.expanded ? children : null)
        ]) : h(QSlideTransition, {
          duration: props.duration,
          onShow,
          onHide
        }, () => withDirectives(
          h("div", {
            class: "q-tree__node-collapsible" + textColorClass.value,
            key: `${key}__q`
          }, [
            body,
            h("div", {
              class: "q-tree__children" + (m.disabled === true ? " q-tree__node--disabled" : "")
            }, children)
          ]),
          [[vShow, m.expanded]]
        )) : body
      ]);
    }
    function blur(key) {
      const blurTarget = blurTargets[key];
      blurTarget && blurTarget.focus();
    }
    function onClick(node, meta2, e, keyboard) {
      keyboard !== true && blur(meta2.key);
      if (hasSelection.value && meta2.selectable) {
        if (props.noSelectionUnset === false) {
          emit("update:selected", meta2.key !== props.selected ? meta2.key : null);
        } else if (meta2.key !== props.selected) {
          emit("update:selected", meta2.key === void 0 ? null : meta2.key);
        }
      } else {
        onExpandClick(node, meta2, e, keyboard);
      }
      if (typeof node.handler === "function") {
        node.handler(node);
      }
    }
    function onExpandClick(node, meta2, e, keyboard) {
      if (e !== void 0) {
        stopAndPrevent(e);
      }
      keyboard !== true && blur(meta2.key);
      setExpanded(meta2.key, !meta2.expanded, node, meta2);
    }
    function onTickedClick(meta2, state) {
      if (meta2.indeterminate === true) {
        state = meta2.indeterminateNextState;
      }
      if (meta2.strictTicking) {
        setTicked([meta2.key], state);
      } else if (meta2.leafTicking) {
        const keys = [];
        const travel = (meta3) => {
          if (meta3.isParent) {
            if (state !== true && meta3.noTick !== true && meta3.tickable === true) {
              keys.push(meta3.key);
            }
            if (meta3.leafTicking === true) {
              meta3.children.forEach(travel);
            }
          } else if (meta3.noTick !== true && meta3.tickable === true && (meta3.leafFilteredTicking !== true || meta3.matchesFilter === true)) {
            keys.push(meta3.key);
          }
        };
        travel(meta2);
        setTicked(keys, state);
      }
    }
    props.defaultExpandAll === true && expandAll();
    Object.assign(proxy, {
      getNodeByKey,
      getTickedNodes,
      getExpandedNodes,
      isExpanded,
      collapseAll,
      expandAll,
      setExpanded,
      isTicked,
      setTicked
    });
    return () => {
      const children = getChildren(props.nodes);
      return h(
        "div",
        {
          class: classes.value
        },
        children.length === 0 ? props.filter ? props.noResultsLabel || $q.lang.tree.noResults : props.noNodesLabel || $q.lang.tree.noNodes : children
      );
    };
  }
});
var BookmarksTree_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$5 = { class: "cursor-pointer fit no-wrap" };
const _hoisted_2$5 = { class: "text-right fit" };
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "BookmarksTree",
  setup(__props) {
    const router = useRouter();
    useTabsStore();
    useFeatureTogglesStore();
    const bookmarksStore = useBookmarksStore();
    const $q = useQuasar();
    const localStorage = useQuasar().localStorage;
    const mouseHover = ref(false);
    const selected = ref("");
    const deleteButtonId = ref("");
    ref("");
    ref(false);
    watch(() => selected.value, (currentValue, oldValue) => {
      if (currentValue !== oldValue) {
        router.push("/bookmarks/" + selected.value);
      }
    });
    watchEffect(() => {
      localStorage.set("bookmarks.expanded", useNotificationsStore().bookmarksExpanded);
    });
    watchEffect(() => {
      deleteButtonId.value = selected.value;
    });
    $q.loadingBar.setDefaults({
      color: "positive",
      size: "10px",
      position: "bottom"
    });
    const deleteBookmarksFolderDialog = () => {
      $q.dialog({
        title: "Delete Bookmark Folder",
        message: "Would you like to delete this folder and its subfolders and bookmarks? This cannot be undone",
        cancel: true,
        persistent: true
      }).onOk(() => {
        BookmarksService.deleteBookmarksFolder(selected.value);
        router.push("/start");
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const entered = (b) => mouseHover.value = b;
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QList, { class: "q-mt-md" }, {
        default: withCtx(() => [
          createVNode(QTree, {
            nodes: unref(bookmarksStore).bookmarksNodes,
            "node-key": "id",
            "selected-color": "dark",
            onMouseenter: _cache[0] || (_cache[0] = ($event) => entered(true)),
            onMouseleave: _cache[1] || (_cache[1] = ($event) => entered(false)),
            selected: selected.value,
            "onUpdate:selected": _cache[2] || (_cache[2] = ($event) => selected.value = $event),
            expanded: unref(useNotificationsStore)().bookmarksExpanded,
            "onUpdate:expanded": _cache[3] || (_cache[3] = ($event) => unref(useNotificationsStore)().bookmarksExpanded = $event)
          }, {
            "header-node": withCtx((prop) => [
              createVNode(QIcon, {
                name: "o_folder",
                class: "q-mr-sm"
              }),
              createBaseVNode("span", _hoisted_1$5, toDisplayString(prop.node.label), 1),
              withDirectives(createBaseVNode("span", _hoisted_2$5, [
                createVNode(QIcon, {
                  name: "delete_outline",
                  color: "negative",
                  size: "18px",
                  onClick: withModifiers(deleteBookmarksFolderDialog, ["stop"])
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => [
                        createTextVNode("Delete this folder")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onClick"])
              ], 512), [
                [vShow, mouseHover.value && prop.node.id === deleteButtonId.value]
              ])
            ]),
            _: 1
          }, 8, ["nodes", "selected", "expanded"])
        ]),
        _: 1
      });
    };
  }
});
var BookmarksTree = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-298ce018"]]);
const _hoisted_1$4 = { class: "row items-baseline" };
const _hoisted_2$4 = { class: "col-2" };
const _hoisted_3$2 = { class: "col-9 text-body2 ellipsis" };
const _hoisted_4$1 = { class: "col-1" };
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "OpenTabCard",
  props: {
    tab: {
      type: Tab,
      required: true
    }
  },
  setup(__props) {
    const closeTab = (tab) => Navigation$1.closeChromeTab(tab);
    const cardStyle = (tab) => {
      const height = "40px";
      let background = "";
      if (tab.isDuplicate) {
        background = "background: radial-gradient(circle, #FFFFFF 0%, #FFECB3 100%)";
      }
      return `height: ${height};max-height:${height}; min-height: ${height};border:1px solid grey;border-bottom: 0px;position:relative; top:5px;border-radius: 5px 5px 0 0;${background}`;
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        class: "my-card",
        flat: "",
        style: normalizeStyle(cardStyle(__props.tab))
      }, {
        default: withCtx(() => [
          createVNode(QCardSection, {
            class: "q-pt-xs cursor-pointer",
            style: { "width": "100%" }
          }, {
            default: withCtx(() => {
              var _a, _b;
              return [
                createBaseVNode("div", _hoisted_1$4, [
                  createBaseVNode("div", _hoisted_2$4, [
                    createVNode(QImg, {
                      class: "rounded-borders",
                      width: "20px",
                      height: "20px",
                      src: (_a = __props.tab.chromeTab) == null ? void 0 : _a.favIconUrl
                    }, null, 8, ["src"])
                  ]),
                  createBaseVNode("div", _hoisted_3$2, toDisplayString((_b = __props.tab.chromeTab) == null ? void 0 : _b.title), 1),
                  createBaseVNode("div", _hoisted_4$1, [
                    createVNode(QIcon, {
                      name: "close",
                      onClick: _cache[0] || (_cache[0] = ($event) => closeTab(__props.tab))
                    })
                  ])
                ])
              ];
            }),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["style"]);
    };
  }
});
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "OpenTabs",
  setup(__props) {
    const tabsStore = useTabsStore();
    function unpinnedNoGroup() {
      var _a;
      return _.filter(
        (_a = tabsStore.browserTabset) == null ? void 0 : _a.tabs,
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1
      );
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QSeparator),
        createVNode(unref(VueDraggableNext), {
          list: unpinnedNoGroup(),
          group: { name: "tabs", pull: "clone", put: false },
          sort: true
        }, {
          default: withCtx(() => [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unpinnedNoGroup(), (tab) => {
              return openBlock(), createElementBlock("div", {
                class: "col-12 q-pa-xs items-center justify-center",
                style: { "width": "100%", "max-width": "300px", "cursor": "move" },
                key: tab.id
              }, [
                createVNode(_sfc_main$6, { tab }, null, 8, ["tab"])
              ]);
            }), 128))
          ]),
          _: 1
        }, 8, ["list"])
      ], 64);
    };
  }
});
const _hoisted_1$3 = {
  class: "col-12 q-pa-xs items-center justify-center",
  style: { "width": "100%", "max-width": "300px", "cursor": "move" }
};
const _hoisted_2$3 = { class: "row items-baseline" };
const _hoisted_3$1 = { class: "col-2" };
const _hoisted_4 = { class: "col-9 text-body2 ellipsis" };
const _hoisted_5 = { class: "col-1" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "SavedTabs",
  setup(__props) {
    useTabsStore();
    const router = useRouter();
    const mhtmls = ref([]);
    MHtmlService.getMHtmls().then((res) => {
      mhtmls.value = res;
    });
    const open = (url) => {
      router.push("/mhtml/" + url);
    };
    const deleteMHtml = () => {
      console.log("deleting...");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QSeparator),
        (openBlock(true), createElementBlock(Fragment, null, renderList(mhtmls.value, (mhtml) => {
          return openBlock(), createElementBlock("div", _hoisted_1$3, [
            createVNode(QCard, {
              class: "my-card",
              flat: "",
              onClick: ($event) => open(mhtml.id)
            }, {
              default: withCtx(() => [
                createVNode(QCardSection, {
                  class: "q-pt-xs cursor-pointer",
                  style: { "width": "100%" }
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_2$3, [
                      createBaseVNode("div", _hoisted_3$1, [
                        createVNode(QImg, {
                          class: "rounded-borders",
                          width: "20px",
                          height: "20px",
                          src: mhtml.favIconUrl
                        }, null, 8, ["src"])
                      ]),
                      createBaseVNode("div", _hoisted_4, toDisplayString(mhtml.title), 1),
                      createBaseVNode("div", _hoisted_5, [
                        createVNode(QIcon, {
                          name: "close",
                          onClick: withModifiers(($event) => deleteMHtml(mhtml), ["stop"])
                        }, null, 8, ["onClick"])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1032, ["onClick"])
          ]);
        }), 256))
      ], 64);
    };
  }
});
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "DrawerLeft",
  setup(__props) {
    useRouter();
    const tab = ref("bookmarks");
    watchEffect(() => {
      tab.value = useNotificationsStore().showOpenTabs ? "openTabs" : "bookmarks";
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QTabs, {
          modelValue: tab.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => tab.value = $event),
          dense: "",
          class: "bg-grey-1 text-primary shadow-2"
        }, {
          default: withCtx(() => [
            createVNode(QTab, {
              name: "bookmarks",
              icon: "o_bookmark",
              color: "positive"
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    createTextVNode("Your bookmarks")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(QTab, {
              name: "openTabs",
              icon: "o_table_rows"
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    createTextVNode("Your open tabs")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(QTab, {
              name: "savedTabs",
              icon: "o_save"
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    createTextVNode("Your saved tabs")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        tab.value === "bookmarks" ? (openBlock(), createBlock(BookmarksTree, { key: 0 })) : tab.value === "openTabs" ? (openBlock(), createBlock(_sfc_main$5, { key: 1 })) : (openBlock(), createBlock(_sfc_main$4, { key: 2 }))
      ], 64);
    };
  }
});
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Export your Tabsets", -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "Please choose", -1);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "ExportDialog",
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    useTabsStore();
    const router = useRouter();
    const $q = useQuasar();
    const exportAs = ref("json");
    const hideWarning = ref(false);
    const warning = ref("");
    watchEffect(() => {
      if (exportAs.value === "bookmarks") {
        warning.value = "Warning! This will replace the bookmarks at '/tabsets'!";
      } else {
        warning.value = "";
      }
    });
    const exportData = () => {
      hideWarning.value = true;
      TabsetService.exportData(exportAs.value).then(() => {
        router.push("/tabset");
        $q.notify({
          message: "export successful",
          type: "positive"
        });
      }).catch((ex) => {
        console.error("ex", ex);
        hideWarning.value = false;
        $q.notify({
          message: "Sorry, there was a problem exporting your data",
          type: "warning"
        });
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1$2
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$2
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  createVNode(QRadio, {
                    modelValue: exportAs.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => exportAs.value = $event),
                    val: "json",
                    label: "as JSON"
                  }, null, 8, ["modelValue"]),
                  createVNode(QRadio, {
                    modelValue: exportAs.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => exportAs.value = $event),
                    val: "csv",
                    label: "as CSV (not implemented yet)"
                  }, null, 8, ["modelValue"]),
                  createVNode(QRadio, {
                    modelValue: exportAs.value,
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => exportAs.value = $event),
                    val: "bookmarks",
                    label: "to Bookmarks Folder"
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              }),
              warning.value !== "" ? (openBlock(), createBlock(QCardSection, {
                key: 0,
                class: "q-pt-none text-warning"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(warning.value), 1)
                ]),
                _: 1
              })) : createCommentVNode("", true),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    label: "Export",
                    onClick: _cache[3] || (_cache[3] = ($event) => exportData())
                  }, null, 512), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Import Tabsets", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "All your current tabsets will be deleted!", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("input", {
  id: "json2import",
  type: "file"
}, null, -1);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ImportDialog",
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    useTabsStore();
    useRouter();
    const importData = () => {
      var file = document.getElementById("json2import").files[0];
      var reader = new FileReader();
      reader.onload = function(e) {
        const json = e.target.result;
        TabsetService.importData(json);
      };
      reader.readAsText(file);
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_1$1
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_2$1
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  _hoisted_3
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    label: "Import",
                    onClick: _cache[0] || (_cache[0] = ($event) => importData())
                  }, null, 512), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
const _hoisted_1 = { class: "text-caption" };
const _hoisted_2 = {
  key: 2,
  class: "q-mr-lg"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MainLayout",
  setup(__props) {
    const router = useRouter();
    const tabsStore = useTabsStore();
    const searchStore = useSearchStore();
    const localStorage = useQuasar().localStorage;
    const rightDrawerOpen = ref(true);
    const leftDrawerOpen = ref(false);
    const notificationsStore = useNotificationsStore();
    useFeatureTogglesStore();
    const spacesStore = useSpacesStore();
    useRoute();
    const spacesOptions = ref([]);
    const search = ref("");
    const $q = useQuasar();
    $q.loadingBar.setDefaults({
      color: "positive",
      size: "10px",
      position: "top"
    });
    watchEffect(() => {
      spacesOptions.value = _.map([...spacesStore.spaces.keys()], (key) => {
        var _a;
        const label = ((_a = spacesStore.spaces.get(key)) == null ? void 0 : _a.label) || "undef";
        return { id: key, label };
      }).concat({ id: "", label: "(unassigned)" });
    });
    const appVersion = "0.2.3";
    const searchBox = ref(null);
    useMeta(() => {
      return {
        title: "Tabsets Extension"
      };
    });
    function checkKeystroke(e) {
      if (e.key === "/") {
        searchBox.value.focus();
        search.value = "";
      }
    }
    onMounted(() => {
      window.addEventListener("keypress", checkKeystroke);
    });
    onUnmounted(() => {
      window.removeEventListener("keypress", checkKeystroke);
    });
    function submitSearch() {
      console.log("s", search.value);
      searchStore.term = search.value;
      router.push("/search/" + search.value);
    }
    const goHome = () => router.push("/");
    const toggleLeftDrawer = () => {
      useNotificationsStore().showDrawer = !useNotificationsStore().showDrawer;
      localStorage.set("showLeftDrawer", useNotificationsStore().showDrawer);
    };
    onMounted(() => {
      leftDrawerOpen.value = localStorage.getItem("showLeftDrawer") || false;
      useNotificationsStore().showDrawer = leftDrawerOpen.value;
    });
    watchEffect(() => {
      leftDrawerOpen.value = useNotificationsStore().showDrawer;
    });
    const showNewTabsetDialog = ref(false);
    const addTabset = () => {
      $q.dialog({
        component: _sfc_main$b
      }).onDismiss(() => {
        showNewTabsetDialog.value = false;
      });
    };
    const closeTrackedTabs = () => {
      TabsetService.closeTrackedTabs();
    };
    const showExportDialog = () => {
      $q.dialog({ component: _sfc_main$2 });
    };
    const showImportDialog = () => {
      $q.dialog({ component: _sfc_main$1 });
    };
    const installNewVersion = () => {
      notificationsStore.updateAvailable(false);
      chrome.runtime.reload();
    };
    return (_ctx, _cache) => {
      const _component_router_view = resolveComponent("router-view");
      return openBlock(), createBlock(QLayout, { view: "hHh lpR lFr" }, {
        default: withCtx(() => [
          createVNode(QHeader, { elevated: "" }, {
            default: withCtx(() => [
              createVNode(QToolbar, null, {
                default: withCtx(() => {
                  var _a, _b;
                  return [
                    createVNode(QBtn, {
                      dense: "",
                      flat: "",
                      round: "",
                      icon: "menu",
                      onClick: toggleLeftDrawer
                    }),
                    createVNode(QToolbarTitle, {
                      onClick: _cache[0] || (_cache[0] = withModifiers(($event) => goHome(), ["stop"])),
                      class: "cursor-pointer",
                      shrink: ""
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Tabsets "),
                        withDirectives(createBaseVNode("span", _hoisted_1, "Handle more links, with less tabs open", 512), [
                          [vShow, unref(spacesStore).spaces.size === 0]
                        ])
                      ]),
                      _: 1
                    }),
                    unref(spacesStore).spaces.size > 0 ? (openBlock(), createBlock(QSelect, {
                      key: 0,
                      "bg-color": "white",
                      filled: "",
                      modelValue: unref(spacesStore).space,
                      "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(spacesStore).space = $event),
                      options: spacesOptions.value,
                      dense: "",
                      "options-dense": ""
                    }, {
                      selected: withCtx(() => [
                        createTextVNode(" Space: "),
                        unref(spacesStore).space ? (openBlock(), createBlock(QChip, {
                          key: 0,
                          dense: "",
                          square: "",
                          color: "white",
                          "text-color": "primary",
                          class: "q-my-none q-ml-xs q-mr-none"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(unref(spacesStore).space.label), 1)
                          ]),
                          _: 1
                        })) : (openBlock(), createBlock(QBadge, { key: 1 }, {
                          default: withCtx(() => [
                            createTextVNode("*none*")
                          ]),
                          _: 1
                        }))
                      ]),
                      _: 1
                    }, 8, ["modelValue", "options"])) : createCommentVNode("", true),
                    unref(tabsStore).tabsets.size > 0 ? (openBlock(), createBlock(QInput, {
                      key: 1,
                      dark: "",
                      dense: "",
                      standout: "",
                      modelValue: search.value,
                      "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => search.value = $event),
                      ref_key: "searchBox",
                      ref: searchBox,
                      style: { "width": "460px" },
                      onKeydown: _cache[4] || (_cache[4] = withKeys(withModifiers(($event) => submitSearch(), ["prevent"]), ["enter"])),
                      class: "q-ml-md"
                    }, {
                      prepend: withCtx(() => [
                        search.value === "" ? (openBlock(), createBlock(QIcon, {
                          key: 0,
                          name: "search"
                        })) : (openBlock(), createBlock(QIcon, {
                          key: 1,
                          name: "clear",
                          class: "cursor-pointer",
                          onClick: _cache[2] || (_cache[2] = ($event) => search.value = "")
                        }))
                      ]),
                      _: 1
                    }, 8, ["modelValue"])) : createCommentVNode("", true),
                    createVNode(QSpace),
                    ((_a = unref(tabsStore).pendingTabset) == null ? void 0 : _a.tabs.length) > 0 && unref(tabsStore).tabsets.size > 1 ? (openBlock(), createElementBlock("div", _hoisted_2, toDisplayString((_b = unref(tabsStore).pendingTabset) == null ? void 0 : _b.tabs.length) + " unassigned tab(s) ", 1)) : createCommentVNode("", true),
                    createVNode(QBtn, {
                      label: "Actions",
                      style: { "width": "200px" },
                      class: "q-mr-lg"
                    }, {
                      default: withCtx(() => [
                        createVNode(QMenu, { fit: "" }, {
                          default: withCtx(() => [
                            createVNode(QList, { style: { "min-width": "100px" } }, {
                              default: withCtx(() => [
                                createVNode(QItem, { clickable: "" }, {
                                  default: withCtx(() => [
                                    withDirectives((openBlock(), createBlock(QItemSection, {
                                      onClick: _cache[5] || (_cache[5] = ($event) => addTabset())
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Add Tabset")
                                      ]),
                                      _: 1
                                    })), [
                                      [ClosePopup]
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(QItem, { clickable: "" }, {
                                  default: withCtx(() => [
                                    withDirectives((openBlock(), createBlock(QItemSection, {
                                      onClick: _cache[6] || (_cache[6] = ($event) => closeTrackedTabs())
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Close all tracked tabs")
                                      ]),
                                      _: 1
                                    })), [
                                      [ClosePopup]
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(QSeparator),
                                createVNode(QItem, { clickable: "" }, {
                                  default: withCtx(() => [
                                    withDirectives((openBlock(), createBlock(QItemSection, {
                                      onClick: _cache[7] || (_cache[7] = ($event) => showExportDialog())
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Export")
                                      ]),
                                      _: 1
                                    })), [
                                      [ClosePopup]
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(QItem, { clickable: "" }, {
                                  default: withCtx(() => [
                                    withDirectives((openBlock(), createBlock(QItemSection, {
                                      onClick: _cache[8] || (_cache[8] = ($event) => showImportDialog())
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Import (Json)")
                                      ]),
                                      _: 1
                                    })), [
                                      [ClosePopup]
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(QSeparator),
                                createVNode(QItem, { clickable: "" }, {
                                  default: withCtx(() => [
                                    createVNode(QItemSection, {
                                      onClick: _cache[9] || (_cache[9] = ($event) => unref(router).push("/settings"))
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Settings")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }),
                                createVNode(QSeparator),
                                unref(useRouter)().currentRoute.value.fullPath !== "/about" ? (openBlock(), createBlock(QItem, {
                                  key: 0,
                                  clickable: "",
                                  onClick: _cache[10] || (_cache[10] = ($event) => unref(router).push("/about"))
                                }, {
                                  default: withCtx(() => [
                                    createVNode(QItemSection, null, {
                                      default: withCtx(() => [
                                        createTextVNode("About tabsets")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })) : createCommentVNode("", true)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    unref(notificationsStore).updateToVersion === "" ? (openBlock(), createElementBlock("div", {
                      key: 3,
                      class: "cursor-pointer",
                      onClick: _cache[11] || (_cache[11] = ($event) => unref(router).push("/about"))
                    }, " v" + toDisplayString(unref(appVersion)), 1)) : (openBlock(), createElementBlock("div", {
                      key: 4,
                      class: "cursor-pointer",
                      onClick: _cache[12] || (_cache[12] = ($event) => unref(router).push("/about"))
                    }, [
                      createVNode(QBtn, {
                        class: "text-primary bg-warning",
                        onClick: installNewVersion,
                        label: "New Version " + unref(notificationsStore).updateToVersion + " available. Click here to update"
                      }, null, 8, ["label"])
                    ]))
                  ];
                }),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(QDrawer, {
            modelValue: leftDrawerOpen.value,
            "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => leftDrawerOpen.value = $event),
            side: "left",
            bordered: ""
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3)
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(QDrawer, {
            "show-if-above": "",
            modelValue: rightDrawerOpen.value,
            "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => rightDrawerOpen.value = $event),
            side: "right",
            bordered: "",
            "content-class": "column justify-between no-wrap bg-grey-1"
          }, {
            default: withCtx(() => [
              createVNode(Navigation),
              createVNode(_sfc_main$a, { style: { "position": "absolute", "bottom": "0" } })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(QPageContainer, null, {
            default: withCtx(() => [
              createVNode(_component_router_view)
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
