import { I as defineComponent, J as useTabsStore, b0 as useSearchStore, r as ref, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, ay as unref, a8 as QDialog, L as useRouter, K as useQuasar, d as createVNode, aF as QCardSection, az as createElementBlock, aA as createTextVNode, aC as toDisplayString, aI as QCardActions, aJ as QBtn, ap as withDirectives, aK as QCard, M as createBaseVNode } from "./index.ac7851bc.js";
import { u as useDialogPluginComponent, C as ClosePopup } from "./use-dialog-plugin-component.220b0d2f.js";
const _hoisted_1 = {
  key: 0,
  class: "text-h6"
};
const _hoisted_2 = {
  key: 1,
  class: "text-h6"
};
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body" }, "If your search does not yield the results you'd expect, you can try re-indexing your tabsets. ", -1);
const _hoisted_4 = {
  key: 0,
  class: "text-body"
};
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("b", null, "a new browser window is opened and the tabs are analyzed one by one", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("span", { class: "text-negative" }, "Please do not use your computer otherwise in that time as it will break the results.", -1);
const _hoisted_9 = { key: 1 };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("b", null, "a new browser window is opened and the tabs are analyzed one by one", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("span", { class: "text-negative" }, "Please do not use your computer otherwise in that time as it will break the results.", -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ReindexDialog",
  props: {
    tabsetId: {
      type: String,
      default: ""
    }
  },
  emits: [
    ...useDialogPluginComponent.emits
  ],
  setup(__props) {
    const props = __props;
    const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();
    const tabsStore = useTabsStore();
    const searchStore = useSearchStore();
    useRouter();
    useQuasar();
    const newTabsetName = ref("");
    const newTabsetNameExists = ref(false);
    ref(false);
    ref(false);
    const duration = ref(1);
    watchEffect(() => {
      var _a;
      if (tabsStore) {
        if (props.tabsetId !== "") {
          duration.value = 1 + Math.floor((((_a = tabsStore.getTabset(props.tabsetId)) == null ? void 0 : _a.tabs.length) || 1) * 3 / 60);
        } else {
          duration.value = 1 + Math.floor(tabsStore.allTabsCount * 3 / 60);
        }
      }
    });
    watchEffect(() => {
      newTabsetNameExists.value = !!tabsStore.nameExistsInContextTabset(newTabsetName.value);
    });
    const startIndexing = () => {
      if (props.tabsetId !== "") {
        searchStore.reindexTabset(props.tabsetId);
      } else {
        searchStore.reindexAll();
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QDialog, {
        ref_key: "dialogRef",
        ref: dialogRef,
        onHide: unref(onDialogHide)
      }, {
        default: withCtx(() => [
          createVNode(QCard, { class: "q-dialog-plugin" }, {
            default: withCtx(() => [
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  props.tabsetId === "" ? (openBlock(), createElementBlock("div", _hoisted_1, "Index your Tabsets")) : (openBlock(), createElementBlock("div", _hoisted_2, "Index this Tabset"))
                ]),
                _: 1
              }),
              createVNode(QCardSection, null, {
                default: withCtx(() => [
                  _hoisted_3
                ]),
                _: 1
              }),
              createVNode(QCardSection, { class: "q-pt-none" }, {
                default: withCtx(() => [
                  props.tabsetId === "" ? (openBlock(), createElementBlock("div", _hoisted_4, [
                    createTextVNode(" Reindexing is the process of going through all your tabsets (and tabs), analyze the tabs' contents and create new thumbnail screenshots. For this, "),
                    _hoisted_5,
                    createTextVNode(". Given your current data, this will take about " + toDisplayString(duration.value) + " minute(s).", 1),
                    _hoisted_6,
                    _hoisted_7,
                    _hoisted_8
                  ])) : (openBlock(), createElementBlock("div", _hoisted_9, [
                    createTextVNode(" Reindexing is the process of going through all the tabs of this tabset, analyze the tabs' contents and create new thumbnail screenshots. For this, "),
                    _hoisted_10,
                    createTextVNode(". Given your current data, this will take about " + toDisplayString(duration.value) + " minute(s).", 1),
                    _hoisted_11,
                    _hoisted_12,
                    _hoisted_13
                  ]))
                ]),
                _: 1
              }),
              createVNode(QCardActions, {
                align: "right",
                class: "text-primary"
              }, {
                default: withCtx(() => [
                  createVNode(QBtn, {
                    flat: "",
                    label: "Cancel",
                    onClick: unref(onDialogCancel)
                  }, null, 8, ["onClick"]),
                  withDirectives(createVNode(QBtn, {
                    flat: "",
                    "data-testid": "reindexSubmit",
                    label: "Got it, start indexing",
                    onClick: _cache[0] || (_cache[0] = ($event) => startIndexing())
                  }, null, 512), [
                    [ClosePopup]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["onHide"]);
    };
  }
});
export { _sfc_main as _ };
