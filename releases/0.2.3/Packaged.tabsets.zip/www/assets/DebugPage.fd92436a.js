import { I as defineComponent, av as useFeatureTogglesStore, J as useTabsStore, r as ref, aw as watchEffect, j as openBlock, az as createElementBlock, aM as renderList, ay as unref, F as Fragment, L as useRouter, aA as createTextVNode, aC as toDisplayString, aP as _, M as createBaseVNode } from "./index.ac7851bc.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "DebugPage",
  setup(__props) {
    const router = useRouter();
    const featureToggles = useFeatureTogglesStore();
    const tabsStore = useTabsStore();
    if (!featureToggles.debugEnabled) {
      router.push("/");
    }
    const urls = ref([]);
    watchEffect(
      () => _.map([...tabsStore.tabsets.values()], (ts) => {
        _.forEach(ts.tabs, (tab) => {
          var _a;
          urls.value.push(((_a = tab == null ? void 0 : tab.chromeTab) == null ? void 0 : _a.url) || "unknown");
        });
      })
    );
    const encoded = (t) => btoa(t);
    return (_ctx, _cache) => {
      return openBlock(true), createElementBlock(Fragment, null, renderList(unref(_).filter(urls.value, (u) => u.length > 1e3), (t) => {
        return openBlock(), createElementBlock("div", null, [
          createTextVNode(toDisplayString(t.length) + ": " + toDisplayString(t), 1),
          _hoisted_1,
          _hoisted_2,
          createTextVNode(" " + toDisplayString(encoded(t)), 1),
          _hoisted_3,
          _hoisted_4
        ]);
      }), 256);
    };
  }
});
export { _sfc_main as default };
