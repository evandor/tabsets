import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { Q as QImg } from "./QImg.0869baf7.js";
import { I as defineComponent, J as useTabsStore, au as useNotificationsStore, av as useFeatureTogglesStore, r as ref, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, L as useRouter, M as createBaseVNode, d as createVNode, aA as createTextVNode, aC as toDisplayString, ay as unref, aD as withModifiers, a1 as QIcon, az as createElementBlock, aB as createCommentVNode, aM as renderList, F as Fragment, ax as TabsetService, aE as Navigation } from "./index.ac7851bc.js";
import { Q as QPage } from "./QPage.d2025984.js";
import { _ as _sfc_main$1 } from "./Fab.577affc8.js";
import { d as date } from "./date.afb255f8.js";
import "./use-dialog-plugin-component.220b0d2f.js";
import "./NewTabsetDialog.35dde97f.js";
import "./ReindexDialog.ccfa929c.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ml-md" }, " Tab Details ", -1);
const _hoisted_2 = { class: "row items-baseline q-mx-md q-my-none" };
const _hoisted_3 = { class: "col-2" };
const _hoisted_4 = { class: "col-10 text-body1 ellipsis" };
const _hoisted_5 = { class: "col-12 text-body2 ellipsis" };
const _hoisted_6 = { class: "col-12" };
const _hoisted_7 = { class: "text-overline ellipsis" };
const _hoisted_8 = {
  class: "row q-mx-md q-my-none",
  style: { "border": "0 solid yellow" }
};
const _hoisted_9 = { class: "col-12" };
const _hoisted_10 = { class: "col-12" };
const _hoisted_11 = { class: "row q-ma-sm" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " created ", -1);
const _hoisted_13 = { class: "col-7" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " updated ", -1);
const _hoisted_15 = { class: "col-7" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " last Active ", -1);
const _hoisted_17 = { class: "col-7" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " activated# ", -1);
const _hoisted_19 = { class: "col-7" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " Description ", -1);
const _hoisted_21 = { class: "col-7" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " History ", -1);
const _hoisted_23 = { class: "col-7" };
const _hoisted_24 = {
  key: 0,
  class: "col-5"
};
const _hoisted_25 = {
  key: 1,
  class: "col-7"
};
const _hoisted_26 = {
  key: 2,
  class: "col-5"
};
const _hoisted_27 = {
  key: 3,
  class: "col-7"
};
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " Meta Info ", -1);
const _hoisted_29 = { class: "col-7" };
const _hoisted_30 = { class: "row" };
const _hoisted_31 = { class: "col-6" };
const _hoisted_32 = { class: "col-6" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("div", { class: "col-5" }, " Content ", -1);
const _hoisted_34 = { class: "col-7" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TabPage",
  setup(__props) {
    useTabsStore();
    const notificationStore = useNotificationsStore();
    useFeatureTogglesStore();
    const router = useRouter();
    const thumbnail = ref("");
    const content = ref("");
    const metas = ref({});
    watchEffect(() => {
      if (notificationStore.selectedTab) {
        TabsetService.getThumbnailFor(notificationStore.selectedTab).then((data) => thumbnail.value = data.thumbnail).catch((err) => console.log("err", err));
        TabsetService.getContentFor(notificationStore.selectedTab).then((data) => {
          content.value = data.content;
          metas.value = data.metas;
        }).catch((err) => console.log("err", err));
      } else {
        router.push("/tabset");
      }
    });
    function getShortHostname(host) {
      const nrOfDots = (host.match(/\./g) || []).length;
      if (nrOfDots >= 2) {
        return host.substring(host.indexOf(".", nrOfDots - 2) + 1);
      }
      return host;
    }
    function getHost(urlAsString, shorten = true) {
      try {
        const url = new URL(urlAsString);
        if (!shorten) {
          return url.protocol + "://" + url.host.toString();
        }
        return getShortHostname(url.host);
      } catch (e) {
        return "---";
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t;
          return [
            _hoisted_1,
            createBaseVNode("div", _hoisted_2, [
              createBaseVNode("div", _hoisted_3, [
                createVNode(QImg, {
                  class: "rounded-borders",
                  width: "32px",
                  height: "32px",
                  src: (_b = (_a = unref(notificationStore).selectedTab) == null ? void 0 : _a.chromeTab) == null ? void 0 : _b.favIconUrl
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => {
                        var _a2, _b2, _c2, _d2;
                        return [
                          createTextVNode(toDisplayString((_b2 = (_a2 = unref(notificationStore).selectedTab) == null ? void 0 : _a2.chromeTab) == null ? void 0 : _b2.favIconUrl) + " / " + toDisplayString((_d2 = (_c2 = unref(notificationStore).selectedTab) == null ? void 0 : _c2.chromeTab) == null ? void 0 : _d2.id) + " / " + toDisplayString(unref(notificationStore).selectedTab.id), 1)
                        ];
                      }),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["src"])
              ]),
              createBaseVNode("div", _hoisted_4, toDisplayString(getHost((_d = (_c = unref(notificationStore).selectedTab) == null ? void 0 : _c.chromeTab) == null ? void 0 : _d.url, true)), 1),
              createBaseVNode("div", _hoisted_5, toDisplayString((_f = (_e = unref(notificationStore).selectedTab) == null ? void 0 : _e.chromeTab) == null ? void 0 : _f.title), 1),
              createBaseVNode("div", _hoisted_6, [
                createBaseVNode("div", _hoisted_7, [
                  createTextVNode(toDisplayString((_h = (_g = unref(notificationStore).selectedTab) == null ? void 0 : _g.chromeTab) == null ? void 0 : _h.url) + "\xA0", 1),
                  createVNode(QIcon, {
                    name: "launch",
                    color: "secondary",
                    onClick: _cache[0] || (_cache[0] = withModifiers(($event) => {
                      var _a2;
                      return unref(Navigation).openOrCreateTab((_a2 = _ctx.tab.chromeTab) == null ? void 0 : _a2.url);
                    }, ["stop"]))
                  })
                ])
              ])
            ]),
            createBaseVNode("div", _hoisted_8, [
              createBaseVNode("div", _hoisted_9, [
                createVNode(QImg, {
                  src: thumbnail.value,
                  width: "512px",
                  style: { "border": "1px solid grey" }
                }, null, 8, ["src"])
              ]),
              createBaseVNode("div", _hoisted_10, [
                createBaseVNode("div", _hoisted_11, [
                  _hoisted_12,
                  createBaseVNode("div", _hoisted_13, toDisplayString(unref(date).formatDate((_i = unref(notificationStore).selectedTab) == null ? void 0 : _i.created, "DD.MM.YYYY HH:mm")), 1),
                  _hoisted_14,
                  createBaseVNode("div", _hoisted_15, toDisplayString(unref(date).formatDate((_j = unref(notificationStore).selectedTab) == null ? void 0 : _j.updated, "DD.MM.YYYY HH:mm")), 1),
                  _hoisted_16,
                  createBaseVNode("div", _hoisted_17, toDisplayString(unref(date).formatDate((_k = unref(notificationStore).selectedTab) == null ? void 0 : _k.lastActive, "DD.MM.YYYY HH:mm")), 1),
                  _hoisted_18,
                  createBaseVNode("div", _hoisted_19, toDisplayString((_l = unref(notificationStore).selectedTab) == null ? void 0 : _l.activatedCount), 1),
                  _hoisted_20,
                  createBaseVNode("div", _hoisted_21, toDisplayString((_m = unref(notificationStore).selectedTab) == null ? void 0 : _m.description), 1),
                  _hoisted_22,
                  createBaseVNode("div", _hoisted_23, toDisplayString((_n = unref(notificationStore).selectedTab) == null ? void 0 : _n.history), 1),
                  ((_o = unref(notificationStore).selectedTab) == null ? void 0 : _o.bookmarkId) ? (openBlock(), createElementBlock("div", _hoisted_24, " Bookmark ID ")) : createCommentVNode("", true),
                  ((_p = unref(notificationStore).selectedTab) == null ? void 0 : _p.bookmarkId) ? (openBlock(), createElementBlock("div", _hoisted_25, toDisplayString((_q = unref(notificationStore).selectedTab) == null ? void 0 : _q.bookmarkId), 1)) : createCommentVNode("", true),
                  ((_r = unref(notificationStore).selectedTab) == null ? void 0 : _r.bookmarkUrl) ? (openBlock(), createElementBlock("div", _hoisted_26, " Bookmark URL ")) : createCommentVNode("", true),
                  ((_s = unref(notificationStore).selectedTab) == null ? void 0 : _s.bookmarkUrl) ? (openBlock(), createElementBlock("div", _hoisted_27, toDisplayString((_t = unref(notificationStore).selectedTab) == null ? void 0 : _t.bookmarkUrl), 1)) : createCommentVNode("", true),
                  _hoisted_28,
                  createBaseVNode("div", _hoisted_29, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(Object.keys(metas.value), (key) => {
                      return openBlock(), createElementBlock("div", _hoisted_30, [
                        createBaseVNode("div", _hoisted_31, toDisplayString(key), 1),
                        createBaseVNode("div", _hoisted_32, toDisplayString(metas.value[key]), 1)
                      ]);
                    }), 256))
                  ]),
                  _hoisted_33,
                  createBaseVNode("div", _hoisted_34, toDisplayString(content.value), 1)
                ])
              ])
            ]),
            createVNode(_sfc_main$1)
          ];
        }),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
