import { I as defineComponent, aL as useSpacesStore, J as useTabsStore, r as ref, aw as watchEffect, j as openBlock, k as createBlock, l as withCtx, L as useRouter, M as createBaseVNode, az as createElementBlock, aM as renderList, aC as toDisplayString, ay as unref, F as Fragment, d as createVNode, aU as QCheckbox, aJ as QBtn, aP as _, ax as TabsetService } from "./index.ac7851bc.js";
import { Q as QPage } from "./QPage.d2025984.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Spaces Settings ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "row" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col-1" }),
  /* @__PURE__ */ createBaseVNode("div", { class: "col" }, [
    /* @__PURE__ */ createBaseVNode("b", null, "Spaces")
  ])
], -1);
const _hoisted_3 = { class: "row" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "col" }, [
  /* @__PURE__ */ createBaseVNode("b", null, "Tabset")
], -1);
const _hoisted_5 = { class: "col" };
const _hoisted_6 = { class: "row" };
const _hoisted_7 = { class: "col" };
const _hoisted_8 = { class: "col" };
const _hoisted_9 = { class: "row" };
const _hoisted_10 = { class: "col" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Spaces",
  setup(__props) {
    const spacesStore = useSpacesStore();
    const tabsStore = useTabsStore();
    const checked = ref([[]]);
    const router = useRouter();
    watchEffect(() => {
      const spaceArray = [];
      _.forEach([...spacesStore.spaces.values()], (space) => {
        const tsArray = [];
        _.forEach([...tabsStore.tabsets.values()], (ts) => {
          console.log("checking", space.id, ts.id);
          tsArray.push(ts.spaces.indexOf(space.id) >= 0);
        });
        spaceArray.push(tsArray);
      });
      console.log("spaceArray", spaceArray);
      checked.value = spaceArray;
    });
    const updateSpaces = () => {
      console.log("updated", checked.value);
      _.forEach([...tabsStore.tabsets.values()], (ts, tabsetIndex) => {
        const spaces = [];
        _.forEach([...spacesStore.spaces.values()], (space, spaceIndex) => {
          console.log("checking", space.id, ts.id);
          if (checked.value[spaceIndex][tabsetIndex]) {
            spaces.push(space.id);
          }
        });
        console.log("result", ts.id, spaces);
        ts.spaces = spaces;
        TabsetService.saveTabset(ts);
        router.push("/tabset");
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          _hoisted_1,
          _hoisted_2,
          createBaseVNode("div", _hoisted_3, [
            _hoisted_4,
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(spacesStore).spaces.values(), (space) => {
              return openBlock(), createElementBlock("div", _hoisted_5, toDisplayString(space.label), 1);
            }), 256))
          ]),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabsStore).tabsets.values(), (ts, tsIndex) => {
            return openBlock(), createElementBlock("div", _hoisted_6, [
              createBaseVNode("div", _hoisted_7, toDisplayString(ts.name), 1),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(spacesStore).spaces.values(), (space, spaceIndex) => {
                return openBlock(), createElementBlock("div", _hoisted_8, [
                  createVNode(QCheckbox, {
                    modelValue: checked.value[spaceIndex][tsIndex],
                    "onUpdate:modelValue": ($event) => checked.value[spaceIndex][tsIndex] = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]);
              }), 256))
            ]);
          }), 256)),
          createBaseVNode("div", _hoisted_9, [
            createBaseVNode("div", _hoisted_10, [
              createVNode(QBtn, {
                flat: "",
                class: "bg-positive",
                "data-testid": "spaceEditedSubmit",
                label: "Update Spaces",
                onClick: _cache[0] || (_cache[0] = ($event) => updateSpaces())
              })
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
