var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { a as QToolbarTitle, Q as QToolbar } from "./QToolbar.8ddc4c0b.js";
import { Q as QItemSection, a as QItemLabel, b as QItem, c as QList } from "./QList.06a62e31.js";
import { Q as QPage } from "./QPage.d2025984.js";
import { I as defineComponent, L as useRouter, av as useFeatureTogglesStore, r as ref, ap as withDirectives, aO as Ripple, j as openBlock, k as createBlock, l as withCtx, d as createVNode, aA as createTextVNode, aC as toDisplayString, az as createElementBlock, F as Fragment, aM as renderList, ay as unref, aB as createCommentVNode, a1 as QIcon, aD as withModifiers, aE as Navigation, aP as _, ax as TabsetService, J as useTabsStore, b0 as useSearchStore, aw as watchEffect, b1 as useRoute, K as useQuasar, M as createBaseVNode, aR as uid, bv as ChromeApi } from "./index.ac7851bc.js";
import { Q as QTooltip } from "./QTooltip.60dd45e2.js";
import { Q as QImg } from "./QImg.0869baf7.js";
import { Q as QChip } from "./QChip.0a3a1859.js";
import { _ as _sfc_main$2 } from "./ReindexDialog.ccfa929c.js";
import "./use-dialog-plugin-component.220b0d2f.js";
class Hit {
  constructor(id, chromeTab, created, updated, score, tabsets, matches, description) {
    __publicField(this, "lastActive");
    __publicField(this, "activatedCount");
    __publicField(this, "lastLoaded");
    __publicField(this, "loadedCount");
    __publicField(this, "history", []);
    __publicField(this, "selected", false);
    __publicField(this, "name");
    __publicField(this, "bookmarkUrl");
    __publicField(this, "bookmarkId");
    this.id = id;
    this.chromeTab = chromeTab;
    this.created = created;
    this.updated = updated;
    this.score = score;
    this.tabsets = tabsets;
    this.matches = matches;
    this.description = description;
    this.updated = new Date().getTime();
    this.lastActive = 0;
    this.activatedCount = 0;
    this.lastLoaded = 0;
    this.loadedCount = 0;
    this.name = void 0;
  }
}
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "SearchHit",
  props: {
    hit: {
      type: Hit,
      required: true
    }
  },
  emits: ["sendCaption"],
  setup(__props, { emit: emits }) {
    const router = useRouter();
    const featureToggles = useFeatureTogglesStore();
    ref(null);
    const tabsetBadges = (hit) => {
      const badges = [];
      _.forEach(hit.tabsets, (ts) => badges.push({
        label: TabsetService.nameForTabsetId(ts),
        tabsetId: ts,
        encodedUrl: btoa(hit.chromeTab.url || "")
      }));
      return badges;
    };
    const openTabset = (badge) => {
      console.log("badge", badge);
      TabsetService.selectTabset(badge.tabsetId);
      router.push("/tabset?highlight=" + badge.encodedUrl);
    };
    return (_ctx, _cache) => {
      return withDirectives((openBlock(), createBlock(QItem, { autofocus: "" }, {
        default: withCtx(() => [
          createVNode(QItemSection, { avatar: "" }, {
            default: withCtx(() => {
              var _a;
              return [
                createVNode(QImg, {
                  class: "rounded-borders",
                  width: "20px",
                  height: "20px",
                  src: (_a = __props.hit.chromeTab) == null ? void 0 : _a.favIconUrl
                }, {
                  default: withCtx(() => [
                    createVNode(QTooltip, null, {
                      default: withCtx(() => {
                        var _a2;
                        return [
                          createTextVNode(toDisplayString((_a2 = __props.hit.chromeTab) == null ? void 0 : _a2.id) + " / " + toDisplayString(__props.hit.id), 1)
                        ];
                      }),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["src"])
              ];
            }),
            _: 1
          }),
          createVNode(QItemSection, { avatar: "" }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(__props.hit.score) + "% ", 1)
            ]),
            _: 1
          }),
          createVNode(QItemSection, null, {
            default: withCtx(() => [
              createVNode(QItemLabel, { class: "ellipsis" }, {
                default: withCtx(() => {
                  var _a;
                  return [
                    createTextVNode(toDisplayString((_a = __props.hit.chromeTab) == null ? void 0 : _a.title) + " ", 1),
                    (openBlock(true), createElementBlock(Fragment, null, renderList(tabsetBadges(__props.hit), (badge) => {
                      return openBlock(), createBlock(QChip, {
                        class: "cursor-pointer",
                        clickable: "",
                        icon: "tab",
                        onClick: ($event) => openTabset(badge)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(badge.label), 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 256))
                  ];
                }),
                _: 1
              }),
              createVNode(QItemLabel, {
                class: "ellipsis",
                caption: ""
              }, {
                default: withCtx(() => {
                  var _a;
                  return [
                    createTextVNode(toDisplayString((_a = __props.hit.chromeTab) == null ? void 0 : _a.url), 1)
                  ];
                }),
                _: 1
              }),
              createVNode(QItemLabel, {
                class: "ellipsis",
                caption: ""
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(__props.hit.description), 1)
                ]),
                _: 1
              }),
              unref(featureToggles).debugEnabled ? (openBlock(), createBlock(QItemLabel, {
                key: 0,
                class: "text-blue-2"
              }, {
                default: withCtx(() => [
                  createTextVNode("Match in: " + toDisplayString(__props.hit["matches"].join(", ")), 1)
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ]),
            _: 1
          }),
          createVNode(QItemSection, { avatar: "" }, {
            default: withCtx(() => [
              createVNode(QIcon, {
                name: "launch",
                color: "primary",
                onClick: _cache[0] || (_cache[0] = withModifiers(($event) => {
                  var _a;
                  return unref(Navigation).openOrCreateTab((_a = __props.hit.chromeTab) == null ? void 0 : _a.url);
                }, ["stop"]))
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })), [
        [Ripple]
      ]);
    };
  }
});
const _hoisted_1 = { class: "row fit" };
const _hoisted_2 = { class: "col-xs-12 col-md-5" };
const _hoisted_3 = { class: "row justify-start items-baseline" };
const _hoisted_4 = { class: "col-1" };
const _hoisted_5 = { class: "text-dark" };
const _hoisted_6 = { class: "text-caption q-mb-md" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("u", null, "re-indexing", -1);
const _hoisted_8 = [
  _hoisted_7
];
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("div", { class: "col-xs-12 col-md-7 text-right" }, null, -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SearchPage",
  setup(__props) {
    const route = useRoute();
    useTabsStore();
    const searchStore = useSearchStore();
    const term = route.params.term;
    const $q = useQuasar();
    const tabsetHits = ref([]);
    const showReindexDialog = ref(false);
    const newSearch = (term2) => {
      tabsetHits.value = [];
      console.log("searching in ", searchStore.fuse.getIndex());
      const results = searchStore.fuse.search(term2);
      console.log("search results", results);
      _.forEach(results, (h) => {
        tabsetHits.value.push(new Hit(
          uid(),
          ChromeApi.createChromeTabObject(h.item.title, h.item.url, h.item.favIconUrl),
          0,
          0,
          Math.round(100 - 100 * h.score),
          h.item.tabsets,
          _.map(h["matches"], (m) => m["key"]),
          h.item.description
        ));
      });
    };
    console.log("term", term);
    if (term && term.trim() !== "") {
      searchStore.term = term;
    }
    watchEffect(() => {
      var _a;
      console.log("searchStore.term", searchStore.term);
      if (((_a = searchStore.term) == null ? void 0 : _a.trim()) !== "") {
        newSearch(searchStore.term);
      }
    });
    watchEffect(() => {
      if (showReindexDialog.value) {
        $q.dialog({
          component: _sfc_main$2
        }).onDismiss(() => {
          showReindexDialog.value = false;
        });
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { class: "q-ma-lg" }, {
        default: withCtx(() => [
          createVNode(QToolbar, { class: "text-primary" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createBaseVNode("div", _hoisted_2, [
                  createVNode(QToolbarTitle, null, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_3, [
                        createBaseVNode("div", _hoisted_4, [
                          createBaseVNode("span", _hoisted_5, "Search Results for '" + toDisplayString(unref(searchStore).term) + "': " + toDisplayString(tabsetHits.value.length) + " hit(s)", 1)
                        ]),
                        createBaseVNode("div", _hoisted_6, [
                          createTextVNode("Not happy with the search results? Try "),
                          createBaseVNode("span", {
                            class: "text-blue-9 cursor-pointer",
                            onClick: _cache[0] || (_cache[0] = ($event) => showReindexDialog.value = true)
                          }, _hoisted_8),
                          createTextVNode(". ")
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _hoisted_9
              ])
            ]),
            _: 1
          }),
          (openBlock(true), createElementBlock(Fragment, null, renderList(tabsetHits.value, (hit) => {
            return openBlock(), createBlock(QList, {
              bordered: "",
              separator: ""
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$1, { hit }, null, 8, ["hit"])
              ]),
              _: 2
            }, 1024);
          }), 256))
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
