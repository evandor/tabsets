import { Q as QPage } from "./QPage.d2025984.js";
import { I as defineComponent, J as useTabsStore, j as openBlock, k as createBlock, l as withCtx, L as useRouter, M as createBaseVNode, aA as createTextVNode, ay as unref, d as createVNode } from "./index.ac7851bc.js";
import { _ as _sfc_main$1 } from "./Fab.577affc8.js";
import "./QTooltip.60dd45e2.js";
import "./use-dialog-plugin-component.220b0d2f.js";
import "./NewTabsetDialog.35dde97f.js";
import "./ReindexDialog.ccfa929c.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Tabsets vs Tabsets Pro ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "Tabsets"),
  /* @__PURE__ */ createTextVNode(" is a browser extension which helps you organize your tabs."),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" Your data is stored locally in the browser you are using and you cannot access it from anywhere else. ")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "Tabsets Pro"),
  /* @__PURE__ */ createTextVNode(" offers the same features as "),
  /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "Tabsets"),
  /* @__PURE__ */ createTextVNode(", and adds: "),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, "Cloud Storage"),
    /* @__PURE__ */ createBaseVNode("li", null, "Tabsets Sharing (Planned)"),
    /* @__PURE__ */ createBaseVNode("li", null, "Bookmarks Integration (Planned)"),
    /* @__PURE__ */ createBaseVNode("li", null, "Advanced Search (Planned)")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, " Cloud Storage ", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body1 q-ma-md" }, " Your data - that is your tabsets - is stored in the cloud. So it is possible, once you login, to access your information from any chrome browser from anywhere. ", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 q-ma-md" }, [
  /* @__PURE__ */ createTextVNode(" Get started with "),
  /* @__PURE__ */ createBaseVNode("span", { class: "text-dark" }, "Tabsets Pro")
], -1);
const _hoisted_7 = { class: "text-body1 q-ma-md" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("u", null, "here", -1);
const _hoisted_9 = [
  _hoisted_8
];
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("span", { class: "text-body1 text-dark" }, "Tabsets Free", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TryPro",
  setup(__props) {
    useTabsStore();
    const router = useRouter();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          _hoisted_1,
          _hoisted_2,
          _hoisted_3,
          _hoisted_4,
          _hoisted_5,
          createBaseVNode("div", null, [
            _hoisted_6,
            createBaseVNode("div", _hoisted_7, [
              createTextVNode(" Click "),
              createBaseVNode("span", {
                class: "cursor-pointer text-blue",
                onClick: _cache[0] || (_cache[0] = ($event) => unref(router).push("/register"))
              }, _hoisted_9),
              createTextVNode(" to create a new account."),
              _hoisted_10,
              _hoisted_11,
              createTextVNode(" You can test it for free for 14 days and then decide if you want to keep it or get back to "),
              _hoisted_12,
              createTextVNode(". "),
              _hoisted_13,
              _hoisted_14,
              createTextVNode(" If you want to keep it, the cost is at 0,99 \u20AC per Month. ")
            ])
          ]),
          createVNode(_sfc_main$1)
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
