import { Q as QPage, N as Navigation } from "./Navigation.230fb221.js";
import { a5 as defineComponent, a6 as useTabsStore, r as ref, ax as _, a9 as openBlock, aa as createBlock, ab as withCtx, aN as useRoute, ai as createBaseVNode, ak as toDisplayString, aj as unref, al as createElementBlock, an as renderList, F as Fragment } from "./index.a33268e4.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "row" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col" }, [
    /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Tabset Extension")
  ])
], -1);
const _hoisted_2 = { class: "row" };
const _hoisted_3 = { class: "col" };
const _hoisted_4 = { class: "text-body1" };
const _hoisted_5 = { class: "row" };
const _hoisted_6 = ["onClick"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SearchPage",
  setup(__props) {
    const route = useRoute();
    const tabStore = useTabsStore();
    const term = route.params.term;
    console.log("term", term);
    const result = ref(/* @__PURE__ */ new Map());
    for (let [key, value] of tabStore.tabsets) {
      const hits = _.filter(value.tabs, (t) => {
        if (t.url) {
          return t.url.indexOf(term) >= 0;
        }
        return false;
      });
      _.forEach(hits, (h) => {
        if (result.value.has(h.url || ""))
          ;
        else {
          result.value.set(h.url || "???", { tabsetName: value.name });
        }
      });
    }
    function openTab(url) {
      console.log("opening", url);
      Navigation.openOrCreateTab(url);
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { class: "q-ma-lg" }, {
        default: withCtx(() => [
          _hoisted_1,
          createBaseVNode("div", _hoisted_2, [
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("div", _hoisted_4, " Search Results for term '" + toDisplayString(unref(term)) + "' ", 1)
            ])
          ]),
          (openBlock(true), createElementBlock(Fragment, null, renderList(result.value.keys(), (key) => {
            return openBlock(), createElementBlock("div", _hoisted_5, [
              createBaseVNode("div", {
                class: "col cursor-pointer",
                onClick: ($event) => openTab(key)
              }, toDisplayString(key), 9, _hoisted_6)
            ]);
          }), 256))
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
