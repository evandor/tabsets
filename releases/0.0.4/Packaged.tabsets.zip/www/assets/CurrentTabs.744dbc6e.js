import { N as Navigation, Q as QPage } from "./Navigation.230fb221.js";
import { j as createComponent, c as computed, h, P as hSlot, G as useDarkProps, aG as useRouterLinkProps, I as useDark, aH as useRouterLink, r as ref, g as getCurrentInstance, a0 as isKeyCode, D as stopAndPrevent, q as hUniqueSlot, l as onBeforeUnmount, aF as Transition, aI as shallowReactive, E as useModelToggleProps, H as useModelToggleEmits, K as useModelToggle, w as watch, aJ as uid, aK as QSeparator, N as withDirectives, aL as vShow, ah as QIcon, aM as QSpinner, a5 as defineComponent, a9 as openBlock, al as createElementBlock, F as Fragment, an as renderList, d as createVNode, ab as withCtx, ap as QCardSection, ai as createBaseVNode, at as createTextVNode, ak as toDisplayString, aa as createBlock, am as createCommentVNode, aj as unref, ay as TabStatus, aw as normalizeStyle, ao as QCard, au as TabsetService, aN as useRoute, ac as useRouter, a8 as useQuasar, a6 as useTabsStore, a7 as useTabGroupsStore, ae as QBtn, ax as _, aO as watchEffect } from "./index.a33268e4.js";
import { b as QTooltip, a as QToolbarTitle, Q as QToolbar } from "./QToolbar.ad6b88a0.js";
var QItemSection = createComponent({
  name: "QItemSection",
  props: {
    avatar: Boolean,
    thumbnail: Boolean,
    side: Boolean,
    top: Boolean,
    noWrap: Boolean
  },
  setup(props, { slots }) {
    const classes = computed(
      () => `q-item__section column q-item__section--${props.avatar === true || props.side === true || props.thumbnail === true ? "side" : "main"}` + (props.top === true ? " q-item__section--top justify-start" : " justify-center") + (props.avatar === true ? " q-item__section--avatar" : "") + (props.thumbnail === true ? " q-item__section--thumbnail" : "") + (props.noWrap === true ? " q-item__section--nowrap" : "")
    );
    return () => h("div", { class: classes.value }, hSlot(slots.default));
  }
});
var QItem = createComponent({
  name: "QItem",
  props: {
    ...useDarkProps,
    ...useRouterLinkProps,
    tag: {
      type: String,
      default: "div"
    },
    active: {
      type: Boolean,
      default: null
    },
    clickable: Boolean,
    dense: Boolean,
    insetLevel: Number,
    tabindex: [String, Number],
    focused: Boolean,
    manualFocus: Boolean
  },
  emits: ["click", "keyup"],
  setup(props, { slots, emit }) {
    const { proxy: { $q } } = getCurrentInstance();
    const isDark = useDark(props, $q);
    const { hasRouterLink, hasLink, linkProps, linkClass, linkTag, navigateToRouterLink } = useRouterLink();
    const rootRef = ref(null);
    const blurTargetRef = ref(null);
    const isActionable = computed(
      () => props.clickable === true || hasLink.value === true || props.tag === "label"
    );
    const isClickable = computed(
      () => props.disable !== true && isActionable.value === true
    );
    const classes = computed(
      () => "q-item q-item-type row no-wrap" + (props.dense === true ? " q-item--dense" : "") + (isDark.value === true ? " q-item--dark" : "") + (hasLink.value === true && props.active === null ? linkClass.value : props.active === true ? `${props.activeClass !== void 0 ? ` ${props.activeClass}` : ""} q-item--active` : "") + (props.disable === true ? " disabled" : "") + (isClickable.value === true ? " q-item--clickable q-link cursor-pointer " + (props.manualFocus === true ? "q-manual-focusable" : "q-focusable q-hoverable") + (props.focused === true ? " q-manual-focusable--focused" : "") : "")
    );
    const style = computed(() => {
      if (props.insetLevel === void 0) {
        return null;
      }
      const dir = $q.lang.rtl === true ? "Right" : "Left";
      return {
        ["padding" + dir]: 16 + props.insetLevel * 56 + "px"
      };
    });
    function onClick(e) {
      if (isClickable.value === true) {
        if (blurTargetRef.value !== null) {
          if (e.qKeyEvent !== true && document.activeElement === rootRef.value) {
            blurTargetRef.value.focus();
          } else if (document.activeElement === blurTargetRef.value) {
            rootRef.value.focus();
          }
        }
        hasRouterLink.value === true && navigateToRouterLink(e);
        emit("click", e);
      }
    }
    function onKeyup(e) {
      if (isClickable.value === true && isKeyCode(e, 13) === true) {
        stopAndPrevent(e);
        e.qKeyEvent = true;
        const evt = new MouseEvent("click", e);
        evt.qKeyEvent = true;
        rootRef.value.dispatchEvent(evt);
      }
      emit("keyup", e);
    }
    function getContent() {
      const child = hUniqueSlot(slots.default, []);
      isClickable.value === true && child.unshift(
        h("div", { class: "q-focus-helper", tabindex: -1, ref: blurTargetRef })
      );
      return child;
    }
    return () => {
      const data = {
        ref: rootRef,
        class: classes.value,
        style: style.value,
        onClick,
        onKeyup
      };
      if (isClickable.value === true) {
        data.tabindex = props.tabindex || "0";
        Object.assign(data, linkProps.value);
      } else if (isActionable.value === true) {
        data["aria-disabled"] = "true";
      }
      return h(
        linkTag.value,
        data,
        getContent()
      );
    };
  }
});
var QItemLabel = createComponent({
  name: "QItemLabel",
  props: {
    overline: Boolean,
    caption: Boolean,
    header: Boolean,
    lines: [Number, String]
  },
  setup(props, { slots }) {
    const parsedLines = computed(() => parseInt(props.lines, 10));
    const classes = computed(
      () => "q-item__label" + (props.overline === true ? " q-item__label--overline text-overline" : "") + (props.caption === true ? " q-item__label--caption text-caption" : "") + (props.header === true ? " q-item__label--header" : "") + (parsedLines.value === 1 ? " ellipsis" : "")
    );
    const style = computed(() => {
      return props.lines !== void 0 && parsedLines.value > 1 ? {
        overflow: "hidden",
        display: "-webkit-box",
        "-webkit-box-orient": "vertical",
        "-webkit-line-clamp": parsedLines.value
      } : null;
    });
    return () => h("div", {
      style: style.value,
      class: classes.value
    }, hSlot(slots.default));
  }
});
var QSlideTransition = createComponent({
  name: "QSlideTransition",
  props: {
    appear: Boolean,
    duration: {
      type: Number,
      default: 300
    }
  },
  emits: ["show", "hide"],
  setup(props, { slots, emit }) {
    let animating = false, doneFn, element;
    let timer, timerFallback, animListener, lastEvent;
    function cleanup() {
      doneFn && doneFn();
      doneFn = null;
      animating = false;
      clearTimeout(timer);
      clearTimeout(timerFallback);
      element !== void 0 && element.removeEventListener("transitionend", animListener);
      animListener = null;
    }
    function begin(el, height, done) {
      el.style.overflowY = "hidden";
      if (height !== void 0) {
        el.style.height = `${height}px`;
      }
      el.style.transition = `height ${props.duration}ms cubic-bezier(.25, .8, .50, 1)`;
      animating = true;
      doneFn = done;
    }
    function end(el, event) {
      el.style.overflowY = null;
      el.style.height = null;
      el.style.transition = null;
      cleanup();
      event !== lastEvent && emit(event);
    }
    function onEnter(el, done) {
      let pos = 0;
      element = el;
      if (animating === true) {
        cleanup();
        pos = el.offsetHeight === el.scrollHeight ? 0 : void 0;
      } else {
        lastEvent = "hide";
      }
      begin(el, pos, done);
      timer = setTimeout(() => {
        el.style.height = `${el.scrollHeight}px`;
        animListener = (evt) => {
          if (Object(evt) !== evt || evt.target === el) {
            end(el, "show");
          }
        };
        el.addEventListener("transitionend", animListener);
        timerFallback = setTimeout(animListener, props.duration * 1.1);
      }, 100);
    }
    function onLeave(el, done) {
      let pos;
      element = el;
      if (animating === true) {
        cleanup();
      } else {
        lastEvent = "show";
        pos = el.scrollHeight;
      }
      begin(el, pos, done);
      timer = setTimeout(() => {
        el.style.height = 0;
        animListener = (evt) => {
          if (Object(evt) !== evt || evt.target === el) {
            end(el, "hide");
          }
        };
        el.addEventListener("transitionend", animListener);
        timerFallback = setTimeout(animListener, props.duration * 1.1);
      }, 100);
    }
    onBeforeUnmount(() => {
      animating === true && cleanup();
    });
    return () => h(Transition, {
      css: false,
      appear: props.appear,
      onEnter,
      onLeave
    }, slots.default);
  }
});
const itemGroups = shallowReactive({});
const LINK_PROPS = Object.keys(useRouterLinkProps);
var QExpansionItem = createComponent({
  name: "QExpansionItem",
  props: {
    ...useRouterLinkProps,
    ...useModelToggleProps,
    ...useDarkProps,
    icon: String,
    label: String,
    labelLines: [Number, String],
    caption: String,
    captionLines: [Number, String],
    dense: Boolean,
    expandIcon: String,
    expandedIcon: String,
    expandIconClass: [Array, String, Object],
    duration: Number,
    headerInsetLevel: Number,
    contentInsetLevel: Number,
    expandSeparator: Boolean,
    defaultOpened: Boolean,
    expandIconToggle: Boolean,
    switchToggleSide: Boolean,
    denseToggle: Boolean,
    group: String,
    popup: Boolean,
    headerStyle: [Array, String, Object],
    headerClass: [Array, String, Object]
  },
  emits: [
    ...useModelToggleEmits,
    "click",
    "after-show",
    "after-hide"
  ],
  setup(props, { slots, emit }) {
    const { proxy: { $q } } = getCurrentInstance();
    const isDark = useDark(props, $q);
    const showing = ref(
      props.modelValue !== null ? props.modelValue : props.defaultOpened
    );
    const blurTargetRef = ref(null);
    const { hide, toggle } = useModelToggle({ showing });
    let uniqueId, exitGroup;
    const classes = computed(
      () => `q-expansion-item q-item-type q-expansion-item--${showing.value === true ? "expanded" : "collapsed"} q-expansion-item--${props.popup === true ? "popup" : "standard"}`
    );
    const contentStyle = computed(() => {
      if (props.contentInsetLevel === void 0) {
        return null;
      }
      const dir = $q.lang.rtl === true ? "Right" : "Left";
      return {
        ["padding" + dir]: props.contentInsetLevel * 56 + "px"
      };
    });
    const hasLink = computed(
      () => props.disable !== true && (props.href !== void 0 || props.to !== void 0 && props.to !== null && props.to !== "")
    );
    const linkProps = computed(() => {
      const acc = {};
      LINK_PROPS.forEach((key) => {
        acc[key] = props[key];
      });
      return acc;
    });
    const isClickable = computed(
      () => hasLink.value === true || props.expandIconToggle !== true
    );
    const expansionIcon = computed(() => props.expandedIcon !== void 0 && showing.value === true ? props.expandedIcon : props.expandIcon || $q.iconSet.expansionItem[props.denseToggle === true ? "denseIcon" : "icon"]);
    const activeToggleIcon = computed(
      () => props.disable !== true && (hasLink.value === true || props.expandIconToggle === true)
    );
    watch(() => props.group, (name) => {
      exitGroup !== void 0 && exitGroup();
      name !== void 0 && enterGroup();
    });
    function onHeaderClick(e) {
      hasLink.value !== true && toggle(e);
      emit("click", e);
    }
    function toggleIconKeyboard(e) {
      e.keyCode === 13 && toggleIcon(e, true);
    }
    function toggleIcon(e, keyboard) {
      keyboard !== true && blurTargetRef.value !== null && blurTargetRef.value.focus();
      toggle(e);
      stopAndPrevent(e);
    }
    function onShow() {
      emit("after-show");
    }
    function onHide() {
      emit("after-hide");
    }
    function enterGroup() {
      if (uniqueId === void 0) {
        uniqueId = uid();
      }
      if (showing.value === true) {
        itemGroups[props.group] = uniqueId;
      }
      const show = watch(showing, (val) => {
        if (val === true) {
          itemGroups[props.group] = uniqueId;
        } else if (itemGroups[props.group] === uniqueId) {
          delete itemGroups[props.group];
        }
      });
      const group = watch(
        () => itemGroups[props.group],
        (val, oldVal) => {
          if (oldVal === uniqueId && val !== void 0 && val !== uniqueId) {
            hide();
          }
        }
      );
      exitGroup = () => {
        show();
        group();
        if (itemGroups[props.group] === uniqueId) {
          delete itemGroups[props.group];
        }
        exitGroup = void 0;
      };
    }
    function getToggleIcon() {
      const data = {
        class: [
          `q-focusable relative-position cursor-pointer${props.denseToggle === true && props.switchToggleSide === true ? " items-end" : ""}`,
          props.expandIconClass
        ],
        side: props.switchToggleSide !== true,
        avatar: props.switchToggleSide
      };
      const child = [
        h(QIcon, {
          class: "q-expansion-item__toggle-icon" + (props.expandedIcon === void 0 && showing.value === true ? " q-expansion-item__toggle-icon--rotated" : ""),
          name: expansionIcon.value
        })
      ];
      if (activeToggleIcon.value === true) {
        Object.assign(data, {
          tabindex: 0,
          onClick: toggleIcon,
          onKeyup: toggleIconKeyboard
        });
        child.unshift(
          h("div", {
            ref: blurTargetRef,
            class: "q-expansion-item__toggle-focus q-icon q-focus-helper q-focus-helper--rounded",
            tabindex: -1
          })
        );
      }
      return h(QItemSection, data, () => child);
    }
    function getHeaderChild() {
      let child;
      if (slots.header !== void 0) {
        child = [].concat(slots.header({ expanded: showing.value === true }));
      } else {
        child = [
          h(QItemSection, () => [
            h(QItemLabel, { lines: props.labelLines }, () => props.label || ""),
            props.caption ? h(QItemLabel, { lines: props.captionLines, caption: true }, () => props.caption) : null
          ])
        ];
        props.icon && child[props.switchToggleSide === true ? "push" : "unshift"](
          h(QItemSection, {
            side: props.switchToggleSide === true,
            avatar: props.switchToggleSide !== true
          }, () => h(QIcon, { name: props.icon }))
        );
      }
      props.disable !== true && child[props.switchToggleSide === true ? "unshift" : "push"](
        getToggleIcon()
      );
      return child;
    }
    function getHeader() {
      const data = {
        ref: "item",
        style: props.headerStyle,
        class: props.headerClass,
        dark: isDark.value,
        disable: props.disable,
        dense: props.dense,
        insetLevel: props.headerInsetLevel
      };
      if (isClickable.value === true) {
        data.clickable = true;
        data.onClick = onHeaderClick;
        hasLink.value === true && Object.assign(
          data,
          linkProps.value
        );
      }
      return h(QItem, data, getHeaderChild);
    }
    function getTransitionChild() {
      return withDirectives(
        h("div", {
          key: "e-content",
          class: "q-expansion-item__content relative-position",
          style: contentStyle.value
        }, hSlot(slots.default)),
        [[
          vShow,
          showing.value
        ]]
      );
    }
    function getContent() {
      const node = [
        getHeader(),
        h(QSlideTransition, {
          duration: props.duration,
          onShow,
          onHide
        }, getTransitionChild)
      ];
      if (props.expandSeparator === true) {
        node.push(
          h(QSeparator, {
            class: "q-expansion-item__border q-expansion-item__border--top absolute-top",
            dark: isDark.value
          }),
          h(QSeparator, {
            class: "q-expansion-item__border q-expansion-item__border--bottom absolute-bottom",
            dark: isDark.value
          })
        );
      }
      return node;
    }
    props.group !== void 0 && enterGroup();
    onBeforeUnmount(() => {
      exitGroup !== void 0 && exitGroup();
    });
    return () => h("div", { class: classes.value }, [
      h("div", { class: "q-expansion-item__container relative-position" }, getContent())
    ]);
  }
});
var QList = createComponent({
  name: "QList",
  props: {
    ...useDarkProps,
    bordered: Boolean,
    dense: Boolean,
    separator: Boolean,
    padding: Boolean
  },
  setup(props, { slots }) {
    const vm = getCurrentInstance();
    const isDark = useDark(props, vm.proxy.$q);
    const classes = computed(
      () => "q-list" + (props.bordered === true ? " q-list--bordered" : "") + (props.dense === true ? " q-list--dense" : "") + (props.separator === true ? " q-list--separator" : "") + (isDark.value === true ? " q-list--dark" : "") + (props.padding === true ? " q-list--padding" : "")
    );
    return () => h("div", { class: classes.value }, hSlot(slots.default));
  }
});
const useRatioProps = {
  ratio: [String, Number]
};
function useRatio(props, naturalRatio) {
  return computed(() => {
    const ratio = Number(
      props.ratio || (naturalRatio !== void 0 ? naturalRatio.value : void 0)
    );
    return isNaN(ratio) !== true && ratio > 0 ? { paddingBottom: `${100 / ratio}%` } : null;
  });
}
const defaultRatio = 16 / 9;
var QImg = createComponent({
  name: "QImg",
  props: {
    ...useRatioProps,
    src: String,
    srcset: String,
    sizes: String,
    alt: String,
    crossorigin: String,
    decoding: String,
    referrerpolicy: String,
    draggable: Boolean,
    loading: {
      type: String,
      default: "lazy"
    },
    fetchpriority: {
      type: String,
      default: "auto"
    },
    width: String,
    height: String,
    initialRatio: {
      type: [Number, String],
      default: defaultRatio
    },
    placeholderSrc: String,
    fit: {
      type: String,
      default: "cover"
    },
    position: {
      type: String,
      default: "50% 50%"
    },
    imgClass: String,
    imgStyle: Object,
    noSpinner: Boolean,
    noNativeMenu: Boolean,
    noTransition: Boolean,
    spinnerColor: String,
    spinnerSize: String
  },
  emits: ["load", "error"],
  setup(props, { slots, emit }) {
    const naturalRatio = ref(props.initialRatio);
    const ratioStyle = useRatio(props, naturalRatio);
    let loadTimer;
    const images = [
      ref(null),
      ref(props.placeholderSrc !== void 0 ? { src: props.placeholderSrc } : null)
    ];
    const position = ref(0);
    const isLoading = ref(false);
    const hasError = ref(false);
    const classes = computed(
      () => `q-img q-img--${props.noNativeMenu === true ? "no-" : ""}menu`
    );
    const style = computed(() => ({
      width: props.width,
      height: props.height
    }));
    const imgClass = computed(
      () => `q-img__image ${props.imgClass !== void 0 ? props.imgClass + " " : ""}q-img__image--with${props.noTransition === true ? "out" : ""}-transition`
    );
    const imgStyle = computed(() => ({
      ...props.imgStyle,
      objectFit: props.fit,
      objectPosition: props.position
    }));
    watch(() => getCurrentSrc(), addImage);
    function getCurrentSrc() {
      return props.src || props.srcset || props.sizes ? {
        src: props.src,
        srcset: props.srcset,
        sizes: props.sizes
      } : null;
    }
    function addImage(imgProps) {
      clearTimeout(loadTimer);
      hasError.value = false;
      if (imgProps === null) {
        isLoading.value = false;
        images[0].value = null;
        images[1].value = null;
        return;
      }
      isLoading.value = true;
      images[position.value].value = imgProps;
    }
    function onLoad({ target }) {
      if (loadTimer === null) {
        return;
      }
      clearTimeout(loadTimer);
      naturalRatio.value = target.naturalHeight === 0 ? 0.5 : target.naturalWidth / target.naturalHeight;
      waitForCompleteness(target, 1);
    }
    function waitForCompleteness(target, count) {
      if (loadTimer === null || count === 1e3) {
        return;
      }
      if (target.complete === true) {
        onReady(target);
      } else {
        loadTimer = setTimeout(() => {
          waitForCompleteness(target, count + 1);
        }, 50);
      }
    }
    function onReady(img) {
      if (loadTimer === null) {
        return;
      }
      position.value = position.value === 1 ? 0 : 1;
      images[position.value].value = null;
      isLoading.value = false;
      hasError.value = false;
      emit("load", img.currentSrc || img.src);
    }
    function onError(err) {
      clearTimeout(loadTimer);
      isLoading.value = false;
      hasError.value = true;
      images[0].value = null;
      images[1].value = null;
      emit("error", err);
    }
    function getContainer(key, child) {
      return h(
        "div",
        { class: "q-img__container absolute-full", key },
        child
      );
    }
    function getImage(index) {
      const img = images[index].value;
      const data = {
        key: "img_" + index,
        class: imgClass.value,
        style: imgStyle.value,
        crossorigin: props.crossorigin,
        decoding: props.decoding,
        referrerpolicy: props.referrerpolicy,
        height: props.height,
        width: props.width,
        loading: props.loading,
        fetchpriority: props.fetchpriority,
        "aria-hidden": "true",
        draggable: props.draggable,
        ...img
      };
      if (position.value === index) {
        data.class += " q-img__image--waiting";
        Object.assign(data, { onLoad, onError });
      } else {
        data.class += " q-img__image--loaded";
      }
      return getContainer("img" + index, h("img", data));
    }
    function getContent() {
      if (isLoading.value !== true) {
        return h("div", {
          key: "content",
          class: "q-img__content absolute-full q-anchor--skip"
        }, hSlot(slots[hasError.value === true ? "error" : "default"]));
      }
      return h("div", {
        key: "loading",
        class: "q-img__loading absolute-full flex flex-center"
      }, slots.loading !== void 0 ? slots.loading() : props.noSpinner === true ? void 0 : [
        h(QSpinner, {
          color: props.spinnerColor,
          size: props.spinnerSize
        })
      ]);
    }
    {
      {
        addImage(getCurrentSrc());
      }
      onBeforeUnmount(() => {
        clearTimeout(loadTimer);
        loadTimer = null;
      });
    }
    return () => {
      const content = [];
      if (ratioStyle.value !== null) {
        content.push(
          h("div", { key: "filler", style: ratioStyle.value })
        );
      }
      if (hasError.value !== true) {
        if (images[0].value !== null) {
          content.push(getImage(0));
        }
        if (images[1].value !== null) {
          content.push(getImage(1));
        }
      }
      content.push(
        h(Transition, { name: "q-transition--fade" }, getContent)
      );
      return h("div", {
        class: classes.value,
        style: style.value,
        role: "img",
        "aria-label": props.alt
      }, content);
    };
  }
});
const _hoisted_1$4 = { class: "row items-start" };
const _hoisted_2$4 = { class: "col-xs-12 col-sm-4 col-md-3 col-lg-2 q-pa-xs" };
const _hoisted_3$4 = { class: "row" };
const _hoisted_4$4 = { class: "col-5" };
const _hoisted_5$4 = { class: "col-5" };
const _hoisted_6$4 = { class: "row" };
const _hoisted_7$4 = { class: "col" };
const _hoisted_8$3 = /* @__PURE__ */ createTextVNode("This url is open in one of your tabs");
const _hoisted_9$3 = { class: "col" };
const _hoisted_10$3 = /* @__PURE__ */ createTextVNode("Save this tab to your current context");
const _hoisted_11$3 = { class: "col" };
const _hoisted_12$3 = /* @__PURE__ */ createBaseVNode("div", { class: "col-1" }, null, -1);
const _hoisted_13$2 = { class: "col-1" };
const _hoisted_14$1 = { class: "text-overline" };
const _hoisted_15$1 = { class: "text-body1 q-mt-sm q-mb-xs" };
const _hoisted_16$1 = {
  class: "text-caption text-grey wrap",
  style: { "overflow": "hidden" }
};
const _hoisted_17$1 = { class: "cursor-pointer" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Tabcards",
  props: {
    tabs: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    function getShortHostname(host) {
      const nrOfDots = (host.match(/\./g) || []).length;
      if (nrOfDots >= 2) {
        return host.substring(host.indexOf(".", nrOfDots - 2) + 1);
      }
      return host;
    }
    function getHost(urlAsString, shorten = true) {
      try {
        const url = new URL(urlAsString);
        if (!shorten) {
          return url.protocol + "://" + url.host.toString();
        }
        return getShortHostname(url.host);
      } catch (e) {
        return "---";
      }
    }
    function withoutHostname(url) {
      const splits = url == null ? void 0 : url.split(getHost(url));
      if ((splits == null ? void 0 : splits.length) > 1) {
        return "..." + splits[1];
      }
      return "---";
    }
    function maxChar(max, t) {
      if ((t == null ? void 0 : t.length) > max - 3) {
        return t.substring(0, max - 3) + "...";
      }
      return t;
    }
    function closeTab(chromeTab) {
      Navigation.closeTab(chromeTab);
    }
    function saveTab(id) {
      console.log("saving tab", id);
      TabsetService.setStatus(id, TabStatus.DEFAULT);
    }
    function togglePin(tabId) {
      console.log("toggling pin", tabId);
      TabsetService.togglePin(tabId);
    }
    function cardStyle(tab) {
      const height = "150px";
      let borderColor = "";
      if (TabStatus.CREATED === tab.status) {
        borderColor = "";
      } else if (TabStatus.DELETED === tab.status) {
        borderColor = "border-color:#EF9A9A";
      }
      let background = "";
      if (tab.isDuplicate) {
        background = "background: radial-gradient(circle, #FFFFFF 0%, #FFECB3 100%)";
      }
      return `height: ${height};max-height:${height}; min-height: ${height};${borderColor};${background}`;
    }
    function isOpen(tab) {
      var _a;
      return TabsetService.isOpen(((_a = tab == null ? void 0 : tab.chromeTab) == null ? void 0 : _a.url) || "");
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(props.tabs, (tab) => {
          return openBlock(), createElementBlock("div", _hoisted_2$4, [
            createVNode(QCard, {
              class: "my-card",
              flat: "",
              bordered: "",
              style: normalizeStyle(cardStyle(tab))
            }, {
              default: withCtx(() => [
                createVNode(QCardSection, { horizontal: "" }, {
                  default: withCtx(() => [
                    createVNode(QCardSection, {
                      class: "q-pt-xs",
                      style: { "width": "100%" }
                    }, {
                      default: withCtx(() => {
                        var _a, _b, _c;
                        return [
                          createBaseVNode("div", _hoisted_3$4, [
                            createBaseVNode("div", _hoisted_4$4, [
                              createVNode(QImg, {
                                class: "rounded-borders",
                                width: "20px",
                                height: "20px",
                                src: (_a = tab.chromeTab) == null ? void 0 : _a.favIconUrl
                              }, {
                                default: withCtx(() => [
                                  createVNode(QTooltip, null, {
                                    default: withCtx(() => {
                                      var _a2;
                                      return [
                                        createTextVNode(toDisplayString((_a2 = tab.chromeTab) == null ? void 0 : _a2.id), 1)
                                      ];
                                    }),
                                    _: 2
                                  }, 1024)
                                ]),
                                _: 2
                              }, 1032, ["src"])
                            ]),
                            createBaseVNode("div", _hoisted_5$4, [
                              createBaseVNode("div", _hoisted_6$4, [
                                createBaseVNode("div", _hoisted_7$4, [
                                  isOpen(tab) ? (openBlock(), createBlock(QIcon, {
                                    key: 0,
                                    name: "done",
                                    color: "green",
                                    class: "cursor-pointer"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(QTooltip, null, {
                                        default: withCtx(() => [
                                          _hoisted_8$3
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })) : createCommentVNode("", true)
                                ]),
                                createBaseVNode("div", _hoisted_9$3, [
                                  tab.status !== unref(TabStatus).DEFAULT ? (openBlock(), createBlock(QIcon, {
                                    key: 0,
                                    name: "save",
                                    class: "cursor-pointer",
                                    onClick: ($event) => saveTab(tab.chromeTab.id)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(QTooltip, null, {
                                        default: withCtx(() => [
                                          _hoisted_10$3
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])) : createCommentVNode("", true)
                                ]),
                                createBaseVNode("div", _hoisted_11$3, [
                                  createVNode(QIcon, {
                                    name: ((_b = tab.chromeTab) == null ? void 0 : _b.pinned) ? "o_push_pin" : "push_pin",
                                    class: "cursor-pointer",
                                    onClick: ($event) => togglePin(tab.chromeTab.id)
                                  }, {
                                    default: withCtx(() => {
                                      var _a2;
                                      return [
                                        createVNode(QTooltip, {
                                          textContent: toDisplayString(((_a2 = tab.chromeTab) == null ? void 0 : _a2.pinned) ? "Unpin this tab" : "Pin this tab")
                                        }, null, 8, ["textContent"])
                                      ];
                                    }),
                                    _: 2
                                  }, 1032, ["name", "onClick"])
                                ])
                              ])
                            ]),
                            _hoisted_12$3,
                            createBaseVNode("div", _hoisted_13$2, [
                              createVNode(QIcon, {
                                name: "close",
                                class: "cursor-pointer",
                                onClick: ($event) => closeTab(tab.chromeTab)
                              }, null, 8, ["onClick"])
                            ])
                          ]),
                          createBaseVNode("div", _hoisted_14$1, [
                            createTextVNode(toDisplayString(getHost(tab.chromeTab.url, true)) + " " + toDisplayString(tab.activatedCount) + "/" + toDisplayString(tab.lastActive) + " ", 1),
                            createVNode(QTooltip, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(getHost(tab.chromeTab.url, false)), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          createBaseVNode("div", _hoisted_15$1, toDisplayString(maxChar(20, ((_c = tab.chromeTab) == null ? void 0 : _c.title) || tab.title)), 1),
                          createBaseVNode("div", _hoisted_16$1, [
                            createVNode(QItemLabel, {
                              lines: "1",
                              class: "q-mt-xs text-body2 text-primary",
                              onClick: ($event) => {
                                var _a2;
                                return unref(Navigation).openOrCreateTab(((_a2 = tab.chromeTab) == null ? void 0 : _a2.url) || tab.url);
                              }
                            }, {
                              default: withCtx(() => {
                                var _a2;
                                return [
                                  createBaseVNode("span", _hoisted_17$1, toDisplayString(maxChar(30, withoutHostname(((_a2 = tab.chromeTab) == null ? void 0 : _a2.url) || tab.url))), 1),
                                  createVNode(QTooltip, null, {
                                    default: withCtx(() => {
                                      var _a3;
                                      return [
                                        createTextVNode(toDisplayString(((_a3 = tab.chromeTab) == null ? void 0 : _a3.url) || tab.url), 1)
                                      ];
                                    }),
                                    _: 2
                                  }, 1024)
                                ];
                              }),
                              _: 2
                            }, 1032, ["onClick"])
                          ])
                        ];
                      }),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1032, ["style"])
          ]);
        }), 256))
      ]);
    };
  }
});
const _hoisted_1$3 = { class: "row justify-start items-baseline" };
const _hoisted_2$3 = ["textContent"];
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("div", {
  class: "col",
  style: { "color": "#000066" }
}, null, -1);
const _hoisted_4$3 = /* @__PURE__ */ createTextVNode("Save tabset as...");
const _hoisted_5$3 = /* @__PURE__ */ createTextVNode("Unset Context");
const _hoisted_6$3 = /* @__PURE__ */ createTextVNode("Replace all current tabs with this tabset");
const _hoisted_7$3 = /* @__PURE__ */ createTextVNode("Delete this tabset");
const _hoisted_8$2 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pending Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "These tabs have been used in the current context but have not been saved yet ")
], -1);
const _hoisted_9$2 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pinned Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "this browser's window's tabs which are pinned right now")
], -1);
const _hoisted_10$2 = { class: "text-weight-bold" };
const _hoisted_11$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_12$2 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Other Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "current tabs, neither pinned nor grouped")
], -1);
const _hoisted_13$1 = { key: 3 };
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "ContextComponent",
  setup(__props) {
    useRoute();
    const router = useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    const tabsetname = ref(tabsStore.currentTabsetName);
    const $q = useQuasar();
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1 && (t.status === TabStatus.DEFAULT || !t.status)
      );
    }
    function tabsForGroup(groupId) {
      console.log("tabsforGroup", groupId);
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t.chromeTab || t),
        (t) => t.groupId === groupId
      );
    }
    const unsetContext = () => TabsetService.unsetContext();
    const formatLength = (length, singular, plural) => {
      return length > 1 ? length + " " + plural : length + " " + singular;
    };
    const removeClosedTabs = () => TabsetService.removeClosedTabs();
    const saveAllPendingTabs = () => TabsetService.saveAllPendingTabs();
    const saveDialog = () => {
      $q.dialog({
        title: "Save current Tabset",
        message: "Please provide a name for the new (or updated) tabset",
        prompt: {
          isValid: (val) => val != "current",
          model: tabsetname.value === "current" ? "" : tabsetname.value,
          type: "text"
        },
        cancel: true,
        persistent: true
      }).onOk((name) => {
        console.log(">>>> saving", name);
        TabsetService.saveOrReplace(name, tabsStore.tabs);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.delete(tabsStore.currentTabsetId);
        router.push("/");
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const restoreDialog = () => {
      $q.dialog({
        title: "Restore Tabset",
        message: "Would you like to restore this tabset? All current tabs will be closed before.",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.restore(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => [
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "tabs"
            }),
            createVNode(QToolbarTitle, null, {
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_1$3, [
                  createBaseVNode("div", {
                    class: "col-1",
                    style: { "width": "80px" },
                    textContent: toDisplayString("Tabset '" + tabsetname.value + "'")
                  }, null, 8, _hoisted_2$3),
                  _hoisted_3$3
                ])
              ]),
              _: 1
            }),
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "save_as",
              onClick: saveDialog
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_4$3
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "o_center_focus_strong",
              onClick: _cache[0] || (_cache[0] = ($event) => unsetContext())
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_5$3
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 0,
              flat: "",
              round: "",
              dense: "",
              icon: "restore_page",
              color: "green",
              onClick: restoreDialog
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_6$3
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 1,
              flat: "",
              round: "",
              dense: "",
              icon: "delete",
              color: "red",
              onClick: deleteDialog
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_7$3
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(QList, { class: "rounded-borders" }, {
          default: withCtx(() => [
            unref(tabsStore).pendingTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 0,
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black",
              "expand-separator": "",
              "default-opened": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "push_pin" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_8$2
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unref(tabsStore).pendingTabs.length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createBaseVNode("div", null, [
                  unref(_).filter(unref(tabsStore).pendingTabs, (t) => t.status === unref(TabStatus).DELETED).length > 1 ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: "cursor-pointer",
                    onClick: _cache[1] || (_cache[1] = ($event) => removeClosedTabs())
                  }, "[remove all closed tabs]")) : createCommentVNode("", true),
                  unref(tabsStore).pendingTabs.length > 1 ? (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: "cursor-pointer",
                    onClick: _cache[2] || (_cache[2] = ($event) => saveAllPendingTabs())
                  }, "[save all]")) : createCommentVNode("", true)
                ]),
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unref(tabsStore).pendingTabs
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 1,
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black",
              "expand-separator": "",
              "default-opened": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "push_pin" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_9$2
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unref(tabsStore).pinnedTabs
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
              return openBlock(), createElementBlock("div", null, [
                tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                  key: 0,
                  "header-class": "bg-amber-2 text-black",
                  "expand-icon-class": "text-black",
                  "expand-separator": "",
                  "default-opened": ""
                }, {
                  header: withCtx(({ expanded }) => [
                    createVNode(QItemSection, { avatar: "" }, {
                      default: withCtx(() => [
                        createVNode(QIcon, {
                          color: group.color,
                          name: "tab"
                        }, null, 8, ["color"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createBaseVNode("div", null, [
                          createBaseVNode("span", _hoisted_10$2, toDisplayString(group.title), 1),
                          _hoisted_11$2
                        ])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  default: withCtx(() => [
                    createVNode(QCard, null, {
                      default: withCtx(() => [
                        createVNode(QCardSection, null, {
                          default: withCtx(() => [
                            createVNode(_sfc_main$4, {
                              tabs: tabsForGroup(group.id)
                            }, null, 8, ["tabs"])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)) : createCommentVNode("", true)
              ]);
            }), 256)),
            unref(tabsStore).pinnedTabs.length > 0 || unref(tabGroupsStore).tabGroups.length > 0 || unref(tabsStore).pendingTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 2,
              icon: "tabs",
              "default-opened": "",
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black"
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "tab" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_12$2
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unpinnedNoGroup()
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : (openBlock(), createElementBlock("div", _hoisted_13$1, [
              createVNode(QCard, null, {
                default: withCtx(() => [
                  createVNode(QCardSection, null, {
                    default: withCtx(() => [
                      createVNode(_sfc_main$4, {
                        tabs: unpinnedNoGroup()
                      }, null, 8, ["tabs"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]))
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
var QBanner = createComponent({
  name: "QBanner",
  props: {
    ...useDarkProps,
    inlineActions: Boolean,
    dense: Boolean,
    rounded: Boolean
  },
  setup(props, { slots }) {
    const vm = getCurrentInstance();
    const isDark = useDark(props, vm.proxy.$q);
    const classes = computed(
      () => "q-banner row items-center" + (props.dense === true ? " q-banner--dense" : "") + (isDark.value === true ? " q-banner--dark q-dark" : "") + (props.rounded === true ? " rounded-borders" : "")
    );
    const actionClass = computed(
      () => `q-banner__actions row items-center justify-end col-${props.inlineActions === true ? "auto" : "all"}`
    );
    return () => {
      const child = [
        h("div", {
          class: "q-banner__avatar col-auto row items-center self-start"
        }, hSlot(slots.avatar)),
        h("div", {
          class: "q-banner__content col text-body2"
        }, hSlot(slots.default))
      ];
      const actions = hSlot(slots.action);
      actions !== void 0 && child.push(
        h("div", { class: actionClass.value }, actions)
      );
      return h("div", {
        class: classes.value + (props.inlineActions === false && actions !== void 0 ? " q-banner--top-padding" : ""),
        role: "alert"
      }, child);
    };
  }
});
const _hoisted_1$2 = {
  key: 0,
  class: "text-body2"
};
const _hoisted_2$2 = /* @__PURE__ */ createTextVNode(" Currently, your ");
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("b", null, "browser tabs", -1);
const _hoisted_4$2 = /* @__PURE__ */ createTextVNode(" are ");
const _hoisted_5$2 = /* @__PURE__ */ createBaseVNode("b", null, "not tracked", -1);
const _hoisted_6$2 = /* @__PURE__ */ createTextVNode(" by this extension and you do not have any tabs associated with this tabset.");
const _hoisted_7$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_8$1 = /* @__PURE__ */ createTextVNode(" To start tracking, you can set this tabset as your 'context' by clicking on ");
const _hoisted_9$1 = /* @__PURE__ */ createTextVNode(" and ");
const _hoisted_10$1 = /* @__PURE__ */ createBaseVNode("b", null, "start opening new tabs", -1);
const _hoisted_11$1 = /* @__PURE__ */ createTextVNode(". ");
const _hoisted_12$1 = { class: "row justify-start items-baseline" };
const _hoisted_13 = ["textContent"];
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", {
  class: "col",
  style: { "color": "#000066" }
}, null, -1);
const _hoisted_15 = /* @__PURE__ */ createTextVNode("Save tabset as...");
const _hoisted_16 = /* @__PURE__ */ createTextVNode("Set as Context");
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pending Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "These tabs have been used in the current context but have not been saved yet ")
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pinned Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "this browser's window's tabs which are pinned right now")
], -1);
const _hoisted_19 = { class: "text-weight-bold" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Other Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "current tabs, neither pinned nor grouped")
], -1);
const _hoisted_22 = { key: 3 };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "EditTabsetComponent",
  setup(__props) {
    useRoute();
    const router = useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    const tabsetname = ref(tabsStore.currentTabsetName);
    const $q = useQuasar();
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1 && (t.status === TabStatus.DEFAULT || !t.status)
      );
    }
    function tabsForGroup(groupId) {
      console.log("tabsforGroup", groupId);
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t.chromeTab || t),
        (t) => t.groupId === groupId
      );
    }
    const setAsContext = () => TabsetService.setContext(tabsStore.currentTabsetId);
    const formatLength = (length, singular, plural) => {
      return length > 1 ? length + " " + plural : length + " " + singular;
    };
    const removeClosedTabs = () => TabsetService.removeClosedTabs();
    const saveAllPendingTabs = () => TabsetService.saveAllPendingTabs();
    const saveDialog = () => {
      $q.dialog({
        title: "Save current Tabset",
        message: "Please provide a name for the new (or updated) tabset",
        prompt: {
          isValid: (val) => val != "current",
          model: tabsetname.value === "current" ? "" : tabsetname.value,
          type: "text"
        },
        cancel: true,
        persistent: true
      }).onOk((name) => {
        console.log(">>>> saving", name);
        TabsetService.saveOrReplace(name, tabsStore.tabs);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.delete(tabsStore.currentTabsetId);
        router.push("/");
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const restoreDialog = () => {
      $q.dialog({
        title: "Restore Tabset",
        message: "Would you like to restore this tabset? All current tabs will be closed before.",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.restore(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QBanner, {
          rounded: "",
          class: "bg-amber-1 text-black"
        }, {
          default: withCtx(() => [
            unref(tabsStore).getCurrentTabs.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_1$2, [
              _hoisted_2$2,
              _hoisted_3$2,
              _hoisted_4$2,
              _hoisted_5$2,
              _hoisted_6$2,
              _hoisted_7$2,
              _hoisted_8$1,
              createVNode(QIcon, {
                color: "blue",
                name: "center_focus_strong"
              }),
              _hoisted_9$1,
              _hoisted_10$1,
              _hoisted_11$1
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => [
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "tabs"
            }),
            createVNode(QToolbarTitle, null, {
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_12$1, [
                  createBaseVNode("div", {
                    class: "col-1",
                    style: { "width": "80px" },
                    textContent: toDisplayString("Tabset '" + unref(tabsStore).currentTabsetName + "'")
                  }, null, 8, _hoisted_13),
                  _hoisted_14
                ])
              ]),
              _: 1
            }),
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "save_as",
              onClick: saveDialog
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_15
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "center_focus_strong",
              onClick: _cache[0] || (_cache[0] = ($event) => setAsContext())
            }, {
              default: withCtx(() => [
                createVNode(QTooltip, null, {
                  default: withCtx(() => [
                    _hoisted_16
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 0,
              flat: "",
              round: "",
              dense: "",
              icon: "restore_page",
              color: "green",
              onClick: restoreDialog
            })) : createCommentVNode("", true),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 1,
              flat: "",
              round: "",
              dense: "",
              icon: "delete",
              color: "red",
              onClick: deleteDialog
            })) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(QList, { class: "rounded-borders" }, {
          default: withCtx(() => [
            unref(tabsStore).pendingTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 0,
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black",
              "expand-separator": "",
              "default-opened": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "push_pin" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_17
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unref(tabsStore).pendingTabs.length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createBaseVNode("div", null, [
                  unref(_).filter(unref(tabsStore).pendingTabs, (t) => t.status === unref(TabStatus).DELETED).length > 1 ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: "cursor-pointer",
                    onClick: _cache[1] || (_cache[1] = ($event) => removeClosedTabs())
                  }, "[remove all closed tabs]")) : createCommentVNode("", true),
                  unref(tabsStore).pendingTabs.length > 1 ? (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: "cursor-pointer",
                    onClick: _cache[2] || (_cache[2] = ($event) => saveAllPendingTabs())
                  }, "[save all]")) : createCommentVNode("", true)
                ]),
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unref(tabsStore).pendingTabs
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 1,
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black",
              "expand-separator": "",
              "default-opened": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "push_pin" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_18
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unref(tabsStore).pinnedTabs
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
              return openBlock(), createElementBlock("div", null, [
                tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                  key: 0,
                  "header-class": "bg-amber-2 text-black",
                  "expand-icon-class": "text-black",
                  "expand-separator": "",
                  "default-opened": ""
                }, {
                  header: withCtx(({ expanded }) => [
                    createVNode(QItemSection, { avatar: "" }, {
                      default: withCtx(() => [
                        createVNode(QIcon, {
                          color: group.color,
                          name: "tab"
                        }, null, 8, ["color"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createBaseVNode("div", null, [
                          createBaseVNode("span", _hoisted_19, toDisplayString(group.title), 1),
                          _hoisted_20
                        ])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  default: withCtx(() => [
                    createVNode(QCard, null, {
                      default: withCtx(() => [
                        createVNode(QCardSection, null, {
                          default: withCtx(() => [
                            createVNode(_sfc_main$4, {
                              tabs: tabsForGroup(group.id)
                            }, null, 8, ["tabs"])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)) : createCommentVNode("", true)
              ]);
            }), 256)),
            unref(tabsStore).pinnedTabs.length > 0 || unref(tabGroupsStore).tabGroups.length > 0 || unref(tabsStore).pendingTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 2,
              icon: "tabs",
              "default-opened": "",
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black"
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "tab" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_21
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unpinnedNoGroup()
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : (openBlock(), createElementBlock("div", _hoisted_22, [
              createVNode(QCard, null, {
                default: withCtx(() => [
                  createVNode(QCardSection, null, {
                    default: withCtx(() => [
                      createVNode(_sfc_main$4, {
                        tabs: unpinnedNoGroup()
                      }, null, 8, ["tabs"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]))
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "row justify-start items-baseline" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "col-1 text-black" }, "Current tabs of this browser's window")
], -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "row justify-start items-baseline" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "You can save your current tabs and give the new set a name. Or you can start a new tabset from scratch by closing all open tabs")
], -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Pinned Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "this browser's window's tabs which are pinned right now")
], -1);
const _hoisted_4$1 = { class: "text-weight-bold" };
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "chrome browser's group of tabs", -1);
const _hoisted_6$1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-weight-bold" }, "Other Tabs"),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "current tabs, neither pinned nor grouped")
], -1);
const _hoisted_7$1 = { key: 2 };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ChromeTabset",
  setup(__props) {
    useRoute();
    const router = useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    const tabGroupsStore = useTabGroupsStore();
    const tabsetname = ref(tabsStore.currentTabsetName);
    const $q = useQuasar();
    watchEffect(() => {
    });
    function unpinnedNoGroup() {
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t),
        (t) => !t.chromeTab.pinned && t.chromeTab.groupId === -1 && (t.status === TabStatus.DEFAULT || !t.status)
      );
    }
    function tabsForGroup(groupId) {
      console.log("tabsforGroup", groupId);
      return _.filter(
        _.map(tabsStore.getCurrentTabs, (t) => t.chromeTab || t),
        (t) => t.groupId === groupId
      );
    }
    const formatLength = (length, singular, plural) => {
      return length > 1 ? length + " " + plural : length + " " + singular;
    };
    const saveDialog = () => {
      $q.dialog({
        title: "Save open Tabs as Tabset",
        message: "Please provide a name for the new (or updated) tabset",
        prompt: {
          isValid: (val) => val != "current",
          model: tabsetname.value === "current" ? "" : tabsetname.value,
          type: "text"
        },
        cancel: true,
        persistent: true
      }).onOk((name) => {
        console.log(">>>> saving", name);
        TabsetService.saveOrReplace(name, tabsStore.tabs);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const deleteDialog = () => {
      $q.dialog({
        title: "Deleting Tabset",
        message: "Would you like to delete this tabset?",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.delete(tabsStore.currentTabsetId);
        router.push("/");
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    const restoreDialog = () => {
      $q.dialog({
        title: "Restore Tabset",
        message: "Would you like to restore this tabset? All current tabs will be closed before.",
        cancel: true,
        persistent: true
      }).onOk((data) => {
        TabsetService.restore(tabsStore.currentTabsetId);
      }).onCancel(() => {
      }).onDismiss(() => {
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QToolbar, { class: "text-primary" }, {
          default: withCtx(() => [
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "tabs"
            }),
            createVNode(QToolbarTitle, null, {
              default: withCtx(() => [
                _hoisted_1$1,
                _hoisted_2$1
              ]),
              _: 1
            }),
            createVNode(QBtn, {
              flat: "",
              round: "",
              dense: "",
              icon: "save",
              onClick: saveDialog
            }),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 0,
              flat: "",
              round: "",
              dense: "",
              icon: "restore_page",
              color: "green",
              onClick: restoreDialog
            })) : createCommentVNode("", true),
            unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createBlock(QBtn, {
              key: 1,
              flat: "",
              round: "",
              dense: "",
              icon: "delete",
              color: "red",
              onClick: deleteDialog
            })) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(QList, { class: "rounded-borders" }, {
          default: withCtx(() => [
            unref(tabsStore).pinnedTabs.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 0,
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black",
              "expand-separator": "",
              "default-opened": ""
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "push_pin" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_3$1
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unref(tabsStore).pinnedTabs.length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unref(tabsStore).pinnedTabs
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabGroupsStore).tabGroups, (group) => {
              return openBlock(), createElementBlock("div", null, [
                tabsForGroup(group.id).length > 0 ? (openBlock(), createBlock(QExpansionItem, {
                  key: 0,
                  "header-class": "bg-amber-2 text-black",
                  "expand-icon-class": "text-black",
                  "expand-separator": "",
                  "default-opened": ""
                }, {
                  header: withCtx(({ expanded }) => [
                    createVNode(QItemSection, { avatar: "" }, {
                      default: withCtx(() => [
                        createVNode(QIcon, {
                          color: group.color,
                          name: "tab"
                        }, null, 8, ["color"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createBaseVNode("div", null, [
                          createBaseVNode("span", _hoisted_4$1, toDisplayString(group.title), 1),
                          _hoisted_5$1
                        ])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(formatLength(tabsForGroup(group.id).length, "tab", "tabs")), 1)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  default: withCtx(() => [
                    createVNode(QCard, null, {
                      default: withCtx(() => [
                        createVNode(QCardSection, null, {
                          default: withCtx(() => [
                            createVNode(_sfc_main$4, {
                              tabs: tabsForGroup(group.id)
                            }, null, 8, ["tabs"])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)) : createCommentVNode("", true)
              ]);
            }), 256)),
            unref(tabsStore).pinnedTabs.length > 0 || unref(tabGroupsStore).tabGroups.length > 0 ? (openBlock(), createBlock(QExpansionItem, {
              key: 1,
              icon: "tabs",
              "default-opened": "",
              "header-class": "bg-amber-2 text-black",
              "expand-icon-class": "text-black"
            }, {
              header: withCtx(({ expanded }) => [
                createVNode(QItemSection, { avatar: "" }, {
                  default: withCtx(() => [
                    createVNode(QIcon, { name: "tab" })
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    _hoisted_6$1
                  ]),
                  _: 1
                }),
                createVNode(QItemSection, null, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatLength(unpinnedNoGroup().length, "tab", "tabs")), 1)
                  ]),
                  _: 1
                })
              ]),
              default: withCtx(() => [
                createVNode(QCard, null, {
                  default: withCtx(() => [
                    createVNode(QCardSection, null, {
                      default: withCtx(() => [
                        createVNode(_sfc_main$4, {
                          tabs: unpinnedNoGroup()
                        }, null, 8, ["tabs"])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : (openBlock(), createElementBlock("div", _hoisted_7$1, [
              createVNode(QCard, null, {
                default: withCtx(() => [
                  createVNode(QCardSection, null, {
                    default: withCtx(() => [
                      createVNode(_sfc_main$4, {
                        tabs: unpinnedNoGroup()
                      }, null, 8, ["tabs"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]))
          ]),
          _: 1
        })
      ], 64);
    };
  }
});
const _hoisted_1 = { key: 0 };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", null, "Context", -1);
const _hoisted_3 = {
  key: 1,
  class: "text-body1"
};
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", null, "chrome", -1);
const _hoisted_5 = { key: 2 };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("div", null, "Edit 1", -1);
const _hoisted_7 = {
  key: 3,
  class: "text-body1"
};
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("div", null, "Edit 2", -1);
const _hoisted_9 = {
  key: 4,
  class: "text-body1"
};
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", null, "chrome", -1);
const _hoisted_11 = { key: 5 };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("div", null, "ELSE", -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CurrentTabs",
  setup(__props) {
    useRoute();
    useRouter();
    useQuasar().localStorage;
    const tabsStore = useTabsStore();
    useTabGroupsStore();
    ref(tabsStore.currentTabsetName);
    useQuasar();
    watchEffect(() => {
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QPage, { padding: "" }, {
        default: withCtx(() => [
          createTextVNode(" contextId: " + toDisplayString(unref(tabsStore).contextId) + ", Current TabsetId " + toDisplayString(unref(tabsStore).currentTabsetId) + " ", 1),
          unref(tabsStore).contextId && unref(tabsStore).currentTabsetId === unref(tabsStore).contextId ? (openBlock(), createElementBlock("div", _hoisted_1, [
            _hoisted_2,
            createVNode(_sfc_main$3)
          ])) : unref(tabsStore).contextId && unref(tabsStore).currentTabsetId === "current" ? (openBlock(), createElementBlock("div", _hoisted_3, [
            _hoisted_4,
            createVNode(_sfc_main$1)
          ])) : unref(tabsStore).contextId && unref(tabsStore).currentTabsetId !== unref(tabsStore).contextId ? (openBlock(), createElementBlock("div", _hoisted_5, [
            _hoisted_6,
            createVNode(_sfc_main$2)
          ])) : !unref(tabsStore).contextId && unref(tabsStore).currentTabsetId !== "current" ? (openBlock(), createElementBlock("div", _hoisted_7, [
            _hoisted_8,
            createVNode(_sfc_main$2)
          ])) : !unref(tabsStore).contextId && unref(tabsStore).currentTabsetId === "current" ? (openBlock(), createElementBlock("div", _hoisted_9, [
            _hoisted_10,
            createVNode(_sfc_main$1)
          ])) : (openBlock(), createElementBlock("div", _hoisted_11, [
            _hoisted_12,
            createTextVNode(" " + toDisplayString(unref(tabsStore).contextId) + "--" + toDisplayString(unref(tabsStore).currentTabsetId) + "??? ", 1)
          ]))
        ]),
        _: 1
      });
    };
  }
});
export { _sfc_main as default };
