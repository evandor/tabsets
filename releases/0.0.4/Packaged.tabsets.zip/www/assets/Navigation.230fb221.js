var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { j as createComponent, c as computed, h, P as hSlot, g as getCurrentInstance, i as inject, s as layoutKey, S as pageContainerKey, a6 as useTabsStore } from "./index.a33268e4.js";
var QPage = createComponent({
  name: "QPage",
  props: {
    padding: Boolean,
    styleFn: Function
  },
  setup(props, { slots }) {
    const { proxy: { $q } } = getCurrentInstance();
    const $layout = inject(layoutKey);
    inject(pageContainerKey, () => {
      console.error("QPage needs to be child of QPageContainer");
    });
    const style = computed(() => {
      const offset = ($layout.header.space === true ? $layout.header.size : 0) + ($layout.footer.space === true ? $layout.footer.size : 0);
      if (typeof props.styleFn === "function") {
        const height = $layout.isContainer.value === true ? $layout.containerHeight.value : $q.screen.height;
        return props.styleFn(offset, height);
      }
      return {
        minHeight: $layout.isContainer.value === true ? $layout.containerHeight.value - offset + "px" : $q.screen.height === 0 ? offset !== 0 ? `calc(100vh - ${offset}px)` : "100vh" : $q.screen.height - offset + "px"
      };
    });
    const classes = computed(
      () => `q-page ${props.padding === true ? " q-layout-padding" : ""}`
    );
    return () => h("main", {
      class: classes.value,
      style: style.value
    }, hSlot(slots.default));
  }
});
class Navigation {
  constructor() {
    __publicField(this, "tabsStore", useTabsStore());
  }
  openOrCreateTab(withUrl) {
    console.log("hier", withUrl);
    chrome.tabs.query({ currentWindow: true }, (t) => {
      let found = false;
      t.filter((r) => r.url && !r.url.startsWith("chrome")).map((r) => {
        if (withUrl === r.url) {
          found = true;
          chrome.tabs.highlight({ tabs: r.index });
        }
      });
      console.log("found", found);
      if (!found) {
        chrome.tabs.create({
          active: false,
          pinned: false,
          url: withUrl
        }).catch((e) => {
          console.log("got error", e);
        });
      }
    });
  }
  closeTab(tab) {
    if ("current" === this.tabsStore.currentTabsetId) {
      console.log("closing tab with id", tab.id);
      if (tab.id) {
        const tabId = tab.id;
        chrome.tabs.remove(tabId).then((res) => this.tabsStore.removeTab(tabId)).catch((ex) => console.error("ex", ex));
      }
    } else {
      console.log("removing tab", tab.id);
      chrome.tabs.query({ url: tab.url }).then((res) => {
        res.forEach((r) => {
          if (r.id) {
            const tabId = r.id;
            chrome.tabs.remove(tabId).then((res2) => this.tabsStore.removeTab(tabId)).catch((ex) => console.error("ex", ex));
          }
        });
      });
      if (tab.id) {
        this.tabsStore.removeTab(tab.id);
      }
    }
  }
}
var Navigation$1 = new Navigation();
export { Navigation$1 as N, QPage as Q };
